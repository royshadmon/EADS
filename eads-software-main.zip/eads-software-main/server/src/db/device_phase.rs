#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct DevicePhase {
    pub uuid: uuid::Uuid,
    pub name: Option<String>,
    pub device: uuid::Uuid,
}

#[tracing::instrument(skip(pool))]
pub async fn create_device_phase(
    pool: &sqlx::Pool<sqlx::Postgres>,
    device_phase: DevicePhase,
) -> sqlx::Result<i64> {
    sqlx::query!(
        "INSERT INTO device_phases ( \
            uuid, \
            name, \
            device \
        ) VALUES ( \
            $1, \
            $2, \
            (SELECT (id) FROM devices WHERE uuid=$3) \
        ) RETURNING (id)",
        device_phase.uuid,
        device_phase.name,
        device_phase.device,
    )
    .fetch_one(pool)
    .await
    .map(|row| Ok(row.id))?
}

#[tracing::instrument(skip(pool))]
pub async fn get_device_phase(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Option<DevicePhase>> {
    sqlx::query_as!(
        DevicePhase,
        "SELECT \
            device_phases.uuid AS uuid, \
            device_phases.name AS name, \
            devices.uuid AS device \
         FROM device_phases \
         INNER JOIN devices
            ON devices.id = device_phases.device \
         WHERE device_phases.uuid = $1",
        uuid
    )
    .fetch_optional(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn get_device_phases_by_device(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Vec<DevicePhase>> {
    sqlx::query_as!(
        DevicePhase,
        "SELECT \
            device_phases.uuid AS uuid, \
            device_phases.name AS name, \
            devices.uuid AS device \
         FROM devices \
         INNER JOIN device_phases
            ON device_phases.device = devices.id \
         WHERE devices.uuid = $1",
        uuid
    )
    .fetch_all(pool)
    .await
}
