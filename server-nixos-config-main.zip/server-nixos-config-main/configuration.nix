{ config, pkgs, lib, ... }:

{
  imports =
    [ 
      ./hardware-configuration.nix
      ./services.nix

      ./cachix.nix
    ];

  boot.loader.systemd-boot = {
    enable = true;
    editor = false;
    consoleMode = "auto";
    configurationLimit = 20;
  };
  boot.tmpOnTmpfs = true;
  boot.loader.efi.efiSysMountPoint = "/efi";
  boot.initrd.network.ssh.enable = true;
  boot.kernelParams = [ "elevator=none" ];

  networking.hostName = "eads";
  networking.hostId = "6c16503f";

  time.timeZone = "US/Pacific";

  networking.useDHCP = false;
  networking.interfaces.eno1.useDHCP = true;
  networking.interfaces.eno2.useDHCP = true;
  networking.interfaces.enp2s0f0.useDHCP = true;
  networking.interfaces.enp2s0f1.useDHCP = true;
  networking.firewall = {
    enable = true;
    checkReversePath = "strict";
    logRefusedPackets = true;
    logReversePathDrops = true;
    logRefusedConnections = true;
    allowedTCPPorts = lib.mkForce [
      80 443
      22 # SSH
      5000 # Docker registry (insecure)
    ];
    allowedUDPPorts = lib.mkForce [];
  };

  i18n.defaultLocale = "en_US.UTF-8";
  console = {
    font = "Lat2-Terminus16";
    keyMap = "us";
  };

  security.sudo.wheelNeedsPassword = false;

  users.users = {
    cwscott = {
      isNormalUser = true;
      extraGroups = [ "wheel" "docker" ];
      openssh.authorizedKeys.keys = [ 
        "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQC/kvYSYIDDcT4TFvktsARiYkaXPj6E10lx+9dGBXykkOAgx89DlQePn56rGbSFoBBfORS+Voe1VHuOewZVt6PRVrUp9cwnlh0XcgxrNFJx+0243nXb2DCy0u/wD3M2yjugGFtXZH3iTI+DHHdcNZ9f1dHqDyr58TtcW37QxzfGDQ2tHF3TOUoorsu5ydVIWeSAsbhAukSgmbJeaTIDsiSoXN5acx2JucLw46svIbVDUnl2PIly7vkFyRoEUZY0zp3gLDyJOhrb96eCypr6l6kuYQqp1tVL55ej2L1F8in+d4o57+SKZicBvq4HiYwOeNI8PUBbnbIFLBW/eVp+X5sx0Xc1PwH2DZTxtVmhGfYKu9mPuDnb6hqrRMT6lvNCQvNdlCrD0CflyaOPh8+22OIOPlTAoCxCzqhJH61WGGh38OvUmM7J17f6OHHYiIhPAHGzMTahaVaW6sjQVI55Uw0o+lkyqCxWxaS3LOjEgzqzqHW0WXp9EpPJjft7KuJhaKQEF77ubOqxr/96PBScnpGa281tqxMvpQ5vo3bBpv3trRX/xnO0FIu394x4rkYFDiApiPA/lZCxCDWAvOg7+bFqgV9nCIAntML4N3g3L77ENw4Xq6v+lY1RS+f5y/EGyTXzwra1c6dzRLRFlDRqq2NxPY14NyTALJN2bGK0EhH/vw=="
      ];
    };
    balena = {
      isNormalUser = true;
      extraGroups = [ "docker" ];
    };
  };

  environment.systemPackages = with pkgs; [
    # basics
    neovim
    wget
    curl
    (htop.override {
      sensorsSupport = true; 
      systemdSupport = true;
    })
    neofetch
    tmux
    parted
    openssl
    lsof

    # Nix cache
    cachix

    # debugging
    man-pages
    dnsutils
    inetutils
    pciutils
    usbutils
    psmisc
  ];

  documentation = {
    dev.enable = true;
    man.generateCaches = true;
  };
 
  services.openssh = {
    enable = true;
    ports = [ 22 ];
    permitRootLogin = "no"; 
    passwordAuthentication = false;
  };

  services.udisks2.enable = false;
 
  nix = {
    autoOptimiseStore = true;
    package = pkgs.nixFlakes;
    extraOptions = ''
      experimental-features = nix-command flakes
    '';
  };

  zramSwap = {
    enable = true;
    algorithm = "zstd";
  };
 
  nixpkgs.config.allowUnfreePredicate = pkg:
    builtins.elem (lib.getName pkg) [];

  system.stateVersion = "22.05"; 
}

