import React from "react";
import useSWR from "swr";
import moment from 'moment';
import _ from 'lodash';

import { API_URI } from "../constants.js";

import Plotly from 'plotly.js-basic-dist-min';
import createPlotlyComponent from 'react-plotly.js/factory';
const Plot = createPlotlyComponent(Plotly);

const fetcher = (url) => fetch(url, { credentials: 'include' }).then((res) => res.json());

export default function EventPlot({ eventId, streams }) {
  const { data, error } = useSWR(
    `${API_URI}/v1/events/${eventId}/data?streams=${streams.join(",")}`,
    fetcher
  );

  const series = React.useMemo(() => {
      if(!data) {
        return {};
      }

      return Object.keys(data).map(stream => {
        const axes = _.unzip(data[stream])

        return {
          x: axes[0]?.map(x => moment(x / 1000).format("YYYY-MM-DD HH:mm:ss.SSS") + String(Math.round(x % 1000)).padStart(3, '0')),
          y: axes[1],
          type: 'line',
        };
      });
    },
    [data]
  );

  if (error) return "An error has occurred.";
  if (!data) return "Loading...";

  return <Plot
      data={ series }
      useResizeHandler={true}
      style={{width: "100%", height: "100%"}}
    />;
}
