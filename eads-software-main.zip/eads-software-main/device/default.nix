{ pkgs, ... }:
{
  eads-sampling = (import ./sampling { inherit pkgs; }).eads-sampling;
  eads-sampling-container = (import ./sampling { inherit pkgs; }).eads-sampling-container;

  eads-scpi = (import ./scpi { inherit pkgs; }).eads-scpi;
  eads-scpi-container = (import ./scpi { inherit pkgs; }).eads-scpi-container;

  eads-gpsd-container = (import ./gpsd { inherit pkgs; }).eads-gpsd-container;
  eads-chrony-container = (import ./chrony { inherit pkgs; }).eads-chrony-container;

  eads-wifi-connect-ui = (import ./wifi-connect { inherit pkgs; }).eads-wifi-connect-ui;
  eads-wifi-connect-container = (import ./wifi-connect { inherit pkgs; }).eads-wifi-connect-container;
}
