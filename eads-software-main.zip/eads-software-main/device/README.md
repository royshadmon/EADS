# EADS Device Software

This directory contains the source for the EADS device firmware.

## Overview

The EADS firmware consists of several software modules, as defined in `docker-compose.yml`.

| Service              | Description                                                                                                                                                                                                                           |
|----------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| api-client           | 
| [sampling](sampling) | The sampling service is in charge of communicating with the ADC and retrieving samples at a set interval.                                                                                                                             |
| [scpi](scpi)         | The scpi service exposes an [SCPI](https://en.wikipedia.org/wiki/Standard_Commands_for_Programmable_Instruments) interface for use in testing and calibration of the device.                                                          |
| [gpsd](gpsd)         | The [gpsd](https://gpsd.gitlab.io/gpsd) service manages the hardware GPS module and provides accurate PPS timing information to the [chrony](chrony) instance.                                                                        |
| [chrony](chrony)     | The [chrony](https://chrony.tuxfamily.org) service provides an accurate system clock to the other services.                                                                                                                           |

## Getting Started

This repository can be deployed directly to a [Balena](https://www.balena.io/) fleet using the [Balena CLI](https://www.balena.io/docs/learn/deploy/deployment/).

In order for the GPS hardware module to work, **all Balena devices must be using the production version of BalenaOS.**

### Device Configuration

The following device configuration variables are required.

| Name                          | Value                                     |
|-------------------------------|-------------------------------------------|
| `RESIN_HOST_CONFIG_dtparam`   | `"i2c_arm=on","spi=on","audio=on"`        |
| `RESIN_HOST_CONFIG_dtoverlay` | `"pi3-miniuart-bt","pps-gpio,gpiopin=18"` |

### Environment Variables

The following environment variables are required.

| Variable           | Service      | Default Value                  | Description                                               |
|--------------------|--------------|--------------------------------|-----------------------------------------------------------|
| `SEADS_DEVICE_ID`  | All services | `DEVICE_ID_MISSING`            | 4 character device ID as shown in the SEADS web interface |
| `SEADS_UPLOAD_URL` | `sender`     | `$SEADS_SERVER/api/post/batch` | URL to post sample data from the `sender` app             |
