# gpsd

The [gpsd](https://gpsd.gitlab.io/gpsd) service manages the hardware GPS module and provides accurate PPS timing information to the chrony instance.

## Hardware

The gpsd service requires a GPS receiver to be connected to the `/dev/ttyAMA0` serial port. This is set to a baudrate of 9600 by default.

The GPS module should be connected as follows:
- GPIO 14: UART TX
- GPIO 15: UART RX
- GPIO 18: PPS
