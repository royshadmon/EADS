use std::collections::{BTreeMap, HashMap};
use std::time::{SystemTime, UNIX_EPOCH};

use axum::extract::{Path, Query};
use axum::Json;
use axum::{extract::Extension, http::StatusCode, response::IntoResponse};
use axum_extra::extract::cookie::CookieJar;
use color_eyre::eyre;
use jwt::{SignWithKey, VerifyWithKey};
use serde_json::json;

use crate::db;
use crate::server_config::ServerConfig;
use crate::server_error::ServerError;

use super::auth_middleware::Auth;

#[tracing::instrument(skip(pool, user, _perms, config))]
pub async fn register_device(
    Auth(user, _perms): Auth,
    Path(uuid): Path<uuid::Uuid>,
    Query(params): Query<HashMap<String, String>>,
    Extension(config): Extension<ServerConfig>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    let device = db::get_device(&pool, uuid)
        .await?
        .ok_or(ServerError::KnownError((
            StatusCode::BAD_REQUEST,
            "Device not found.",
        )))?;

    let state = db::get_device_registration_state(&pool, uuid)
        .await?
        .unwrap();

    if state.registered {
        return Err(ServerError::KnownError((
            StatusCode::BAD_REQUEST,
            "Device is already registered.",
        )));
    }

    let time = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_secs();

    // If a verification was already completed but the device was not
    // registered then we can assume that the user is trying to verify
    // again. In that case, remove the completed time.
    if state.register_validation_completed.is_some() {
        db::set_device_register_validation_completed(&pool, uuid, None).await?;
    }

    db::set_device_register_waiting_on_validation(&pool, uuid, time).await?;

    Ok((
        StatusCode::OK,
        Json(json!({ "token": make_registration_token(config, device.uuid, time)?})),
    ))
}

#[derive(Debug, serde::Deserialize)]
pub struct RegistrationInfoRef {
    pub name: String,
    pub longitude: f64,
    pub latitude: f64,
}

#[tracing::instrument(skip(pool, user, _perms, config))]
pub async fn complete_registration(
    Auth(user, _perms): Auth,
    Path(uuid): Path<uuid::Uuid>,
    jar: CookieJar,
    axum::Json(payload): axum::Json<RegistrationInfoRef>,
    Extension(config): Extension<ServerConfig>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    let device = db::get_device(&pool, uuid)
        .await?
        .ok_or(ServerError::KnownError((
            StatusCode::BAD_REQUEST,
            "Device not found.",
        )))?;

    let state = db::get_device_registration_state(&pool, uuid)
        .await?
        .unwrap();

    if state.registered {
        return Err(ServerError::KnownError((
            StatusCode::BAD_REQUEST,
            "Device is already registered.",
        )));
    }

    let register_token = jar.get("register-token").ok_or(ServerError::KnownError((
        StatusCode::BAD_REQUEST,
        "Missing cookie 'register-token'.",
    )))?;

    let (token_device, token_time) =
        validate_registration_token(&config, register_token.value()).ok_or(
            ServerError::KnownError((StatusCode::BAD_REQUEST, "Invalid register token.")),
        )?;

    if token_device != uuid {
        return Err(ServerError::KnownError((
            StatusCode::BAD_REQUEST,
            "Invalid register token.",
        )));
    }

    let state = db::get_device_registration_state(&pool, uuid)
        .await?
        .unwrap();

    if Some(token_time)
        != state
            .register_waiting_on_validation
            .map(|x| x.assume_utc().unix_timestamp() as u64)
    {
        return Err(ServerError::KnownError((
            StatusCode::BAD_REQUEST,
            "Expired register token.",
        )));
    }

    db::set_device_registration_info(
        &pool,
        uuid,
        db::RegistrationInfo {
            name: payload.name,
            longitude: payload.longitude,
            latitude: payload.latitude,
            user: user.uuid,
        },
    )
    .await?;

    db::set_device_registered(&pool, uuid, true).await?;

    Ok(())
}

#[derive(serde::Serialize)]
#[serde(rename_all = "snake_case")]
enum RegistrationStatus {
    Registered,
    Validated,
    WaitingForValidation,
    NotRegisteredOnline,
    NotRegistered,
}

#[tracing::instrument(skip(pool, user, _perms))]
pub async fn get_registration_status(
    Auth(user, _perms): Auth,
    Path(uuid): Path<uuid::Uuid>,
    Query(params): Query<HashMap<String, String>>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    let device = db::get_device(&pool, uuid)
        .await?
        .ok_or(ServerError::KnownError((
            StatusCode::BAD_REQUEST,
            "Device not found.",
        )))?;

    let state = db::get_device_registration_state(&pool, uuid)
        .await?
        .unwrap();

    let status = if state.registered {
        RegistrationStatus::Registered
    } else if state.register_validation_completed.is_some() {
        RegistrationStatus::Validated
    } else if Some(true)
        == state.register_waiting_on_validation.and_then(|x| {
            SystemTime::now()
                .duration_since(x.into())
                .ok()
                .map(|d| d.as_secs() < 300)
        })
    {
        RegistrationStatus::WaitingForValidation
    } else if device.last_online.is_some() {
        // TODO: Check here if the device is still online???
        RegistrationStatus::NotRegisteredOnline
    } else {
        RegistrationStatus::NotRegistered
    };

    Ok((StatusCode::OK, Json(json!({ "status": status }))))
}

fn make_registration_token(
    config: ServerConfig,
    device: uuid::Uuid,
    time: u64,
) -> eyre::Result<String> {
    let mut claims = BTreeMap::new();
    claims.insert("type", "register".to_string());
    claims.insert("device", device.to_string());
    claims.insert("time", time.to_string());
    Ok(claims.sign_with_key(&config.jwt_key)?)
}

fn validate_registration_token(config: &ServerConfig, token: &str) -> Option<(uuid::Uuid, u64)> {
    let claims: BTreeMap<String, String> = token.verify_with_key(&config.jwt_key).ok()?;

    let device = match claims.get("device").map(|x| uuid::Uuid::parse_str(x)) {
        Some(Ok(device)) => device,
        _ => {
            return None;
        }
    };

    let time = match claims.get("time").map(|x| x.parse::<u64>()) {
        Some(Ok(time)) => time,
        _ => {
            return None;
        }
    };

    Some((device, time))
}
