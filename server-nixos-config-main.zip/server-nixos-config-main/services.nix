{ pkgs, lib, ... }:

{
  security.acme = {
    defaults.email = "eads-group@ucsc.edu";
    acceptTerms = true;
  };

  virtualisation.docker = {
    enable = true;
    storageDriver = "zfs";
    autoPrune.enable = true;
  };

  services.dockerRegistry = {
    enable = true;
    enableDelete = true;
    enableGarbageCollect = true;

    # Allow docker containers to connect
    listenAddress = "0.0.0.0";
  };

  services.nomad = {
    enable = true;
    extraPackages = with pkgs; [ cni-plugins ];

    # Required for bridged networking
    dropPrivileges = false;

    settings = {
      server = {
        enabled = true;
	bootstrap_expect = 1;
      };
      client = {
        enabled = true;
	cni_path = "${pkgs.cni-plugins}/bin";
	host_volume."postgres" = {
	  path = "/data/postgres";
	  read_only = false;
	};
      };
    };
  };

  services.gitlab = {
    enable = true;
    initialRootPasswordFile = "/var/gitlab/secrets/root.txt";

    host = "git.eads.soe.ucsc.edu";
    port = 443;
    https = true;

    secrets = {
      dbFile = "/var/gitlab/secrets/db.txt";
      jwsFile = "/var/gitlab/secrets/jws.txt";
      otpFile = "/var/gitlab/secrets/otp.txt";
      secretFile = "/var/gitlab/secrets/secret.txt";
    };
  };

  # Enable building for aarch64
  boot.binfmt.emulatedSystems = [ "armv7l-linux" "aarch64-linux" ];

  services.gitlab-runner = {
    enable = true;
    concurrent = 16;

    services = {
      nix = with lib; {
        registrationConfigFile = "/var/gitlab-runner/secrets/runner.txt";
        dockerImage = "alpine";
	dockerVolumes = [
	  "/nix/store:/nix/store:ro"
	  "/nix/var/nix/db:/nix/var/nix/db:ro"
	  "/nix/var/nix/daemon-socket:/nix/var/nix/daemon-socket:ro"
	];
	dockerDisableCache = true;
	dockerExtraHosts = [
	  "docker-host:127.0.0.1"
	];
	preBuildScript = pkgs.writeScript "setup-container" ''
          mkdir -p -m 0755 /nix/var/log/nix/drvs
          mkdir -p -m 0755 /nix/var/nix/gcroots
          mkdir -p -m 0755 /nix/var/nix/profiles
          mkdir -p -m 0755 /nix/var/nix/temproots
          mkdir -p -m 0755 /nix/var/nix/userpool
          mkdir -p -m 1777 /nix/var/nix/gcroots/per-user
          mkdir -p -m 1777 /nix/var/nix/profiles/per-user
          mkdir -p -m 0755 /nix/var/nix/profiles/per-user/root
          mkdir -p -m 0700 "$HOME/.nix-defexpr"
          . ${pkgs.nix}/etc/profile.d/nix.sh
          ${pkgs.nix}/bin/nix-channel --add https://nixos.org/channels/nixos-22.05 nixpkgs
          ${pkgs.nix}/bin/nix-channel --update nixpkgs
          ${pkgs.nix}/bin/nix-env -i ${concatStringsSep " " (with pkgs; [
	    nixFlakes cacert git openssh skopeo
	  ])}
        '';
	environmentVariables = {
          ENV = "/etc/profile";
          USER = "root";
          NIX_REMOTE = "daemon";
          PATH = "/nix/var/nix/profiles/default/bin:/nix/var/nix/profiles/default/sbin:/bin:/sbin:/usr/bin:/usr/sbin";
          NIX_SSL_CERT_FILE = "/nix/var/nix/profiles/default/etc/ssl/certs/ca-bundle.crt";
        };
        tagList = [ "nix" ];
      };
    };
  };

  services.nginx = {
    enable = true;
    recommendedGzipSettings = true;
    recommendedOptimisation = true;
    recommendedProxySettings = true;
    recommendedTlsSettings = true;
    virtualHosts."git.eads.soe.ucsc.edu" = {
      enableACME = true;
      forceSSL = true;
      locations."/".proxyPass = "http://unix:/run/gitlab/gitlab-workhorse.socket";
    };
    virtualHosts."eads.soe.ucsc.edu" = {
      enableACME = true;
      forceSSL = true;
      locations."/".extraConfig = ''
        if ($content_type = application/grpc) {
          grpc_pass localhost:3002;
          break;
        }

        proxy_pass http://localhost:3001;
      '';
    };
    virtualHosts."docker.eads.soe.ucsc.edu" = {
      enableACME = true;
      forceSSL = true;
      basicAuthFile = "/var/nginx/secrets/docker-credentials.txt";
      locations."/".proxyPass = "http://localhost:5000";
    };
  };

}
