{ config, lib, pkgs, ... }:

{
  boot.initrd.availableKernelModules = [ "xhci_pci" "ahci" "megaraid_sas" "usbhid" "usb_storage" "sd_mod" ];
  boot.initrd.kernelModules = [ ];
  boot.kernelModules = [ "kvm-amd" ];
  boot.extraModulePackages = [ ];

  fileSystems."/" =
    { device = "system/fsroot";
      fsType = "zfs";
    };

  fileSystems."/var" =
    { device = "system/var";
      fsType = "zfs";
    };

  fileSystems."/nix" =
    { device = "system/nix";
      fsType = "zfs";
    };

  fileSystems."/data" =
    { device = "data/root";
      fsType = "zfs";
    };

  fileSystems."/data/postgres" =
    { device = "data/postgres";
      fsType = "zfs";
    };

  fileSystems."/var/lib/docker" =
    { device = "data/docker";
      fsType = "zfs";
    };

  fileSystems."/var/lib/docker-registry" =
    { device = "data/docker-registry";
      fsType = "zfs";
    };

  fileSystems."/efi" =
    { device = "/dev/disk/by-uuid/DA6C-5CA2";
      fsType = "vfat";
    };

  swapDevices = [ ];

  hardware.cpu.amd.updateMicrocode = true;
}
