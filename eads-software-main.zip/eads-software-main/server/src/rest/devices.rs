use std::collections::{BTreeMap, HashMap};

use axum::extract::{Path, Query};
use axum::Json;
use axum::{extract::Extension, http::StatusCode, response::IntoResponse};
use color_eyre::eyre;
use jwt::SignWithKey;
use serde_json::json;

use crate::db;
use crate::server_config::ServerConfig;
use crate::server_error::ServerError;

use super::auth_middleware::Auth;
use super::util;

#[tracing::instrument(skip(pool))]
pub async fn get_devices(
    Query(params): Query<HashMap<String, String>>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<()>> {
    if params.get("status") == Some(&"true".to_string()) {
        let devices = db::get_devices_with_status(&pool).await?;

        Ok((
            StatusCode::OK,
            Json(
                devices
                    .into_iter()
                    .map(|(device, status)| {
                        let mut out = serde_json::to_value(device)?;

                        json_patch::merge(&mut out, &json!({ "status": status }));

                        Ok(out)
                    })
                    .collect::<Result<serde_json::Value, eyre::Error>>()?,
            ),
        ))
    } else {
        let devices = db::get_devices(&pool).await?;

        Ok((StatusCode::OK, Json(serde_json::to_value(devices)?)))
    }
}

#[tracing::instrument(skip(pool))]
pub async fn get_device(
    Path(uuid): Path<uuid::Uuid>,
    Query(params): Query<HashMap<String, String>>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    let device = db::get_device(&pool, uuid)
        .await?
        .ok_or(ServerError::KnownError((
            StatusCode::NOT_FOUND,
            "Device not found.",
        )))?;

    let mut out = serde_json::to_value(device)?;

    if params.get("status") == Some(&"true".to_string()) {
        let status = db::get_device_status(&pool, uuid).await?;

        json_patch::merge(&mut out, &json!({ "status": status }));
    }

    Ok((StatusCode::OK, Json(out)))
}

#[tracing::instrument(skip(pool))]
pub async fn get_device_phases(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<()>> {
    let phases = db::get_device_phases_by_device(&pool, uuid).await?;

    Ok((StatusCode::OK, Json(phases)))
}

#[tracing::instrument(skip(pool))]
pub async fn get_device_streams(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<()>> {
    let streams = db::get_data_streams_by_device(&pool, uuid).await?;

    Ok((StatusCode::OK, Json(streams)))
}

#[tracing::instrument(skip(pool))]
pub async fn get_device_events(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<()>> {
    let events = db::get_events_by_device(&pool, uuid).await?;

    Ok((StatusCode::OK, Json(events)))
}

#[tracing::instrument(skip(pool))]
pub async fn get_device_latest_heartbeats(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<()>> {
    let heartbeats = db::get_latest_heartbeat_datapoints_for_device(&pool, uuid).await?;

    Ok((
        StatusCode::OK,
        Json(util::collect_heartbeat_data_points(heartbeats)),
    ))
}

#[tracing::instrument(skip(pool))]
pub async fn get_device_by_balena(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    match db::get_device_by_balena_uuid(&pool, uuid).await? {
        None => Err(ServerError::KnownError((
            StatusCode::NOT_FOUND,
            "Device not found.",
        ))),
        Some(x) => Ok((StatusCode::OK, Json(x))),
    }
}

#[tracing::instrument(skip(pool, _user, perms))]
pub async fn create_device(
    Auth(_user, perms): Auth,
    axum::Json(payload): axum::Json<db::CreateDevice>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    perms.assert_has("provision")?;

    let uuid = db::create_device(&pool, payload).await?;

    Ok((StatusCode::OK, Json(json!({ "uuid": uuid }))))
}

#[tracing::instrument(skip(config, pool, _user, perms))]
pub async fn get_device_token(
    Auth(_user, perms): Auth,
    Path(uuid): Path<uuid::Uuid>,
    Extension(config): Extension<ServerConfig>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    perms.assert_has("provision")?;

    let device = db::get_device(&pool, uuid)
        .await?
        .ok_or(ServerError::KnownError((
            StatusCode::NOT_FOUND,
            "Device not found.",
        )))?;

    let mut claims = BTreeMap::new();
    claims.insert("device_id", device.uuid);
    let token_str = claims.sign_with_key(&config.jwt_key)?;

    Ok((StatusCode::OK, Json(json!({ "token": token_str }))))
}
