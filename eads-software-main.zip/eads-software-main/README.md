# eads-api

This repository contains the code for the Seads API server and client.

## Dependencies

The following are required for building and running the Seads API Server:
- `cargo`
- [`protoc`](https://grpc.io/docs/protoc-installation/) Protocol Buffer Compiler
- [`openssl`](https://www.openssl.org/) library
- [`sqlx`](https://github.com/launchbadge/sqlx) Rust SQL Toolkit migration management tool
- PostgreSQL

## Building

To build the server and client applications in debug mode, run

```sh
cargo build
```

This will download all required Rust package dependencies and produce binaries for each target application.

When building for production environments, the applications should be built in release mode to strip out unneeded debug info. To build in release mode, run

```sh
cargo build --release
```

To optionally build the sampling mocker application for local client development, the `sampling-mocker` flag can be supplied to the build command

```sh
cargo build --features sampling-mocker
```

More information on the sampling mocker application is available in the [sampling mocker section](#local-development-using-the-sampling-mocker)

## Running the API server

To run the server, either run the `seads-api-server` binary in the `target/<profile>` directory or run

```sh
cargo run --bin seads-api-server
```

The server requires that some environment variables are present, which are described in the following section.

### Environment Variables

The following environment variables are required to run the API server:

| Name                  | Example value                           | Description                                                                                                                     |
|-----------------------|-----------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|
| `DATABASE_URL`        | `postgres://user:pass@host`             | PostgreSQL database URI                                                                                                         |
| `JWT_AUTH_SECRET_KEY` | `ZXhhbXBsZSBzZWNyZXQ=`                  | Base64 encoded secret key used to generate JWTs for device authentication. This can be generated with `openssl rand -base64 32` |
| `AUTH0_URI`           | `https://my-app.us.auth0.com`           | Auth0 domain. See [Auth0 setup](#auth0-setup) for details.                                                                      |
| `AUTH0_CLIENT_ID`     | N/A                                     | Auth0 client ID. See  [Auth0 setup](#auth0-setup)  for details.                                                                 |
| `AUTH0_CLIENT_SECRET` | N/A                                     | Auth0 client secret. See  [Auth0 setup](#auth0-setup)  for details.                                                             |
| `AUTH0_REDIRECT_URI`  | `http://localhost:5001/oauth/authorize` | Auth0 callback URI. See  [Auth0 setup](#auth0-setup)  for details.                                                              |
| `AUTH0_AUDIENCE`      | `http://localhost:5001`                 | Auth0 API access token audience. See  [Auth0 setup](#auth0-setup)  for details.                                                 |

### Database Setup

On the first startup of the application, SQLx does not have any information about what migrations have been run.

To initialize the database and setup SQLx migrations metadata, run

```sh
sqlx migrate run
```

After this initial migration SQLx will have the necessary information to automatically perform any outstanding migrations on startup.

### Auth0 Setup

This section describes the steps to setup the [Auth0](https://auth0.com) user management service.

#### Create an Application

In the Auth0 web interface, navigate to the "Applications" page and click "Create Application". Select "Regular Web Applications" as the application type and create the application.

Navigating into the newly created app's "Settings" page, there will be basic information about the application. Copy the "Domain", "Client ID", and "Client Secret" fields, saving them as the environment variables `AUTH0_URI`, `AUTH0_CLIENT_ID`, and `AUTH0_CLIENT_SECRET`, respectively.

Scroll down to the "Application URIs" section and add your server's redirect URI to the "Allowed Callback URLs" list. This will be the value of `AUTH0_REDIRECT_URI` and should be of the form `http(s)://<server host>/oauth/authorize`.

#### Create an API

Now, navigate to the "APIs" page and click "Create API". The identifier should be your application's URI. This will be your `AUTH0_AUDIENCE` and should be of the form `http(s)://<server host>`. Select "RS256" for the signing algorithm and create the API.

#### Create Scopes

In the API you just created navigate to the "Permissions" page and add the following scopes.

| Scope                 | Description                                                |
|-----------------------|------------------------------------------------------------|
| `read:calibrations`   |                                                            |
| `write:calibrations`  |                                                            |
| `read:devices`        |                                                            |
| `write:devices`       |                                                            |
| `read:data_streams`   |                                                            |
| `write:data_streams`  |                                                            |
| `read:device_phases`  |                                                            |
| `write:device_phases` |                                                            |
| `read:channels`       |                                                            |
| `write:channels`      |                                                            |
| `read:device_tokens`  | Create device tokens, allowing for provisioning of devices |

## Running the API client

To run the client, either run the `seads-api-client` binary in the `target/<profile>` directory or run

```sh
cargo run --bin seads-api-client
```

The client requires that some environment variables are present, which are described in the following section.

### Environment Variables

The following environment variables are required to run the client:

| Name                 | Example value                                                                                                                                                                                    | Description                                                                                                                       |
|----------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------|
| `SEADS_API_URI`      | `http://localhost:5001`                                                                                                                                                                          | URI of the Seads API server                                                                                                       |
| `SEADS_CLIENT_TOKEN` | <details><summary>Example token</summary> <p> `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkZXZpY2VfaWQiOiJleGFtcGxlIGRlaXZjZSB1dWlkIn0.Waezk061w_ynZswOeKrZ8EMRf572tFs_5evuXbVsNzw` </p> </details> | JWT used for device authentication. Can be generated by issuing a GET request to `SEADS_API_URI/v1/devices/<device uuid>/token`.` |

### Local development using the sampling mocker

To facilitate local development of the client application, there is a `sampling` service mocker which will create and publish to the samples and offset socket similarly to how a normal device would.

To use the mocker, run

```sh
cargo run --bin seads-api-sampling-mocker --features="sampling-mocker"
```

The additional features flag is needed to enable this binary since it is not built by default.

This will open the samples and offset Unix sockets and wait for connections from client applications.

**Currently, only the samples socket is supported**
