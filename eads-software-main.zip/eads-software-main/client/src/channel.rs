use tokio::sync::broadcast;
use tokio_stream::wrappers::BroadcastStream;

use crate::{settings::ChannelSettings, device::Sample};

const CHANNEL_BUFFER_LENGTH: usize = 32768;

pub struct Channel {
    settings: ChannelSettings,

    bus: broadcast::Sender<Sample>,
    // We must keep one receiver open to keep the broadcast open to ensure sending is always valid.
    // This induces a memory overhead of (sizeof(Sample) * CHANNEL_BUFFER_LENGTH) and messages
    // after this will simply overwrite old values.
    bus_rx: broadcast::Receiver<Sample>,
}

impl Channel {
    pub fn new(settings: ChannelSettings) -> Channel {
        let (bus, bus_rx) = broadcast::channel(CHANNEL_BUFFER_LENGTH);

        Channel {
            settings,
            bus,
            bus_rx,
        }
    }

    pub fn uuid(&self) -> &str {
        &self.settings.uuid
    }

    pub fn frequency(&self) -> f64 {
        self.settings.frequency
    }

    pub fn adc_channel(&self) -> usize {
        self.settings.calibration.adc_channel()
    }

    pub fn subscribe(&self) -> BroadcastStream<Sample> {
        BroadcastStream::new(self.bus.subscribe())
    }

    pub fn add_raw_sample(
        &self,
        timestamp: u64,
        value: u32,
    ) -> Result<(), broadcast::error::SendError<Sample>> {
        let value = self.settings.calibration.apply(value);

        self.bus.send(Sample { timestamp, value }).map(|_| ())
    }
}
