use geozero::wkb;
use sqlx::types::time;

#[derive(Debug, serde::Serialize, serde::Deserialize, sqlx::Type)]
#[serde(rename_all = "snake_case")]
#[sqlx(type_name = "event_status", rename_all = "snake_case")]
pub enum EventStatus {
    Running,
    Complete,
}

#[derive(Debug, serde::Serialize, serde::Deserialize, sqlx::Type)]
#[serde(rename_all = "snake_case")]
#[sqlx(type_name = "event_type", rename_all = "snake_case")]
pub enum EventType {
    DeviceTriggered,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct Event {
    pub uuid: uuid::Uuid,
    pub status: EventStatus,
    pub r#type: EventType,
    pub start_time: u64,
    pub end_time: Option<u64>,
}

#[tracing::instrument(skip(pool))]
pub async fn create_event(pool: &sqlx::Pool<sqlx::Postgres>, event: Event) -> sqlx::Result<i64> {
    sqlx::query!(
        "INSERT INTO events (
            uuid, \
            status, \
            type, \
            start_time, \
            end_time) \
        VALUES ($1, $2, $3, $4, $5) \
        RETURNING (id)",
        event.uuid,
        event.status as EventStatus,
        event.r#type as EventType,
        super::from_unix_timestamp_micros(event.start_time),
        event.end_time.map(super::from_unix_timestamp_micros),
    )
    .fetch_one(pool)
    .await
    .map(|row| Ok(row.id))?
}

#[tracing::instrument(skip(pool))]
pub async fn set_event_status(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
    status: EventStatus,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "UPDATE events
        SET status=$1
        WHERE uuid=$2",
        status as EventStatus,
        event,
    )
    .execute(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn set_event_end_time(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
    end_time: u64,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "UPDATE events
        SET end_time=$1
        WHERE uuid=$2",
        super::from_unix_timestamp_micros(end_time),
        event,
    )
    .execute(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn set_event_initial_radius(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
    time: u64,
    center: geo_types::Point<f64>,
    radius: f64,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "INSERT INTO event_locations ( \
            event, \
            time, \
            geo \
        ) VALUES ( \
            (SELECT id FROM events WHERE uuid=$1), \
            $2, \
            ST_Buffer($3, $4) \
        )",
        event,
        super::from_unix_timestamp_micros(time),
        wkb::Encode(geo_types::Geometry::Point(center)) as _,
        radius,
    )
    .execute(pool)
    .await
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct EventLocation {
    pub event: uuid::Uuid,
    pub time: u64,
    pub geojson: String,
}

#[tracing::instrument(skip(pool))]
pub async fn get_event_locations(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
) -> sqlx::Result<Vec<EventLocation>> {
    sqlx::query!(
        "SELECT
            (SELECT uuid FROM events where id=event) AS event,
            time,
            ST_AsGeoJSON(geo) AS geojson
        FROM event_locations
        WHERE event=(SELECT id FROM events WHERE uuid=$1)",
        event,
    )
    .fetch_all(pool)
    .await
    .map(|x| {
        x.into_iter()
            .filter_map(|rec| {
                Some(EventLocation {
                    event: rec.event?,
                    time: super::to_unix_timestamp_micros(rec.time),
                    geojson: rec.geojson?,
                })
            })
            .collect()
    })
}

#[tracing::instrument(skip(pool))]
pub async fn get_latest_event_location(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
) -> sqlx::Result<Option<EventLocation>> {
    sqlx::query!(
        "SELECT
            (SELECT uuid FROM events where id=event) AS event,
            time,
            ST_AsGeoJSON(geo) AS geojson
        FROM event_locations
        WHERE event=(SELECT id FROM events WHERE uuid=$1)
        ORDER BY time DESC
        LIMIT 1",
        event,
    )
    .fetch_optional(pool)
    .await
    .map(|x| {
        x.and_then(|rec| {
            Some(EventLocation {
                event: rec.event?,
                time: super::to_unix_timestamp_micros(rec.time),
                geojson: rec.geojson?,
            })
        })
    })
}

// Struct used to decode device objects from the db
struct EventRec {
    pub uuid: uuid::Uuid,
    pub status: EventStatus,
    pub r#type: EventType,
    pub start_time: time::PrimitiveDateTime,
    pub end_time: Option<time::PrimitiveDateTime>,
}

#[tracing::instrument(skip(pool))]
pub async fn get_event(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
) -> sqlx::Result<Option<Event>> {
    sqlx::query_as!(
        EventRec,
        "SELECT
            events.uuid AS uuid, \
            events.status AS \"status!: _\", \
            events.type AS \"type!: _\", \
            events.start_time AS start_time, \
            events.end_time AS end_time \
        FROM events \
        WHERE uuid = $1",
        event
    )
    .fetch_optional(pool)
    .await
    .map(|x| {
        x.map(|row| Event {
            uuid: row.uuid,
            status: row.status,
            r#type: row.r#type,
            start_time: super::to_unix_timestamp_micros(row.start_time),
            end_time: row.end_time.map(super::to_unix_timestamp_micros),
        })
    })
}

#[tracing::instrument(skip(pool))]
pub async fn get_events(pool: &sqlx::Pool<sqlx::Postgres>) -> sqlx::Result<Vec<Event>> {
    sqlx::query_as!(
        EventRec,
        "SELECT
            events.uuid AS uuid, \
            events.status AS \"status!: _\", \
            events.type AS \"type!: _\", \
            events.start_time AS start_time, \
            events.end_time AS end_time \
        FROM events",
    )
    .fetch_all(pool)
    .await
    .map(|x| {
        x.into_iter()
            .map(|row| Event {
                uuid: row.uuid,
                status: row.status,
                r#type: row.r#type,
                start_time: super::to_unix_timestamp_micros(row.start_time),
                end_time: row.end_time.map(super::to_unix_timestamp_micros),
            })
            .collect()
    })
}

#[tracing::instrument(skip(pool))]
pub async fn add_phase_to_event(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
    phase: uuid::Uuid,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "INSERT INTO event_phases (
            event, \
            phase \
        ) VALUES ( \
            (SELECT id FROM events WHERE uuid=$1), \
            (SELECT id FROM device_phases WHERE uuid=$2) \
        )",
        event,
        phase
    )
    .execute(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn remove_phase_from_event(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
    phase: uuid::Uuid,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "DELETE FROM event_phases
        WHERE event=(SELECT id FROM events WHERE uuid=$1) \
        AND phase=(SELECT id FROM device_phases WHERE uuid=$2)",
        event,
        phase
    )
    .execute(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn remove_phase_from_all_events(
    pool: &sqlx::Pool<sqlx::Postgres>,
    phase: uuid::Uuid,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "DELETE FROM event_phases
        WHERE phase=(SELECT id FROM device_phases WHERE uuid=$1)",
        phase
    )
    .execute(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn get_events_by_phase(
    pool: &sqlx::Pool<sqlx::Postgres>,
    phase: uuid::Uuid,
) -> sqlx::Result<Vec<Event>> {
    sqlx::query_as!(
        EventRec,
        "SELECT
            events.uuid AS uuid, \
            events.status AS \"status!: _\", \
            events.type AS \"type!: _\", \
            events.start_time AS start_time, \
            events.end_time AS end_time \
        FROM device_phases \
        INNER JOIN event_phases \
            ON event_phases.phase = device_phases.id \
        INNER JOIN events \
            ON event_phases.event = events.id \
        WHERE device_phases.uuid = $1",
        phase
    )
    .fetch_optional(pool)
    .await
    .map(|x| {
        x.into_iter()
            .map(|row| Event {
                uuid: row.uuid,
                status: row.status,
                r#type: row.r#type,
                start_time: super::to_unix_timestamp_micros(row.start_time),
                end_time: row.end_time.map(super::to_unix_timestamp_micros),
            })
            .collect()
    })
}

#[tracing::instrument(skip(pool))]
pub async fn get_event_phases(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
) -> sqlx::Result<Vec<uuid::Uuid>> {
    sqlx::query!(
        "SELECT
            device_phases.uuid AS uuid
        FROM event_phases
        INNER JOIN device_phases
            ON device_phases.id = event_phases.phase
        WHERE event_phases.event = (SELECT id FROM events WHERE uuid=$1)",
        event,
    )
    .fetch_all(pool)
    .await
    .map(|x| x.into_iter().filter_map(|row| row.uuid).collect())
}

#[tracing::instrument(skip(pool))]
pub async fn add_stream_to_event(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
    stream: uuid::Uuid,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "INSERT INTO event_streams (
            event, \
            stream \
        ) VALUES ( \
            (SELECT id FROM events WHERE uuid=$1), \
            (SELECT id FROM data_streams WHERE uuid=$2) \
        )",
        event,
        stream
    )
    .execute(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn get_event_streams(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
) -> sqlx::Result<Vec<uuid::Uuid>> {
    sqlx::query!(
        "SELECT
            data_streams.uuid AS uuid
        FROM event_streams
        INNER JOIN data_streams
            ON data_streams.id = event_streams.stream
        WHERE event_streams.event = (SELECT id FROM events WHERE uuid=$1)",
        event,
    )
    .fetch_all(pool)
    .await
    .map(|x| x.into_iter().filter_map(|row| row.uuid).collect())
}

#[tracing::instrument(skip(pool))]
pub async fn get_running_events(pool: &sqlx::Pool<sqlx::Postgres>) -> sqlx::Result<Vec<Event>> {
    sqlx::query_as!(
        EventRec,
        "SELECT
            events.uuid AS uuid, \
            events.status AS \"status!: _\", \
            events.type AS \"type!: _\", \
            events.start_time AS start_time, \
            events.end_time AS end_time \
        FROM events \
        WHERE events.status = 'running'",
    )
    .fetch_all(pool)
    .await
    .map(|x| {
        x.into_iter()
            .map(|row| Event {
                uuid: row.uuid,
                status: row.status,
                r#type: row.r#type,
                start_time: super::to_unix_timestamp_micros(row.start_time),
                end_time: row.end_time.map(super::to_unix_timestamp_micros),
            })
            .collect()
    })
}

#[tracing::instrument(skip(pool))]
pub async fn get_running_events_overlapping_device(
    pool: &sqlx::Pool<sqlx::Postgres>,
    device: uuid::Uuid,
) -> sqlx::Result<Vec<Event>> {
    sqlx::query_as!(
        EventRec,
        "SELECT
            events.uuid AS uuid, \
            events.status AS \"status!: _\", \
            events.type AS \"type!: _\", \
            events.start_time AS start_time, \
            events.end_time AS end_time \
        FROM devices \
        INNER JOIN event_locations \
            ON ST_Crosses(event_locations.geo, devices.location::geometry)
        INNER JOIN events \
            ON events.id = event_locations.event \
            AND events.status = 'running' \
        WHERE devices.uuid=$1",
        device
    )
    .fetch_all(pool)
    .await
    .map(|x| {
        x.into_iter()
            .map(|row| Event {
                uuid: row.uuid,
                status: row.status,
                r#type: row.r#type,
                start_time: super::to_unix_timestamp_micros(row.start_time),
                end_time: row.end_time.map(super::to_unix_timestamp_micros),
            })
            .collect()
    })
}

#[tracing::instrument(skip(pool))]
pub async fn get_events_by_device(
    pool: &sqlx::Pool<sqlx::Postgres>,
    device: uuid::Uuid,
) -> sqlx::Result<Vec<Event>> {
    sqlx::query_as!(
        EventRec,
        "SELECT DISTINCT
            events.uuid AS uuid, \
            events.status AS \"status!: _\", \
            events.type AS \"type!: _\", \
            events.start_time AS start_time, \
            events.end_time AS end_time \
        FROM devices \
        INNER JOIN data_streams
            ON data_streams.device = devices.id
        INNER JOIN event_streams
            ON event_streams.stream = data_streams.id
        INNER JOIN events
            ON events.id = event_streams.event
        WHERE devices.uuid = $1",
        device
    )
    .fetch_all(pool)
    .await
    .map(|x| {
        x.into_iter()
            .map(|row| Event {
                uuid: row.uuid,
                status: row.status,
                r#type: row.r#type,
                start_time: super::to_unix_timestamp_micros(row.start_time),
                end_time: row.end_time.map(super::to_unix_timestamp_micros),
            })
            .collect()
    })
}

#[tracing::instrument(skip(pool))]
pub async fn get_running_events_by_device(
    pool: &sqlx::Pool<sqlx::Postgres>,
    device: uuid::Uuid,
) -> sqlx::Result<Vec<Event>> {
    sqlx::query_as!(
        EventRec,
        "SELECT DISTINCT
            events.uuid AS uuid, \
            events.status AS \"status!: _\", \
            events.type AS \"type!: _\", \
            events.start_time AS start_time, \
            events.end_time AS end_time \
        FROM devices \
        INNER JOIN data_streams
            ON data_streams.device = devices.id
        INNER JOIN event_streams
            ON event_streams.stream = data_streams.id
        INNER JOIN events
            ON events.id = event_streams.event
            AND events.status = 'running'
        WHERE devices.uuid = $1",
        device
    )
    .fetch_all(pool)
    .await
    .map(|x| {
        x.into_iter()
            .map(|row| Event {
                uuid: row.uuid,
                status: row.status,
                r#type: row.r#type,
                start_time: super::to_unix_timestamp_micros(row.start_time),
                end_time: row.end_time.map(super::to_unix_timestamp_micros),
            })
            .collect()
    })
}

#[derive(Debug, serde::Serialize, serde::Deserialize, sqlx::Type)]
#[serde(rename_all = "snake_case")]
#[sqlx(type_name = "event_message_type", rename_all = "snake_case")]
pub enum EventMessageType {
    DeviceOnline,
    DeviceOffline,
    PhaseTrigger,
    PhaseUntrigger,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct EventMessage {
    pub time: u64,
    pub event: uuid::Uuid,
    pub r#type: EventMessageType,
    pub data: Option<serde_json::Value>,
}

#[tracing::instrument(skip(pool))]
pub async fn insert_event_message(
    pool: &sqlx::Pool<sqlx::Postgres>,
    message: EventMessage,
) -> sqlx::Result<i64> {
    sqlx::query!(
        "INSERT INTO event_messages ( \
            time, \
            event, \
            type, \
            data \
        ) VALUES ( \
            $1, \
            (SELECT id FROM events WHERE uuid=$2), \
            $3, \
            $4 \
        ) RETURNING (id)",
        super::from_unix_timestamp_micros(message.time),
        message.event,
        message.r#type as EventMessageType,
        message.data,
    )
    .fetch_one(pool)
    .await
    .map(|row| Ok(row.id))?
}

pub struct EventMessageRec {
    pub time: time::PrimitiveDateTime,
    pub r#type: EventMessageType,
    pub data: Option<serde_json::Value>,
}

#[tracing::instrument(skip(pool))]
pub async fn get_event_messages(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
) -> sqlx::Result<Vec<EventMessage>> {
    sqlx::query_as!(
        EventMessageRec,
        "SELECT
            time, \
            type AS \"type!: _\", \
            data \
        FROM event_messages
        WHERE event=(SELECT id FROM events WHERE uuid=$1)",
        event
    )
    .fetch_all(pool)
    .await
    .map(|x| {
        x.into_iter()
            .map(|rec| {
                Ok(EventMessage {
                    time: super::to_unix_timestamp_micros(rec.time),
                    event,
                    r#type: rec.r#type,
                    data: rec.data,
                })
            })
            .collect()
    })?
}
