use std::{collections::BTreeMap, env};

use color_eyre::eyre;
use hmac::{Hmac, Mac};
use jwt::VerifyWithKey;
use sha2::Sha256;
use tonic::{Request, Status};

pub struct AuthSettings {
    jwt_key: Hmac<Sha256>,
}

impl AuthSettings {
    pub fn new() -> eyre::Result<AuthSettings> {
        let key = Hmac::new_from_slice(env::var("JWT_AUTH_SECRET_KEY")?.as_bytes())?;

        Ok(AuthSettings { jwt_key: key })
    }
}

// TODO: This should not be able to be constructed outside of this module.
pub struct Auth {
    pub device_id: uuid::Uuid,
}

pub fn auth_interceptor(
    settings: AuthSettings,
) -> impl Fn(Request<()>) -> Result<Request<()>, Status> {
    move |mut req: Request<()>| {
        let auth_header = req
            .metadata()
            .get("Authorization")
            .ok_or_else(|| Status::unauthenticated("Missing 'Authorization' header."))
            .and_then(|x| {
                x.to_str()
                    .map_err(|_| Status::unauthenticated("Invalid ASCII in token."))
            })?;

        // Parse the token out of the Bearer format
        let token = parse_authorization_header(auth_header)
            .ok_or_else(|| Status::unauthenticated("Invalid 'Authorization' header."))?;

        // Extract the claims from the token
        let claims: BTreeMap<String, String> = token
            .verify_with_key(&settings.jwt_key)
            .map_err(|_| Status::unauthenticated("Invalid token."))?;

        // Now that we know the token is valid we can set the device id
        let device_id = claims
            .get("device_id")
            .ok_or_else(|| Status::internal("Token is missing 'device_id' field."))?;

        let device_uuid_parsed = uuid::Uuid::parse_str(device_id)
            .map_err(|_| Status::internal("Token 'device_id' field is not a valid UUID."))?;

        // Add the Auth extension to this connection
        req.extensions_mut().insert(Auth {
            device_id: device_uuid_parsed,
        });

        // Accept the request
        Ok(req)
    }
}

/// Parse an authorization header field of the form `Bearer <token>`, returning
/// the token on success.
fn parse_authorization_header(header: &str) -> Option<&str> {
    header.strip_prefix("Bearer ")
}
