from . import calibration
from . import database

class TestCalibration(calibration.CalibrationSequence):
    def __init__(self):
        super().__init__()

        self.channels["waveform"] = calibration.Channel(
            type="test",
            computed=True,
            units=calibration.ChannelUnits.VOLTS,
            frequency=80,
            calibration=calibration.Calibration(type="this is test", data={})
        )

    def identifier(self):
        return "Test Calibration"

    def perform(self, scope, device):
        #
        # Initialize scope
        #
        scope.write(":WGEN:OUTPut OFF")
        scope.write(":STOP")
        
        #####################################################
        
        scope.write(":WAVeform:FORMat WORD")
        scope.write(":WAVeform:BYTeorder LSBFirst")
        scope.write(":WAVeform:UNSigned OFF")
        scope.write(":ACQuire:TYPE NORmal")
        
        #####################################################
        
        scope.write(":WAVeform:SOURce CHANnel 3")
        scope.write(":WAVeform:POINts:MODE NORmal")
        scope.write(":WAVeform:POINts 8000")
        
        print(scope.query(":WAVeform:POINts?"))
        
        scope.write(":TIMebase:MODE MAIN")
        
        #######################################################
                    
        y_increment = float(scope.query(":WAVeform:YINCrement?"))
        y_origin = float(scope.query(":WAVeform:YORigin?"))
        y_reference = float(scope.query(":WAVeform:YREFerence?"))
        
        x_increment = float(scope.query(":WAVeform:XINCrement?"))
        x_origin = float(scope.query(":WAVeform:XORigin?"))
        x_reference = float(scope.query(":WAVeform:XREFerence?"))
                    
        ############################################################ 
        
        scope.write(":TRIGger:MODE EDGE") 
        scope.write(":TRIGger:LEVel .5")
        scope.write(":TRIGger:EDGE:SOURce WGEN")
        
        scope.write(":WGEN:FUNCtion:PULSe")
        scope.write(":WGEN:FUNCtion:PULSe:WIDTh .250")
        scope.write(":WGEN:PERiod 3")
        
        scope.write(":SINGle")
        scope.write(":WGEN:OUTPut ON")
        
        #########################################################
        scope.write(":DIGitize")
        
        waveform = scope.query_binary_values(":WAVeform:DATA?", datatype='h', container = np.array)
        
        scope.write(":WAVeform:SOURce CHANnel 1")
        wave2 = scope.query_binary_values(":WAVeform:DATA?", datatype='h', container = np.array)
        
        plt.figure(1)
        plt.plot(waveform)
        plt.show()
        
        plt.figure(2)
        plt.plot(wave2)
        plt.show()

database.calibrations.register_calibration(TestCalibration())
