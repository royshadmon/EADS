use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use color_eyre::Report;
use tracing::error;

pub enum ServerError<T> {
    InternalError(Report),
    KnownError(T),
}

impl<E, T> From<E> for ServerError<T>
where
    E: Into<Report>,
{
    fn from(err: E) -> Self {
        ServerError::InternalError(err.into())
    }
}

impl<T> IntoResponse for ServerError<T>
where
    T: IntoResponse,
{
    fn into_response(self) -> Response {
        match self {
            ServerError::InternalError(error) => {
                error!(error = %error);
                (StatusCode::INTERNAL_SERVER_ERROR, "Something went wrong!").into_response()
            }
            ServerError::KnownError(res) => res.into_response(),
        }
    }
}
