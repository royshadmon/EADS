import React from "react";
import useSWR from "swr";

import { API_URI } from "../constants.js";

import { Link } from "react-router-dom";
import { Container, Row, Col, Card, Table, Badge, Nav, Tabs, Tab, OverlayTrigger, Tooltip } from 'react-bootstrap';

import DeviceMap from '../components/devicemap.js';
import DevicesList from '../components/deviceslist.js';

const fetcher = (url) => fetch(url, { credentials: 'include' }).then((res) => res.json());

export default function Devices() {
  const { data, error } = useSWR(
    `${API_URI}/v1/devices?status=true`,
    fetcher
  );

  if (error) return "An error has occurred.";
  if (!data) return "Loading...";

  return <Container>
    <Row>
      <Col>
        <Tab.Container defaultActiveKey="map">
          <Card>
            <Card.Header>
              <Nav variant="tabs">
                <Nav.Item>
                  <Nav.Link eventKey="map" style={{ cursor: 'pointer' }}>Map</Nav.Link>
                </Nav.Item>
              </Nav>
            </Card.Header>
            <Card.Body>
              <Tab.Content>
                <Tab.Pane eventKey="map">
                  <DeviceMap devices={ data } center={[-122.063313, 36.998345]}/>
                </Tab.Pane>
                <Tab.Pane eventKey="status">
                </Tab.Pane>
              </Tab.Content>
            </Card.Body>
          </Card>
        </Tab.Container>
      </Col>
    </Row>
    <Row className="mt-3">
      <Col>
        <Card>
          <Card.Body>
            <DevicesList data={ data } />
          </Card.Body>
        </Card>
      </Col>
    </Row>
  </Container>;
}
