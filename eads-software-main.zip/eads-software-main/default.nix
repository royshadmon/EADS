{ pkgs, cargo2nix }:
rec {
  rustPkgs = pkgs.rustBuilder.makePackageSet {
    rustVersion = "1.75.0";
    packageFun = import ./Cargo.nix;
    rootFeatures = [ "eads-client/rpi" ];
  };

  webConfig = import ./web-config.nix;

  eads-server = (rustPkgs.workspace.eads-server {}).bin;
  eads-server-container = pkgs.dockerTools.buildImage {
    name = "eads-server";
    contents = [ pkgs.cacert ];
    config = {
      Cmd = ["${(rustPkgs.workspace.eads-server {}).bin}/bin/eads-server"];
    };
  };

  eads-client = (rustPkgs.workspace.eads-client {}).bin;
  eads-client-container = pkgs.dockerTools.buildImage {
    name = "eads-client";
    contents = [ pkgs.cacert ];
    config = {
      Cmd = ["${eads-client}/bin/eads-client"];
    };
  };

  eads-mocker = (rustPkgs.workspace.eads-mocker {}).bin;

  eads-web = pkgs.mkYarnPackage {
    name = "eads-web";
    src = ./web;

    packageJSON = ./web/package.json;
    yarnLock = ./web/yarn.lock;
    yarnNix = ./web/yarn.nix;

    extraBuildInputs = with pkgs; [ esbuild ];


    buildPhase = ''
      export REACT_APP_CONTACT_EMAIL=${webConfig.REACT_APP_CONTACT_EMAIL};
      export REACT_APP_API_URI=${webConfig.REACT_APP_API_URI};
      export REACT_APP_MAPBOX_ACCESS_TOKEN=${webConfig.REACT_APP_MAPBOX_ACCESS_TOKEN};

      pushd deps/$pname
      make build-release
      popd
    '';
    installPhase = ''
      mkdir -p $out
      cp -r deps/$pname/build $out
    '';
    distPhase = ''

    '';
  };
  eads-web-config = pkgs.writeTextFile {
    name = "eads-web-config";
    text = ''
      error_log /dev/stdout info;

      user root;

      events {}

      http {
        access_log /dev/stdout;

        server {
          listen 80;

          location /v1 {
            proxy_pass http://localhost:5001;
          }
          location /oauth {
            proxy_pass http://localhost:5001;
          }

          location /static {
            include ${pkgs.nginx}/conf/mime.types;

            root ${eads-web}/build;
          }

          location / {
            root ${eads-web}/build;
            index index.html;
            try_files $uri $uri/ /index.html;
          }

          add_header Last-Modified "";
          if_modified_since off;
          etag off;
        }

        ## From nixpkgs recommendedOptimization
        # optimisation
        sendfile on;
        tcp_nopush on;
        tcp_nodelay on;
        keepalive_timeout 65;

        ## From nixpkgs recommendedGzipSettings
        gzip on;
        gzip_proxied any;
        gzip_comp_level 5;
        gzip_types
          application/atom+xml
          application/javascript
          application/json
          application/xml
          application/xml+rss
          image/svg+xml
          text/css
          text/javascript
          text/plain
          text/xml;
        gzip_vary on;
      }
    '';
  };
  eads-web-container = pkgs.dockerTools.buildImage {
    name = "eads-web";
    contents = [ pkgs.cacert ];

    runAsRoot = ''
      ${pkgs.dockerTools.shadowSetup}

      mkdir -p /var/log/nginx
      mkdir -p /var/cache/nginx
    '';
    config = {
      Cmd = ["${pkgs.nginx}/bin/nginx" "-c" "${eads-web-config}" "-g" "daemon off;"];
    };
  };
}
