{ pkgs, ... }:
rec {
  eads-chrony-config = pkgs.writeTextFile {
    name = "eads-chrony-config";
    text = builtins.readFile ./chrony.conf;
  };

  eads-chrony-start = pkgs.writeScriptBin "eads-chrony-start"
    ''
      #!${pkgs.bash}/bin/sh

      ${pkgs.coreutils}/bin/rm -f /var/run/chrony/chronyd.pid
      ${pkgs.chrony}/bin/chronyd -d -x -f ${eads-chrony-config}
    '';

  eads-chrony-container = pkgs.dockerTools.buildImage {
    name = "eads-chrony";

    runAsRoot = ''
      ${pkgs.dockerTools.shadowSetup}
    '';

    config = {
      Cmd = ["${eads-chrony-start}/bin/eads-chrony-start"];
    };
  };
}
