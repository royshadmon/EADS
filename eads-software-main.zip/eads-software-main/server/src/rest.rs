use axum::{extract, response::IntoResponse, routing, Router};
use reqwest::StatusCode;

use crate::server_config::ServerConfig;

pub mod auth0;
mod auth_middleware;
mod calibrations;
mod channels;
mod data_streams;
mod device_phases;
mod devices;
mod events;
mod register;
mod util;

pub fn make_router(
    config: ServerConfig,
    sql_pool: sqlx::Pool<sqlx::Postgres>,
    reqwest_client: reqwest::Client,
) -> Router {
    axum::Router::new()
        .nest(
            "/oauth",
            axum::Router::new()
                .route("/login", routing::get(auth0::oauth_login))
                .route("/authorize", routing::get(auth0::oauth_authorize))
                .route("/logout", routing::get(auth0::oauth_logout)),
        )
        .nest(
            "/v1",
            axum::Router::new()
                .route("/ping", routing::get(ping))
                .route("/register/:id", routing::post(register::register_device))
                .route(
                    "/register/:id/status",
                    routing::get(register::get_registration_status),
                )
                .route(
                    "/register/:id/complete",
                    routing::post(register::complete_registration),
                )
                .route(
                    "/devices",
                    routing::get(devices::get_devices).post(devices::create_device),
                )
                .route("/devices/:id", routing::get(devices::get_device))
                .route(
                    "/devices/:id/phases",
                    routing::get(devices::get_device_phases),
                )
                .route(
                    "/devices/:id/streams",
                    routing::get(devices::get_device_streams),
                )
                .route(
                    "/devices/:id/events",
                    routing::get(devices::get_device_events),
                )
                .route(
                    "/devices/:id/heartbeats/latest",
                    routing::get(devices::get_device_latest_heartbeats),
                )
                .route(
                    "/devices/:id/token",
                    routing::get(devices::get_device_token),
                )
                .route(
                    "/devices/by-balena/:id",
                    routing::get(devices::get_device_by_balena),
                )
                .route(
                    "/calibrations",
                    routing::post(calibrations::create_calibration),
                )
                .route(
                    "/calibrations/:id",
                    routing::get(calibrations::get_calibration),
                )
                .route("/phases", routing::post(device_phases::create_device_phase))
                .route("/phases/:id", routing::get(device_phases::get_device_phase))
                .route("/channels", routing::post(channels::create_channel))
                .route("/channels/:id", routing::get(channels::get_channel))
                .route("/streams", routing::post(data_streams::create_data_stream))
                .route("/streams/:id", routing::get(data_streams::get_data_stream))
                .route(
                    "/streams/:id/heartbeats/latest",
                    routing::get(data_streams::get_data_stream_latest_heartbeat),
                )
                .route("/events", routing::get(events::get_events))
                .route("/events/:id", routing::get(events::get_event))
                .route(
                    "/events/:id/streams",
                    routing::get(events::get_event_streams),
                )
                .route("/events/:id/logs", routing::get(events::get_event_logs))
                .route(
                    "/events/:id/location",
                    routing::get(events::get_event_location),
                )
                .route("/events/:id/data", routing::get(events::get_event_data)),
        )
        .layer(extract::Extension(config))
        .layer(extract::Extension(sql_pool))
        .layer(extract::Extension(reqwest_client))
}

async fn ping() -> impl IntoResponse {
    (StatusCode::OK, "pong")
}
