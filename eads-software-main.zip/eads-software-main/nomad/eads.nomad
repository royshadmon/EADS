job "eads" {
  datacenters = ["dc1"]

  group "eads-group" {
    network {
      mode = "bridge"

      port "http" {
        static = 5001
        to = 5001
      }
    }

    task "eads-api" {
      driver = "docker"

      config {
        image = "localhost:5000/eads-server"
        ports = ["http"]
      }

      env {
        DATABASE_URL = "postgres://eads:eads@localhost/eads"
        AUTH0_URI = "https://dev-td4lg8lz.us.auth0.com"
        AUTH0_CLIENT_ID = "VRQVjEWy0ZGCzIhbWkZPFjVtXfEzbnae"
        AUTH0_CLIENT_SECRET = "O3ORYdHOu6xdfoGUDCWmOaBuwq7z_HhK2URsZyWweCrJI_vRNJsRjVpsAsO-24Bx"
        AUTH0_REDIRECT_URI = "http://seadsvault2.soe.ucsc.edu:5001/oauth/authorize"
        AUTH0_AUDIENCE = "http://seadsvault2.soe.ucsc.edu:5001"
        JWT_AUTH_SECRET_KEY = "shhthisisasecret"
      }
    }

    task "eads-db" {
      driver = "docker"

      config {
        image = "postgis/postgis:13-3.2-alpine"
      }

      # /var/lib/postgresql/data

      env {
        POSTGRES_USER = "eads"
        POSTGRES_PASSWORD = "eads"
        POSTGRES_DB = "eads"
      }
    }
  }
}
