use color_eyre::eyre;
use hmac::{Hmac, Mac};
use sha2::Sha256;
use std::{env, ops::Deref, sync::Arc};

pub struct ServerConfigInternal {
    pub postgres_uri: String,
    pub auth0_client_id: String,
    pub auth0_client_secret: String,
    pub auth0_uri: reqwest::Url,
    pub auth0_redirect_uri: String,
    pub auth0_audience: String,
    pub auth0_key_set: alcoholic_jwt::JWKS,
    pub jwt_key: Hmac<Sha256>,
}

#[derive(Clone)]
pub struct ServerConfig(Arc<ServerConfigInternal>);

impl Deref for ServerConfig {
    type Target = Arc<ServerConfigInternal>;

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

impl ServerConfig {
    pub async fn new(client: reqwest::Client) -> eyre::Result<ServerConfig> {
        let auth0_uri = reqwest::Url::parse(&env::var("AUTH0_URI")?)?;

        // Request the JWT signing keys from Auth0
        let jwks = client
            .get(auth0_uri.join("/.well-known/jwks.json")?)
            .send()
            .await?
            .json()
            .await?;

        Ok(ServerConfig(Arc::new(ServerConfigInternal {
            postgres_uri: env::var("DATABASE_URL")?,
            auth0_client_id: env::var("AUTH0_CLIENT_ID")?,
            auth0_client_secret: env::var("AUTH0_CLIENT_SECRET")?,
            auth0_uri,
            auth0_redirect_uri: env::var("AUTH0_REDIRECT_URI")?,
            auth0_audience: env::var("AUTH0_AUDIENCE")?,
            auth0_key_set: jwks,
            jwt_key: Hmac::new_from_slice(env::var("JWT_AUTH_SECRET_KEY")?.as_bytes())?,
        })))
    }
}
