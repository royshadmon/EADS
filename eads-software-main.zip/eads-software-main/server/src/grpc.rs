use std::{
    pin::Pin,
    sync::Arc,
    time::{Duration, SystemTime, UNIX_EPOCH},
};

use color_eyre::eyre;
use futures::{future::try_join_all, Stream};
use serde_json::json;
use tokio::sync::{broadcast, Mutex};
use tonic::{Request, Response, Status};
use tracing::{debug, error, info, warn};
use uuid::Uuid;

use crate::db;

use eads_proto::api::seads_api_server::{SeadsApi, SeadsApiServer};

use self::auth_interceptor::AuthSettings;

pub mod auth_interceptor;
pub mod device_settings;
mod util;

pub fn make_router(
    auth: AuthSettings,
    sql_pool: sqlx::Pool<sqlx::Postgres>,
) -> eyre::Result<tonic::transport::server::Router> {
    let reflection_service = tonic_reflection::server::Builder::configure()
        .register_encoded_file_descriptor_set(eads_proto::FILE_DESCRIPTOR_SET)
        .build()?;

    let grpc_auth_interceptor: Arc<
        dyn Fn(tonic::Request<()>) -> Result<tonic::Request<()>, tonic::Status>
            + Send
            + Sync
            + 'static,
    > = Arc::new(Box::new(auth_interceptor::auth_interceptor(auth)));

    Ok(tonic::transport::Server::builder()
        .add_service(reflection_service)
        .add_service(SeadsApiServer::with_interceptor(
            SeadsApiImpl::new(sql_pool),
            move |req| grpc_auth_interceptor(req),
        )))
}

#[derive(Debug, Clone)]
enum EventMessage {
    Start {
        uuid: Uuid,
        timestamp: u64,
        streams: Vec<Uuid>,
    },
    End {
        uuid: Uuid,
        timestamp: u64,
    },
    UpdateStreams {
        uuid: Uuid,
        streams: Vec<Uuid>,
    },
}

struct SeadsApiState {
    // Pub-sub system for requesting data streams from devices
    event_stream_tx: broadcast::Sender<EventMessage>,
    event_stream_rx: broadcast::Receiver<EventMessage>,
}

pub struct SeadsApiImpl {
    state: Arc<Mutex<SeadsApiState>>,
    sql_pool: sqlx::Pool<sqlx::Postgres>,
}

impl SeadsApiImpl {
    pub fn new(sql_pool: sqlx::Pool<sqlx::Postgres>) -> Self {
        let (event_stream_tx, event_stream_rx) = broadcast::channel(10);

        Self {
            state: Arc::new(Mutex::new(SeadsApiState {
                event_stream_tx,
                event_stream_rx,
            })),
            sql_pool,
        }
    }
}

#[tonic::async_trait]
impl SeadsApi for SeadsApiImpl {
    async fn get_device_settings(
        &self,
        req: tonic::Request<eads_proto::api::DeviceSettingsRequest>,
    ) -> Result<Response<eads_proto::api::DeviceSettingsResponse>, Status> {
        let auth = req.extensions().get::<auth_interceptor::Auth>().unwrap();

        let device = db::get_device(&self.sql_pool, auth.device_id)
            .await
            .map_err(|_| Status::internal("Internal error."))?
            .ok_or_else(|| Status::not_found("Device not found."))?;

        let settings = device_settings::get_device_settings(&self.sql_pool, device).await?;

        Ok(Response::new(eads_proto::api::DeviceSettingsResponse {
            settings: Some(settings),
        }))
    }

    async fn send_heartbeat(
        &self,
        req: Request<eads_proto::api::Heartbeat>,
    ) -> Result<Response<eads_proto::api::SendHeartbeatResponse>, Status> {
        let device_id = req
            .extensions()
            .get::<auth_interceptor::Auth>()
            .unwrap()
            .device_id;

        // TODO: Check that all streams are owned by this device
        for datapoint in req.into_inner().data {
            let uuid = if let Ok(uuid) = uuid::Uuid::parse_str(&datapoint.stream) {
                uuid
            } else {
                return Err(Status::invalid_argument("Invalid 'stream' field."));
            };

            // If the timestamp is beyond 5 minutes in the future then we will ignore this segment.
            let time = SystemTime::UNIX_EPOCH + Duration::from_micros(datapoint.timestamp);

            if (SystemTime::now() + Duration::from_secs(60 * 5))
                .duration_since(time)
                .is_ok()
            {
                db::insert_heartbeat_datapoint(
                    &self.sql_pool,
                    db::HeartbeatDataPoint {
                        stream: uuid,
                        time: datapoint.timestamp,
                        duration: datapoint.duration,
                        values: datapoint.values,
                    },
                )
                .await
                .map_err(|_| Status::data_loss("Failed to insert heartbeat datapoint."))?;
            } else {
                warn!("Stream {} sent heartbeat with invalid time.", uuid);
            }
        }

        db::set_device_last_online(
            &self.sql_pool,
            device_id,
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs(),
        )
        .await
        .map_err(|_| Status::internal("Internal error."))?;

        Ok(Response::new(
            eads_proto::api::SendHeartbeatResponse::default(),
        ))
    }

    async fn send_data_segment(
        &self,
        req: Request<eads_proto::api::DataSegment>,
    ) -> Result<Response<eads_proto::api::SendDataSegmentResponse>, Status> {
        let device_id = req
            .extensions()
            .get::<auth_interceptor::Auth>()
            .unwrap()
            .device_id;

        let message = req.into_inner();

        debug!("Received data segment from {}", device_id);

        let event_uuid = uuid::Uuid::parse_str(&message.event)
            .map_err(|_| Status::invalid_argument("Invalid 'event' field."))?;

        for datapoint in message.data {
            let stream_uuid = uuid::Uuid::parse_str(&datapoint.stream)
                .map_err(|_| Status::invalid_argument("Invalid 'stream' field."))?;

            // If the timestamp is beyond 5 minutes in the future then we will ignore this segment.
            let time = SystemTime::UNIX_EPOCH + Duration::from_micros(datapoint.timestamp);

            if (SystemTime::now() + Duration::from_secs(60 * 5))
                .duration_since(time)
                .is_ok()
            {
                db::insert_event_datapoint(
                    &self.sql_pool,
                    db::DataPoint {
                        stream: stream_uuid,
                        event: event_uuid,
                        time: datapoint.timestamp,
                        duration: datapoint.duration,
                        values: datapoint.values,
                    },
                )
                .await
                .map_err(|_| Status::data_loss("Failed to insert segment datapoint."))?;
            }
        }

        Ok(Response::new(
            eads_proto::api::SendDataSegmentResponse::default(),
        ))
    }

    async fn send_event_advisory(
        &self,
        req: Request<eads_proto::api::EventAdvisory>,
    ) -> Result<Response<eads_proto::api::EventAdvisoryResponse>, Status> {
        let auth = req.extensions().get::<auth_interceptor::Auth>().unwrap();

        let device = db::get_device(&self.sql_pool, auth.device_id)
            .await
            .map_err(|_| Status::internal("Internal error."))?
            .ok_or_else(|| Status::not_found("Device not found."))?;

        let message = req.into_inner();

        match message.msg {
            Some(msg) => match msg {
                eads_proto::api::event_advisory::Msg::PhaseTrigger(trigger) => {
                    let phase = Uuid::parse_str(&trigger.phase).map_err(|_| {
                        Status::invalid_argument("Invalid 'phase' in 'data' field.")
                    })?;

                    // If the event start time is more than 5 minutes in the future then we will
                    // not accept it.
                    let time = SystemTime::UNIX_EPOCH + Duration::from_micros(trigger.timestamp);
                    if (SystemTime::now() + Duration::from_secs(60 * 5))
                        .duration_since(time)
                        .is_err()
                    {
                        return Err(Status::invalid_argument(format!(
                            "Invalid 'time' value ({}) in 'data' field.",
                            trigger.timestamp
                        )));
                    }

                    let events =
                        db::get_running_events_overlapping_device(&self.sql_pool, device.uuid)
                            .await
                            .map_err(|_| {
                                Status::internal("Internal error: Failed to search for events")
                            })?;

                    if events.is_empty() {
                        // Create new event
                        let uuid = uuid::Uuid::new_v4();
                        db::create_event(
                            &self.sql_pool,
                            db::Event {
                                uuid,
                                status: db::EventStatus::Running,
                                r#type: db::EventType::DeviceTriggered,
                                start_time: trigger.timestamp,
                                end_time: None,
                            },
                        )
                        .await
                        .map_err(|_| Status::internal("Internal error: Failed to create event"))?;
                        db::set_event_initial_radius(
                            &self.sql_pool,
                            uuid,
                            trigger.timestamp,
                            device.location.unwrap(), // TODO TODO TODO
                            0.1,
                        )
                        .await
                        .map_err(|_| {
                            Status::internal("Internal error: Failed to set event region")
                        })?;
                        db::add_phase_to_event(&self.sql_pool, uuid, phase)
                            .await
                            .map_err(|_| {
                                Status::internal("Internal error: Failed to set event region")
                            })?;
                        db::insert_event_message(
                            &self.sql_pool,
                            db::EventMessage {
                                time: trigger.timestamp,
                                event: uuid,
                                r#type: db::EventMessageType::PhaseTrigger,
                                data: Some(json!({ "phase": trigger.phase })),
                            },
                        )
                        .await
                        .map_err(|_| {
                            Status::internal("Internal error: Failed to create event message")
                        })?;

                        info!("Event {} started", uuid);

                        // Tell all the connected devices!
                        // TODO: Select all streams we want
                        let streams: Vec<_> = db::get_all_data_streams(&self.sql_pool)
                            .await
                            .map_err(|_| Status::internal("Internal error."))?
                            .iter()
                            .map(|s| s.uuid)
                            .collect();

                        // TODO: Use a single sql query
                        for stream in streams.iter() {
                            db::add_stream_to_event(&self.sql_pool, uuid, *stream)
                                .await
                                .map_err(|_| Status::internal("Internal error."))?;
                        }

                        // If there is not already an event going then we will start one.
                        let state = self.state.lock().await;
                        state
                            .event_stream_tx
                            .send(EventMessage::Start {
                                uuid,
                                timestamp: trigger.timestamp
                                    - std::time::Duration::from_secs(5).as_micros() as u64,
                                streams,
                            })
                            .map_err(|_| Status::internal("Internal error."))?;
                    } else {
                        let event = if events.len() == 1 {
                            events.get(0).unwrap()
                        } else {
                            warn!("Overlapping running events {:?}", events);
                            // TODO: We need some way of resolving this
                            events.get(0).unwrap()
                        };

                        // Record the trigger event
                        db::add_phase_to_event(&self.sql_pool, event.uuid, phase)
                            .await
                            .map_err(|_| {
                                Status::internal("Internal error: Failed to set event region")
                            })?;
                        db::insert_event_message(
                            &self.sql_pool,
                            db::EventMessage {
                                time: trigger.timestamp,
                                event: event.uuid,
                                r#type: db::EventMessageType::PhaseTrigger,
                                data: Some(json!({ "phase": trigger.phase })),
                            },
                        )
                        .await
                        .map_err(|_| {
                            Status::internal("Internal error: Failed to create event message")
                        })?;

                        // TODO: Add ourself to the region of the event
                    }

                    Ok(Response::new(
                        eads_proto::api::EventAdvisoryResponse::default(),
                    ))
                }
                eads_proto::api::event_advisory::Msg::PhaseUntrigger(untrigger) => {
                    let phase = Uuid::parse_str(&untrigger.phase).map_err(|_| {
                        Status::invalid_argument("Invalid 'phase' in 'data' field.")
                    })?;

                    let events = db::get_events_by_phase(&self.sql_pool, phase)
                        .await
                        .map_err(|_| Status::internal("Internal error"))?;

                    db::remove_phase_from_all_events(&self.sql_pool, phase)
                        .await
                        .map_err(|_| Status::internal("Internal error"))?;

                    for event in events.iter() {
                        // Record the untrigger event
                        db::insert_event_message(
                            &self.sql_pool,
                            db::EventMessage {
                                time: untrigger.timestamp,
                                event: event.uuid,
                                r#type: db::EventMessageType::PhaseUntrigger,
                                data: Some(json!({ "phase": untrigger.phase })),
                            },
                        )
                        .await
                        .map_err(|_| Status::internal("Internal error"))?;

                        let phases = db::get_event_phases(&self.sql_pool, event.uuid)
                            .await
                            .map_err(|_| Status::internal("Internal error"))?;

                        if phases.is_empty() {
                            info!("Event {} completed", event.uuid);

                            db::set_event_status(
                                &self.sql_pool,
                                event.uuid,
                                db::EventStatus::Complete,
                            )
                            .await
                            .map_err(|_| {
                                Status::internal("Internal error: Failed to set event status")
                            })?;

                            db::set_event_end_time(&self.sql_pool, event.uuid, untrigger.timestamp)
                                .await
                                .map_err(|_| {
                                    Status::internal("Internal error: Failed to set event end time")
                                })?;

                            // Tell all the connected devices!
                            let state = self.state.lock().await;
                            state
                                .event_stream_tx
                                .send(EventMessage::End {
                                    uuid: event.uuid,
                                    timestamp: untrigger.timestamp
                                        + std::time::Duration::from_secs(5).as_micros() as u64,
                                })
                                .map_err(|_| Status::internal("Internal error."))?;
                        }
                    }

                    Ok(Response::new(
                        eads_proto::api::EventAdvisoryResponse::default(),
                    ))
                }
            },
            None => Err(Status::invalid_argument("Missing 'msg' field.")),
        }
    }

    type SubscribeEventNotificationsStream =
        Pin<Box<dyn Stream<Item = Result<eads_proto::api::EventNotification, Status>> + Send>>;

    async fn subscribe_event_notifications(
        &self,
        req: Request<eads_proto::api::SubscribeEventsInfo>,
    ) -> Result<Response<Self::SubscribeEventNotificationsStream>, Status> {
        let auth = req.extensions().get::<auth_interceptor::Auth>().unwrap();

        debug!("Subscribe data requests from {}", auth.device_id);

        // Grab some server data for use in the async function
        let state = self.state.lock().await;
        let mut event_rx = state.event_stream_tx.subscribe();
        drop(state);
        let device = auth.device_id;
        let pool = self.sql_pool.clone();

        let output = async_stream::stream! {
            let device_streams: Vec<_> =
                db::get_data_streams_by_device(&pool, device)
                    .await
                    .map_err(|_| Status::internal("Internal error."))?
                    .iter()
                    .map(|s| s.uuid)
                    .collect();

            // List of currently running events for this device.
            let mut events: Vec<_> = db::get_running_events_by_device(&pool, device)
                .await
                .map_err(|_| Status::internal("Internal error."))?
                .iter()
                .map(|e| e.uuid)
                .collect();

            let mut heartbeat_interval = tokio::time::interval(std::time::Duration::from_millis(10000 /* TODO */));

            loop {
                tokio::select! {
                    _ = heartbeat_interval.tick() => {
                        let pool = &pool;
                        let events: Result<Vec<eads_proto::api::event_notification::event_heartbeat::EventHeartbeatEntry>, Status> = try_join_all(events
                            .iter()
                            .map(|x| Box::pin(async move {
                                let triggered_phases = db::get_event_phases(pool, *x)
                                    .await
                                    .map_err(|_| Status::internal("Internal error"))?;

                                Ok(eads_proto::api::event_notification::event_heartbeat::EventHeartbeatEntry {
                                    uuid:  x.to_string(),
                                    triggered_phases: triggered_phases.iter().map(|x| x.to_string()).collect(),
                                })
                            }))).await;

                        yield events.map(|events| eads_proto::api::EventNotification {
                            msg: Some(eads_proto::api::event_notification::Msg::Heartbeat(
                                eads_proto::api::event_notification::EventHeartbeat {
                                    events
                                },
                            )),
                        })
                    },
                    recv = event_rx.recv() => match recv {
                        Ok(msg) => match msg {
                            EventMessage::Start { uuid, timestamp, streams } => {
                                if streams.iter().any(|x| device_streams.contains(x)) {
                                    events.push(uuid);

                                    yield Ok(eads_proto::api::EventNotification {
                                        msg: Some(eads_proto::api::event_notification::Msg::Start(
                                            eads_proto::api::event_notification::EventStart {
                                                uuid: uuid.to_string(),
                                                streams: streams
                                                    .iter()
                                                    .filter(|x| device_streams.contains(x))
                                                    .map(|x| x.to_string())
                                                    .collect(),
                                                start: timestamp,
                                            },
                                        )),
                                    })
                                }
                            },
                            EventMessage::End { uuid, timestamp } => {
                                if events.contains(&uuid) {
                                    events.retain(|x| *x != uuid);

                                    yield Ok(eads_proto::api::EventNotification {
                                        msg: Some(eads_proto::api::event_notification::Msg::End(
                                            eads_proto::api::event_notification::EventEnd {
                                                uuid: uuid.to_string(),
                                                end: timestamp,
                                            },
                                        )),
                                    })
                                }
                            },
                            EventMessage::UpdateStreams { uuid, streams } => {
                                if streams.iter().any(|x| device_streams.contains(x)) {
                                    if !events.contains(&uuid) {
                                        events.push(uuid);
                                    }

                                    yield Ok(eads_proto::api::EventNotification {
                                        msg: Some(eads_proto::api::event_notification::Msg::UpdateStreams (
                                            eads_proto::api::event_notification::EventUpdateStreams {
                                                uuid: uuid.to_string(),
                                                streams: streams
                                                    .iter()
                                                    .filter(|x| device_streams.contains(x))
                                                    .map(|x| x.to_string())
                                                    .collect(),
                                            },
                                        )),
                                    })
                                }
                            },
                        },
                        Err(_) => {
                            error!("Event notification stream fell behind.");
                            yield Err(Status::internal("Internal error."))
                        }
                    }
                }
            }
        };

        Ok(Response::new(
            Box::pin(output) as Self::SubscribeEventNotificationsStream
        ))
    }

    async fn event_status(
        &self,
        req: tonic::Request<eads_proto::api::EventStatusInfo>,
    ) -> Result<Response<eads_proto::api::EventStatusResponse>, Status> {
        let _auth = req.extensions().get::<auth_interceptor::Auth>().unwrap();

        let message = req.into_inner();

        let event_uuid = uuid::Uuid::parse_str(&message.uuid)
            .map_err(|_| Status::invalid_argument("Invalid 'uuid' field."))?;

        let event = db::get_event(&self.sql_pool, event_uuid)
            .await
            .map_err(|_| Status::internal("Internal error."))?
            .ok_or_else(|| Status::not_found("Event not found."))?;

        let streams = db::get_event_streams(&self.sql_pool, event_uuid)
            .await
            .map_err(|_| Status::internal("Internal error."))?
            .iter()
            .map(|x| x.to_string())
            .collect();

        Ok(Response::new(eads_proto::api::EventStatusResponse {
            start: event.start_time,
            end: event.end_time,
            streams,
            status: (match event.status {
                db::EventStatus::Running => {
                    eads_proto::api::event_status_response::EventStatus::Running
                }
                db::EventStatus::Complete => {
                    eads_proto::api::event_status_response::EventStatus::Ended
                }
            })
            .into(),
        }))
    }

    async fn get_registration_state(
        &self,
        req: tonic::Request<eads_proto::api::GetRegistrationStateInfo>,
    ) -> Result<Response<eads_proto::common::RegistrationState>, Status> {
        let auth = req.extensions().get::<auth_interceptor::Auth>().unwrap();

        let state = db::get_device_registration_state(&self.sql_pool, auth.device_id)
            .await
            .map_err(|_| Status::internal("Internal error."))?
            .ok_or_else(|| Status::not_found("Device not found."))?;

        let status = if state.registered {
            eads_proto::common::registration_state::RegistrationStatus::Registered
        } else if state.register_validation_completed.is_some() {
            eads_proto::common::registration_state::RegistrationStatus::Validated
        } else if Some(true)
            == state.register_waiting_on_validation.and_then(|x| {
                SystemTime::now()
                    .duration_since(x.into())
                    .ok()
                    .map(|d| d.as_secs() < 300)
            })
        {
            eads_proto::common::registration_state::RegistrationStatus::WaitingForValidation
        } else {
            eads_proto::common::registration_state::RegistrationStatus::NotRegistered
        };

        // Set the last online for the device so the web page can continue.
        // HACK: This assumes that devices will only request their own registration state.
        db::set_device_last_online(
            &self.sql_pool,
            auth.device_id,
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs(),
        )
        .await
        .map_err(|_| Status::internal("Internal error."))?;

        Ok(Response::new(eads_proto::common::RegistrationState {
            status: status.into(),
        }))
    }

    async fn validate_registration(
        &self,
        req: tonic::Request<eads_proto::api::ValidateRegistrationInfo>,
    ) -> Result<Response<eads_proto::api::ValidateRegistrationResponse>, Status> {
        let auth = req.extensions().get::<auth_interceptor::Auth>().unwrap();

        let state = db::get_device_registration_state(&self.sql_pool, auth.device_id)
            .await
            .map_err(|_| Status::internal("Internal error."))?
            .ok_or_else(|| Status::not_found("Device not found."))?;

        if state.registered {
            return Err(Status::failed_precondition("Device is already registered."));
        }
        if state.register_validation_completed.is_some() {
            return Err(Status::failed_precondition("Device is already validated."));
        }

        if Some(true)
            != state.register_waiting_on_validation.and_then(|x| {
                SystemTime::now()
                    .duration_since(x.into())
                    .ok()
                    .map(|d| d.as_secs() < 300 + 10 /* 10 sec grace period */)
            })
        {
            return Err(Status::failed_precondition(
                "Device is not in validation state.",
            ));
        }

        db::set_device_register_validation_completed(
            &self.sql_pool,
            auth.device_id,
            Some(
                SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap()
                    .as_secs(),
            ),
        )
        .await
        .map_err(|_| Status::internal("Internal error."))?;

        Ok(Response::new(
            eads_proto::api::ValidateRegistrationResponse::default(),
        ))
    }
}
