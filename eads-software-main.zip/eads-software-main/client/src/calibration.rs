use color_eyre::eyre::{self, eyre};
use prost_types::value::Kind;

#[derive(Debug, Clone)]
pub enum Calibration {
    AdcLinearCalibration {
        channel: usize,
        slope: f64,
        offset: f64,
    },
}

impl Calibration {
    pub fn new(
        channel_calibration: eads_proto::common::ChannelCalibration,
    ) -> Result<Calibration, eyre::Report> {
        match channel_calibration.r#type.as_str() {
            "linear" => {
                let data = &channel_calibration
                    .calibration_data
                    .ok_or(eyre!("Missing calibration data."))?;

                let channel = if let Kind::StringValue(channel) = data
                    .fields
                    .get("channel")
                    .and_then(|x| x.kind.clone())
                    .ok_or(eyre!("Missing 'channel' field in calibration data."))?
                {
                    // NOTE: In the future this can be expanded to allow for channels like "0.0" to
                    // map to chip 0, channel 0. For now, we will only use "0" and assume we are on
                    // chip 0.
                    channel
                        .parse()
                        .map_err(|_| eyre!("Invalid adc channel {} in calibration data.", channel))
                } else {
                    Err(eyre!(
                        "Invalid type for 'channel' field in calibration data. Expected string."
                    ))
                }?;

                let slope = if let Kind::NumberValue(slope) = data
                    .fields
                    .get("slope")
                    .and_then(|x| x.kind.clone())
                    .ok_or(eyre!("Missing 'slope' field in calibration data."))?
                {
                    Ok(slope)
                } else {
                    Err(eyre!(
                        "Invalid type for 'slope' field in calibration data. Expected number."
                    ))
                }?;

                let offset = if let Kind::NumberValue(offset) = data
                    .fields
                    .get("offset")
                    .and_then(|x| x.kind.clone())
                    .ok_or(eyre!("Missing 'offset' field in calibration data."))?
                {
                    Ok(offset)
                } else {
                    Err(eyre!(
                        "Invalid type for 'offset' field in calibration data. Expected number."
                    ))
                }?;

                Ok(Calibration::AdcLinearCalibration {
                    channel,
                    slope,
                    offset,
                })
            }
            &_ => Err(eyre!("")),
        }
    }

    /// Get the ADC channel that this calibration is associated to
    pub fn adc_channel(&self) -> usize {
        match self {
            Calibration::AdcLinearCalibration {
                channel,
                slope: _,
                offset: _,
            } => *channel,
        }
    }

    pub fn apply(&self, value: u32) -> f64 {
        match self {
            Calibration::AdcLinearCalibration {
                channel: _,
                slope,
                offset,
            } => slope * (value as f64) + offset,
        }
    }
}
