use axum::extract::Path;
use axum::Json;
use axum::{extract::Extension, http::StatusCode, response::IntoResponse};
use serde_json::json;

use crate::db::{self, DevicePhase};
use crate::server_error::ServerError;

use super::auth_middleware::Auth;

#[tracing::instrument(skip(pool))]
pub async fn get_device_phase(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    match db::get_device_phase(&pool, uuid).await? {
        None => Err(ServerError::KnownError((
            StatusCode::NOT_FOUND,
            "Device phase not found.",
        ))),
        Some(x) => Ok((StatusCode::OK, Json(x))),
    }
}

#[derive(Debug, serde::Deserialize)]
pub struct CreateDevicePhase {
    device: uuid::Uuid,
    name: Option<String>,
}

#[tracing::instrument(skip(pool, _user, perms))]
pub async fn create_device_phase(
    Auth(_user, perms): Auth,
    axum::Json(payload): axum::Json<CreateDevicePhase>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    perms.assert_has("provision")?;

    let uuid = uuid::Uuid::new_v4();

    db::create_device_phase(
        &pool,
        DevicePhase {
            uuid,
            name: payload.name,
            device: payload.device,
        },
    )
    .await?;

    Ok((StatusCode::OK, Json(json!({ "uuid": uuid }))))
}
