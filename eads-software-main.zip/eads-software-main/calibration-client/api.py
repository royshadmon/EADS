import urllib.parse
import requests

def get_device_by_balena(server, access_token, balena_uuid):
    headers = {
        "content-type": "application/json"
    }
    cookies = {
        "auth0-access-token": access_token
    }
    
    return requests.get(
        urllib.parse.urljoin(server, f"/v1/devices/by-balena/{balena_uuid}"),
        headers=headers,
        cookies=cookies
    )

def create_device(server, access_token, balena_uuid):
    headers = {
        "content-type": "application/json"
    }
    cookies = {
        "auth0-access-token": access_token
    }
    
    res = requests.post(
        urllib.parse.urljoin(server, "/v1/devices"),
        headers=headers,
        cookies=cookies,
        json={
            "balena_uuid": balena_uuid,
        }
    )
    res.raise_for_status()

    return res.json()["uuid"]

def create_phase(server, access_token, device_uuid, name):
    headers = {
        "content-type": "application/json"
    }
    cookies = {
        "auth0-access-token": access_token
    }
    
    res = requests.post(
        urllib.parse.urljoin(server, "/v1/phases"),
        headers=headers,
        cookies=cookies,
        json={
            "name": name,
            "device": device_uuid 
        }
    )
    res.raise_for_status()

    return res.json()["uuid"]

def create_calibration(server, access_token, calibration):
    headers = {
        "content-type": "application/json"
    }
    cookies = {
        "auth0-access-token": access_token
    }
    
    res = requests.post(
        urllib.parse.urljoin(server, "/v1/calibrations"),
        headers=headers,
        cookies=cookies,
        json={
            "time": calibration.time,
            "type": calibration.type,
            "data": calibration.data
        }
    )
    res.raise_for_status()

    return res.json()["uuid"]


def create_channel(server, access_token, device_uuid, phase_uuid, calibration_uuid, type, channel):
    headers = {
        "content-type": "application/json"
    }
    cookies = {
        "auth0-access-token": access_token
    }
    
    res = requests.post(
        urllib.parse.urljoin(server, "/v1/channels"),
        headers=headers,
        cookies=cookies,
        json={
            "calibration": calibration_uuid,
            "type": type,
            "frequency": channel.frequency,
            "device": device_uuid,
            "phase": phase_uuid,
        }
    )
    res.raise_for_status()

    return res.json()["uuid"]

def create_stream(server, access_token, device_uuid, phase_uuid, channel_uuid, type, stream):
    headers = {
        "content-type": "application/json"
    }
    cookies = {
        "auth0-access-token": access_token
    }
    
    res = requests.post(
        urllib.parse.urljoin(server, "/v1/streams"),
        headers=headers,
        cookies=cookies,
        json={
            "type": type,
            "computed": stream.computed,
            "units": stream.units,
            "frequency": stream.frequency,
            "threshold_low": stream.threshold_low,
            "threshold_high": stream.threshold_high,
            "channel": channel_uuid,
            "device": device_uuid,
            "phase": phase_uuid,
        }
    )
    res.raise_for_status()

    return res.json()["uuid"]

def get_device_token(server, access_token, device):
    headers = {
        "content-type": "application/json"
    }
    cookies = {
        "auth0-access-token": access_token
    }
    
    res = requests.get(
        urllib.parse.urljoin(server, f"/v1/devices/{device}/token"),
        headers=headers,
        cookies=cookies
    )
    res.raise_for_status()

    return res.json()["token"]
