use sqlx::Postgres;
use tonic::Status;

use super::util::serde_to_prost;
use crate::db;

pub async fn get_device_settings(
    pool: &sqlx::Pool<Postgres>,
    device: db::Device,
) -> Result<eads_proto::common::DeviceSettings, Status> {
    let phases = db::get_device_phases_by_device(pool, device.uuid)
        .await
        .map_err(|_| Status::internal("Internal error."))?;

    let mut phase_settings = Vec::new();

    for phase in phases {
        phase_settings.push(get_phase_settings(pool, phase).await?);
    }

    let registration_state = db::get_device_registration_state(pool, device.uuid)
        .await
        .map_err(|_| Status::internal("Internal error."))
        .and_then(|x| x.ok_or(Status::internal("Internal error.")))?;

    Ok(eads_proto::common::DeviceSettings {
        uuid: device.uuid.to_string(),
        phases: phase_settings,
        position: device
            .location
            .map(|loc| eads_proto::common::device_settings::LatLng {
                latitude: loc.x(),
                longitude: loc.y(),
            }),
        registered: registration_state.registered,
    })
}

async fn get_phase_settings(
    pool: &sqlx::Pool<Postgres>,
    phase: db::DevicePhase,
) -> Result<eads_proto::common::PhaseSettings, Status> {
    let channels = db::get_channels_by_device_phase(pool, phase.uuid)
        .await
        .map_err(|_| Status::internal("Internal error."))?;

    let mut channel_settings = Vec::new();

    for channel in channels {
        channel_settings.push(get_channel_settings(pool, channel).await?);
    }

    let streams = db::get_data_streams_by_phase(pool, phase.uuid)
        .await
        .map_err(|_| Status::internal("Internal error."))?;

    let mut stream_settings = Vec::new();

    for stream in streams {
        stream_settings.push(get_stream_settings(pool, stream).await?);
    }

    Ok(eads_proto::common::PhaseSettings {
        uuid: phase.uuid.to_string(),
        channels: channel_settings,
        streams: stream_settings,
    })
}

async fn get_channel_settings(
    pool: &sqlx::Pool<Postgres>,
    channel: db::Channel,
) -> Result<eads_proto::common::ChannelSettings, Status> {
    let calibration = get_channel_calibration(pool, channel.calibration).await?;

    Ok(eads_proto::common::ChannelSettings {
        uuid: channel.uuid.to_string(),
        calibration,
        frequency: channel.frequency,
        r#type: serde_plain::to_string(&channel.r#type)
            .map_err(|_| Status::internal("Internal error."))?,
    })
}

async fn get_stream_settings(
    _pool: &sqlx::Pool<Postgres>,
    stream: db::DataStream,
) -> Result<eads_proto::common::StreamSettings, Status> {
    Ok(eads_proto::common::StreamSettings {
        uuid: stream.uuid.to_string(),
        r#type: serde_plain::to_string(&stream.r#type)
            .map_err(|_| Status::internal("Internal error."))?,
        computed: stream.computed,
        units: serde_plain::to_string(&stream.units)
            .map_err(|_| Status::internal("Internal error."))?,
        frequency: stream.frequency,
        threshold_low: stream.threshold_low,
        threshold_high: stream.threshold_high,
        channel: stream.channel.to_string(),
    })
}

async fn get_channel_calibration(
    pool: &sqlx::Pool<Postgres>,
    uuid: uuid::Uuid,
) -> Result<Option<eads_proto::common::ChannelCalibration>, Status> {
    db::get_calibration(pool, uuid)
        .await
        .map_err(|_| Status::internal("Internal error."))?
        .map(|calibration| {
            let data = calibration
                .data
                .map(|x| serde_to_prost(&x))
                .transpose()
                .map_err(|_| Status::internal("Internal error."))?;

            let data = data
                .map(|x| match x {
                    prost_types::Value {
                        kind: Some(prost_types::value::Kind::StructValue(obj)),
                    } => Ok(obj),
                    _ => Err(Status::internal("Internal error.")),
                })
                .transpose()?;

            Ok(eads_proto::common::ChannelCalibration {
                uuid: calibration.uuid.to_string(),
                time_calibrated: calibration.time,
                r#type: calibration.r#type,
                calibration_data: data,
            })
        })
        .transpose()
}
