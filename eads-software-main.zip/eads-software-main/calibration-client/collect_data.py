import time
import pyvisa as visa
import numpy as np
import matplotlib.pyplot as plt

def collect_data(scope, device, channel):
    """
    Collect 1 second of calibration data from the scope and device pyVISA instruments

    Returns scope_data, device_data
    """
    scope_channels = [ 1 ]
    
    # Measured correction factor for oscilloscope probe
    scope_correction = 1.0262

    scope.write("*RST")

    time.sleep(5)

    #####################################################


    scope.write(":TIMebase:MODE MAIN")
    scope.write(":TIMebase:REFerence LEFT")
    scope.write(":TIMebase:RANGe 1")
    # Range of 1 means trigger occurs at t=0.1s. Let's fix that.
    scope.write(":TIMebase:POSition 0.10")

    scope.write(":ACQuire:TYPE NORmal")
    scope.write(":ACQuire:MODE RTIMe")

    # TODO: This should have a settings vector
    scope.write(":channel1:display ON")
    scope.write(":CHANnel1:PROBe 100")
    scope.write(":CHANnel1:scale 48V")

    scope.write(":channel2:display ON") 
    scope.write(":CHANnel2:PROBe 10")
    scope.write(":CHANnel2:scale 1V")

    # Set up scope triggering
    scope.write(":trigger:sweep normal") 
    scope.write(":trigger:mode edge") 
    scope.write(":trigger:edge:source chan2")
    scope.write(":trigger:edge:level 2")

    # Set up wavegen to create square wave for trigger
    scope.write(":WGEN:FUNCtion PULSe")
    scope.write(":WGEN:FUNCtion:PULSe:WIDTh 10s")
    scope.write(":WGEN:PERiod 10s")
    scope.write(":WGEN:OUTPut:load ONEMeg")
    scope.write(":WGEN:OUTPut:POLarity normal")
    scope.write(":WGEN:VOLTage:LOW 0")
    scope.write(":WGEN:VOLTage:HIGH 3")

    #####################################################

    device_preamble = device.query_ascii_values(':waveform:preamble?', converter='s')
    device_points = float(device_preamble[1])
    device_x_increment = float(device_preamble[2])
    device_x_origin = float(device_preamble[3])
    device_y_increment = float(device_preamble[5])
    device_y_origin = float(device_preamble[6])

    device.write(":trigger:source 0")
    device.write(":trigger:level 750")
    device.write(f":waveform:source {channel}")

    #
    # Start the wavegen to trigger both devices
    #

    device.write(":single")
    scope.write(":single")

    time.sleep(1)

    scope.write(":WGEN:OUTPut ON")

    time.sleep(3)

    scope.write(":WGEN:OUTPut OFF")
    #########################################################

    scope.write(":WAVeform:SOURce CHANnel" + str(scope_channels[0]))
    scope.write(":WAVeform:FORMat WORD")
    scope.write(":WAVeform:BYTeorder LSBFirst")
    scope.write(":WAVeform:UNSigned OFF")

    scope.write(":WAVeform:POINts:MODE raw")
    scope.write(":WAVeform:POINts 200000")
    points = int(scope.query(":WAVeform:POINts?"))
    print("Points: ", points)

    num_channel = len(scope_channels)
    scope_data = np.empty((num_channel, points, 2))

    for i in range(0, num_channel):    
        scope.write(":WAVeform:SOURce CHANnel" + str(scope_channels[i]))
                
        # Retrieve preamble so we can scale scope output
        y_increment = float(scope.query(":WAVeform:YINCrement?"))
        y_origin = float(scope.query(":WAVeform:YORigin?"))
        y_reference = float(scope.query(":WAVeform:YREFerence?"))
        x_increment = float(scope.query(":WAVeform:XINCrement?"))
        x_origin = float(scope.query(":WAVeform:XORigin?"))
        x_reference = float(scope.query(":WAVeform:XREFerence?"))

        scope_waveform = scope.query_binary_values(":WAVeform:DATA?", datatype='h', container = np.array)
        for x in range(0, points):
            scope_data[i,x,0] = x_origin + (x * x_increment)
            scope_data[i,x,1] = scope_correction * ((scope_waveform[x] - y_origin) * y_increment + y_reference)

    device_timestamps = device.query_ascii_values(':waveform:time?', container=np.ndarray)
    device_voltages = device.query_ascii_values(':waveform:data?', container=np.ndarray)

    #out = np.empty(20)
    #for j in range(-10, 10):
    #    out[j + 10] = np.sum(np.roll(scope_data[0,:,1], j) * device_voltages)

    #np.argmax(out)

    scope_data = np.stack((scope_data[0,:,0], np.roll(scope_data[0,:,1], 0)), axis=-1) # np.argmax(out - 10)
    device_data = np.stack((device_timestamps / 1e6, device_voltages), axis=-1)

    return scope_data, device_data
