pub mod common {
    tonic::include_proto!("seads.common");
}
pub mod api {
    tonic::include_proto!("seads.api");
}

pub const FILE_DESCRIPTOR_SET: &[u8] =
    tonic::include_file_descriptor_set!("seads_api_descriptor");
