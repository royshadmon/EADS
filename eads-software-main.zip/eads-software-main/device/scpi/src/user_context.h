#ifndef USER_CONTEXT_H
#define USER_CONTEXT_H

#include <stdint.h>
#include <stdatomic.h>

#define SAMPLE_MAX_VALUE 4096
#define SAMPLE_BUFFER_LENGTH 80000
#define SAMPLING_ADC_REFERENCE_VOLTAGE 3.3
#define SAMPLING_FREQUENCY 8000
#define SAMPLING_CHANNEL_COUNT 8

#define MAX_POINTS 80000

typedef struct {
    uint32_t trigger_channel;
    uint32_t trigger_level;

    uint32_t channel;
    uint32_t points;
} scpi_user_settings_t;
extern const scpi_user_settings_t default_user_settings;

typedef enum {
    SINGLE,
    TRIGGERED,
    STOPPED
} scpi_device_state_t;

typedef struct {
    scpi_device_state_t device_state;
    
    _Atomic uint32_t trigger_sample_count_left;
    _Atomic uint32_t trigger_timestamp_origin;
} scpi_user_state_t;
extern const scpi_user_state_t default_user_state;

typedef struct {
    int* client_fd;

    volatile _Atomic uint32_t** sample_buffers;
    volatile _Atomic uint32_t** timestamp_buffers;
    volatile atomic_size_t* sample_offsets;

    scpi_user_settings_t user_settings;
    scpi_user_state_t user_state;
} scpi_user_context_t;

#endif // USER_CONTEXT_H
