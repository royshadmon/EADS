from . import calibration
from . import database

import numpy as np
from scipy import signal

class LinearCalibration(database.CalibrationSequence):
    def identifier():
        return "linear"

    def apply(calibration, data):
        return np.sum([np.ones(data.shape[-1]) * calibration["offset"], data * calibration["slope"]], axis=0)

    def calibrate(expected, actual):
        print(expected)
        print(actual)

        out = np.matmul(np.linalg.pinv(np.stack([np.ones(actual.shape[-1]), actual], axis=-1)), expected)

        print(out)

        return { "offset": out[0], "slope": out[1] }

database.calibrations.register(LinearCalibration)
