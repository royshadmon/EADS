use std::collections::HashMap;

use axum::extract::{Path, Query};
use axum::Json;
use axum::{extract::Extension, http::StatusCode, response::IntoResponse};

use crate::db;
use crate::server_error::ServerError;

#[tracing::instrument(skip(pool))]
pub async fn get_events(
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<()>> {
    let events = db::get_events(&pool).await?;
    Ok((StatusCode::OK, Json(events)))
}

#[tracing::instrument(skip(pool))]
pub async fn get_event(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    match db::get_event(&pool, uuid).await? {
        None => Err(ServerError::KnownError((
            StatusCode::NOT_FOUND,
            "Event not found.",
        ))),
        Some(x) => Ok((StatusCode::OK, Json(x))),
    }
}

#[tracing::instrument(skip(pool))]
pub async fn get_event_streams(
    Path(uuid): Path<uuid::Uuid>,
    Query(params): Query<HashMap<String, String>>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<()>> {
    let streams = db::get_event_streams(&pool, uuid).await?;

    if params.get("expanded") == Some(&"true".to_string()) {
        let streams_data = db::get_data_streams(&pool, streams).await?;

        Ok((StatusCode::OK, Json(serde_json::to_value(streams_data)?)))
    } else {
        Ok((StatusCode::OK, Json(serde_json::to_value(streams)?)))
    }
}

#[tracing::instrument(skip(pool))]
pub async fn get_event_logs(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<()>> {
    let messages = db::get_event_messages(&pool, uuid).await?;
    Ok((StatusCode::OK, Json(messages)))
}

#[tracing::instrument(skip(pool))]
pub async fn get_event_location(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<()>> {
    let location = db::get_latest_event_location(&pool, uuid).await?;
    Ok((StatusCode::OK, Json(location)))
}

#[tracing::instrument(skip(pool))]
pub async fn get_event_data(
    Path(uuid): Path<uuid::Uuid>,
    Query(params): Query<HashMap<String, String>>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    let streams: Vec<uuid::Uuid> = params
        .get("streams")
        .ok_or(ServerError::KnownError((
            StatusCode::BAD_REQUEST,
            "Missing 'streams' query param.",
        )))?
        .split(',')
        .map(|x| {
            uuid::Uuid::parse_str(x).map_err(|_| {
                ServerError::KnownError((StatusCode::BAD_REQUEST, "Invalid 'streams' value."))
            })
        })
        .collect::<Result<Vec<_>, ServerError<_>>>()?;

    let data_points = db::get_event_datapoints_for_streams(&pool, uuid, streams).await?;

    let mut stream_data = HashMap::new();

    for data_point in data_points {
        if stream_data.get(&data_point.stream).is_none() {
            stream_data.insert(data_point.stream, Vec::new());
        }

        let mut values: Vec<(f64, f64)> = itertools::iterate(data_point.time as f64, |&t| {
            t + (data_point.duration as f64 / data_point.values.len() as f64)
        })
        .zip(data_point.values.iter().copied())
        .collect();

        stream_data
            .get_mut(&data_point.stream)
            .unwrap()
            .append(&mut values);
    }

    Ok((StatusCode::OK, Json(stream_data)))
}
