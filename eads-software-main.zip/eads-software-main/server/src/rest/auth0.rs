use alcoholic_jwt::Validation;
use axum::{
    body::Empty,
    extract::{Extension, Query, TypedHeader},
    http::{HeaderMap, HeaderValue, StatusCode},
    response::IntoResponse,
};
use color_eyre::eyre;
use cookie::{Cookie, SameSite};
use rand::distributions::Alphanumeric;
use rand::Rng;
use reqwest::header;
use tracing::info;

use crate::{db, server_config::ServerConfig};
use crate::{db::create_user, server_error::ServerError};

pub async fn oauth_login(
    Extension(config): Extension<ServerConfig>,
) -> Result<impl IntoResponse, ServerError<()>> {
    // Generate a random 20 digit alphanumeric value to pass through the OAuth
    // flow. This will be set as a cookie on the client as well as passed
    // through the `state` query parameter. Doing so will protect against CSRF.
    //
    // See: https://auth0.com/docs/secure/attack-protection/state-parameters
    let state: String = rand::thread_rng()
        .sample_iter(&Alphanumeric)
        .take(20)
        .map(char::from)
        .collect();

    // Build the Auth0 URI to redirect
    let mut uri = config.auth0_uri.join("authorize")?;
    uri.query_pairs_mut()
        .append_pair("response_type", "code")
        .append_pair("client_id", &config.auth0_client_id)
        .append_pair("redirect_uri", &config.auth0_redirect_uri)
        .append_pair("scope", "openid profile email")
        .append_pair("audience", &config.auth0_audience)
        .append_pair("state", &state);

    // Add the location to redirect and the state cookie headers
    let mut headers = HeaderMap::new();
    headers.insert(header::LOCATION, HeaderValue::from_str(&uri.to_string())?);
    headers.append(
        header::SET_COOKIE,
        HeaderValue::from_str(
            &Cookie::build("auth0-verification-state", &state)
                .finish()
                .to_string(),
        )?,
    );

    Ok((StatusCode::TEMPORARY_REDIRECT, headers, Empty::new()))
}

#[allow(dead_code)]
#[derive(serde::Deserialize)]
pub struct Auth0Params {
    code: String,
    state: String,
}

#[allow(dead_code)]
#[derive(Debug, serde::Deserialize)]
struct Auth0Response {
    access_token: String,
    refresh_token: Option<String>,
    id_token: String,
    token_type: String,
}

/// Route for handling authorizations with Auth0 using OAuth.
///
/// This is intended to be the callback from the Auth0 flow to allow for users
/// to retrieve their id token.
pub async fn oauth_authorize(
    Query(query): Query<Auth0Params>,
    TypedHeader(cookies): TypedHeader<headers::Cookie>,
    Extension(config): Extension<ServerConfig>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
    Extension(reqwest_client): Extension<reqwest::Client>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    // Check that the auth0-verification-state cookie matches the state passed
    // as a query parameter.
    let verification_cookie = cookies.get("auth0-verification-state");
    let state_param = query.state;
    if verification_cookie != Some(&state_param) {
        info!(
            cookie = ?verification_cookie,
            param = ?state_param,
            "Found invalid Auth0 verification state."
        );
        return Err(ServerError::KnownError((
            StatusCode::BAD_REQUEST,
            "Invalid verification code.",
        )));
    }

    // Request auth token from Auth0 API
    let req = reqwest_client
        .post(config.auth0_uri.join("oauth/token")?)
        .header(header::CONTENT_TYPE, "application/x-www-form-urlencoded")
        .form(&[
            ("grant_type", "authorization_code"),
            ("client_id", &config.auth0_client_id),
            ("client_secret", &config.auth0_client_secret),
            ("code", &query.code),
            ("redirect_uri", &config.auth0_redirect_uri),
        ])
        .send()
        .await?;
    let res = req.json::<Auth0Response>().await?;

    // Validate the id and access JWTs passed back from Auth0
    validate_auth0_id_jwt(&res.id_token, &config)?;
    let validated_access_jwt = validate_auth0_access_jwt(&res.access_token, &config)?;

    // If the user does not exist then create it
    let auth0_id = validated_access_jwt.claims.get("sub").unwrap().to_string();
    if db::get_user_by_auth0(&pool, &auth0_id).await?.is_none() {
        create_user(
            &pool,
            db::User {
                uuid: uuid::Uuid::new_v4(),
                auth0_id: auth0_id.clone(),
            },
        )
        .await?;
    }

    let mut headers = HeaderMap::new();
    // Set the id token
    headers.append(
        header::SET_COOKIE,
        HeaderValue::from_str(
            &Cookie::build("auth0-id-token", res.id_token.clone())
                .path("/")
                .same_site(SameSite::Strict)
                .finish()
                .to_string(),
        )?,
    );
    // Set the access token
    headers.append(
        header::SET_COOKIE,
        HeaderValue::from_str(
            &Cookie::build("auth0-access-token", res.access_token.clone())
                .path("/")
                .same_site(SameSite::Strict)
                .http_only(true)
                .finish()
                .to_string(),
        )?,
    );
    // Invalidate the verification state cookie
    headers.append(
        header::SET_COOKIE,
        HeaderValue::from_str(
            &Cookie::build("auth0-verification-state", "")
                .expires(cookie::Expiration::DateTime(
                    time::OffsetDateTime::UNIX_EPOCH,
                ))
                .finish()
                .to_string(),
        )?,
    );

    if let Some(uri) = cookies.get("auth0-redirect-uri") {
        match urlencoding::decode(uri) {
            Ok(uri) => {
                headers.insert(header::LOCATION, HeaderValue::from_str(&uri)?);

                Ok((StatusCode::TEMPORARY_REDIRECT, headers, Empty::new()))
            }
            Err(_) => Err(ServerError::KnownError((
                StatusCode::BAD_REQUEST,
                "Invalid url-encoded redirect uri",
            ))),
        }
    } else {
        Ok((StatusCode::OK, headers, Empty::new()))
    }
}

/// Route for handling OAuth logout.
pub async fn oauth_logout(
    TypedHeader(cookies): TypedHeader<headers::Cookie>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    let mut headers = HeaderMap::new();
    // Invalidate the auth state cookies
    headers.append(
        header::SET_COOKIE,
        HeaderValue::from_str(
            &Cookie::build("auth0-id-token", "")
                .path("/")
                .expires(cookie::Expiration::DateTime(
                    time::OffsetDateTime::UNIX_EPOCH,
                ))
                .finish()
                .to_string(),
        )?,
    );
    headers.append(
        header::SET_COOKIE,
        HeaderValue::from_str(
            &Cookie::build("auth0-access-token", "")
                .path("/")
                .expires(cookie::Expiration::DateTime(
                    time::OffsetDateTime::UNIX_EPOCH,
                ))
                .finish()
                .to_string(),
        )?,
    );

    if let Some(uri) = cookies.get("auth0-redirect-uri") {
        match urlencoding::decode(uri) {
            Ok(uri) => {
                headers.insert(header::LOCATION, HeaderValue::from_str(&uri)?);

                Ok((StatusCode::TEMPORARY_REDIRECT, headers, Empty::new()))
            }
            Err(_) => Err(ServerError::KnownError((
                StatusCode::BAD_REQUEST,
                "Invalid url-encoded redirect uri",
            ))),
        }
    } else {
        Ok((StatusCode::OK, headers, Empty::new()))
    }
}

fn validate_auth0_id_jwt(
    token: &str,
    config: &ServerConfig,
) -> Result<alcoholic_jwt::ValidJWT, color_eyre::Report> {
    let validated = validate_auth0_jwt(token, config)?;

    // The audience must match the client id of our application
    validated
        .claims
        .get("aud")
        .ok_or_else(|| eyre::eyre!("Token is missing 'aud' field"))?
        .as_str()
        .ok_or_else(|| eyre::eyre!("Token 'aud' field was not a string"))
        .and_then(|aud| {
            if aud == config.auth0_client_id {
                Ok(())
            } else {
                Err(eyre::eyre!("Token 'aud' field is not valid"))
            }
        })?;

    Ok(validated)
}

pub fn validate_auth0_access_jwt(
    token: &str,
    config: &ServerConfig,
) -> Result<alcoholic_jwt::ValidJWT, color_eyre::Report> {
    let validated = validate_auth0_jwt(token, config)?;

    // The audience must match the client id of our application
    validated
        .claims
        .get("aud")
        .ok_or_else(|| eyre::eyre!("Token is missing 'aud' field"))?
        .as_array()
        .ok_or_else(|| eyre::eyre!("Token 'aud' field was not a array"))
        .and_then(|aud| {
            if aud.contains(&serde_json::Value::String(config.auth0_audience.clone())) {
                Ok(())
            } else {
                Err(eyre::eyre!("Token 'aud' field is not valid"))
            }
        })?;

    Ok(validated)
}

/// Validate the Auth0 JSON Web Token against the publicly available signing
/// public keys. This function additionally checks that the token's `iss` field
/// is our Auth0 application and that the token's `aud` is our client id.
fn validate_auth0_jwt(
    token: &str,
    config: &ServerConfig,
) -> Result<alcoholic_jwt::ValidJWT, color_eyre::Report> {
    let kid = alcoholic_jwt::token_kid(token)
        .map_err(|x| eyre::eyre!("Failed to parse JWT: {:?}", x))?
        .ok_or_else(|| eyre::eyre!("Failed to get kid claim on JWT"))?;
    let jwk = config
        .auth0_key_set
        .find(&kid)
        .ok_or_else(|| eyre::eyre!("Failed to find auth0 key matching kid claim {}", kid))?;
    let validated_id_jwt = alcoholic_jwt::validate(
        token,
        jwk,
        vec![
            Validation::Issuer(config.auth0_uri.to_string()),
            Validation::SubjectPresent,
            Validation::NotExpired,
        ],
    )
    .map_err(|err| eyre::eyre!("Failed to validate auth0 JWT: {:?}", err))?;
    Ok(validated_id_jwt)
}
