# Sampling

The sampling service provides an interface to retrieve samples from the ADC over SPI on a Raspberry Pi board. This software makes use of the DMA controller on the Raspberry Pi board to sample the ADC at precise intervals without CPU intervention. The data from the ADC along with the timestamps are made available through Unix domain sockets described below.

## Hardware

The sampling service requires following hardware:
- Raspberry Pi 3 (configurable in [`util.h`](src/hardware/util.h))
  - SPI0 (GPIO pins 8, 9, 10, and 11)
  - DMA channels 5, 6, 7, and 9 (see [Configuration](#configuration))
  - PWM channel 1
- [Microchip MCP3208](https://www.microchip.com/en-us/product/MCP3208) 12-bit 8 channel ADC on SPI0

## How to Build

### Building with Nix

To build with nix, simply run

```sh
nix build .#eads-sampling
```

The output of the build will be available at `./result`.

### Dependencies

The following libraries are required to compile the sampling executable:
- [liblfds](https://liblfds.org)

### Configuration

The ADC to target for sampling can be specified with the `SAMPLING_ADC` environment variable. Possible values: `MCP3202`, `MCP3204`, `MCP3208`.

### Building

To build this project, change directories into `src` and run

```sh
make all
```

This will produce an executable named `sampling` in the current directory.

## Usage

Since this application directly access the hardware, it requires access to the `/dev/vcio` and `/dev/mem`, which typically require the application to be run with root permissions.

To start the sampling service, run

```sh
./sampling
```

This will begin sampling and sending data to the sockets described below.

### Sockets

The sampling service exposes two Unix domain sockets to allow other applications to connect and receive data from the ADC. These sockets are available at `/var/sampling/samples.sock` and `/var/sampling/offset.sock` and are described below.

When connecting to either socket, take care to ensure that your application reads from the socket quickly and does not allow the socket buffer to fill. In the case that a client does not read data quickly enough, the sampling application will disconnect to avoid loss of data that could affect other clients.

#### `/var/sampling/samples.sock`

The samples socket provides the stream of samples from the ADC along with associated System Timer timestamps.

Lines are sent in the form `<timestamp>,<channel>,<value>`:
- `timestamp`: Base 10 64-bit System Timer microsecond timestamp (This is not the same as the Unix timestamp! See [Computing Timing Information](#computing-timing-information) for how to compute the Unix timestamp of collected data).
- `channel`: ADC channel the sample was taken from.
- `value`: Base 10 12-bit value captured from the ADC.

One line is sent per sample captured.

#### `/var/sampling/offset.sock`

The offset socket provides information mapping from the System Timer timestamps to Unix microsecond timestamps.

Lines are sent in the form `<unix_timestamp>,<system_timer_timestamp>,<offset>,<skew_ppm>`:
- `unix_timestamp`: 64-bit Unix microsecond timestamp when offset was computed.
- `system_timer_timestamp`: 64-bit System Timer microsecond timestamp when offset was computed.
- `offset`: Computed offset to be used for computing timing information. Note that this value is not necessarily equal to `unix_timestamp - system_timer_timestamp` because several samples are averaged to increase accuracy.
- `skew_ppm`: Computed rate (in parts per million) at which the offset is changing based on previous offset values. This is used for computing timing information.

### Computing Timing Information

The sampling service does not automatically convert between System Timer timestamps and Unix microsecond timestamps to allow some freedom by the client on how clock offsets and skews should be handled.

In the most basic case, the `offset` value provided by the offset socket can be simply added to each sample's System Timer timestamp to convert to the Unix microsecond timestamp. This method is the easiest, however it does not account for changes in the offset over time. While this may be fine for a smaller set of samples (on the order of a few seconds), as the offset is updated there will be inconsistencies in the spacing between samples.

If data will be collected over a longer interval, the `skew_ppm` value can be used to help account for variations in the System Timer hardware clock. In this case, the following formula should be used to calculate the Unix microsecond timestamp of each sample.

<img src="https://render.githubusercontent.com/render/math?math=t_\text{unix}%20=%20\text{offset}%20%2b%20\text{skew_ppm}%20\cdot%20\left(t_\text{system}%20-%20\text{system_timer_timestamp}\right)">

where `offset`, `skew_ppm`, and `system_timer_timestamp` are given by the offset socket.

When new offset information is made available, the application should check that this does not cause overlaps or gaps in timestamps. **There is no guarantee that any two offsets generated by the application will be consistent and result in regular spacing.** Care should be taken by users to ensure that the method of computing timing information chosen does not result in internal inconsistencies in data. The sampling process only guarantees that samples are taken at the correct interval according to the System Timer clock.

## Configuration

The configuration for the sampling can be found at the top of [`dma_sampling.h`](src/dma_sampling.h).

The following sampling options are available.


| Name                     | Default Value | Description                                                                                                                                                                    |
|--------------------------|---------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `SAMPLING_CHANNEL_COUNT` | `1`           | The number of channels to sample.                                                                                                                                              |
| `SAMPLING_CHANNELS`      | `{0}`         | The channels to sample. Length must equal `SAMPLING_CHANNEL_COUNT`.                                                                                                            |
| `SAMPLING_FREQUENCY`     | `8000`        | Frequency in Hz to sample at. If multiple channels are defined then each channel will be sampled at this frequency.                                                            |
| `DMA_PACE_CHAN`          | `7`           | DMA channel to use for the PWM pacing.                                                                                                                                         |
| `DMA_TX_CHAN`            | `9`           | DMA channel to use for SPI TX.                                                                                                                                                 |
| `DMA_RX_CHAN_A`          | `5`           | DMA channel to use for collecting ADC readings from the SPI controller.                                                                                                        |
| `DMA_RX_CHAN_B`          | `6`           | DMA channel to use for collecting timestamp information.                                                                                                                       |
| `BUFFER_PAGES`           | `16`          | Number of pages allocated for the sample buffer. Increasing this value reduces CPU usage but increases delay between batches of samples. Must not exceed 256.                  |
| `PWM_FREQUENCY`          | `1000000`     | PWM pacing frequency in Hz. This should be a multiple of `SAMPLING_FREQUENCY`.                                                                                                 |
| `SPI_FREQUENCY`          | `1000000`     | SPI bus clock frequency in Hz. This can be increased to allow for higher sampling frequencies if SPI packets begin to overlap. Must not exceed value set by MCP3208 datasheet. |


## Credits

Much of the code in the project is based on work done in the ["Streaming analog data from a Raspberry Pi"](https://iosoft.blog/2020/11/16/streaming-analog-data-raspberry-pi) blog series by Jeremy P Bentham. Full credit goes to the author for developing and documenting the method used for communicating with the hardware.

Additionally, the [BCM2835 ARM Peripherals](https://www.raspberrypi.org/app/uploads/2012/02/BCM2835-ARM-Peripherals.pdf) document and the [Errata](https://elinux.org/BCM2835_datasheet_errata) wiki provide good reference for the hardware registers used in this application.
