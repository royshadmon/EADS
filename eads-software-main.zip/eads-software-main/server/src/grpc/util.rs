use color_eyre::eyre::{self, eyre};
use prost_types::value::Kind;

pub fn serde_to_prost(value: &serde_json::Value) -> Result<prost_types::Value, eyre::Report> {
    Ok(match value {
        serde_json::Value::Null => prost_types::Value { kind: None },
        serde_json::Value::Bool(x) => prost_types::Value {
            kind: Some(Kind::BoolValue(*x)),
        },
        serde_json::Value::Number(x) => prost_types::Value {
            kind: Some(Kind::NumberValue(
                x.as_f64()
                    .ok_or_else(|| eyre!("Unable to convert number {}.", x))?,
            )),
        },
        serde_json::Value::String(x) => prost_types::Value {
            kind: Some(Kind::StringValue(x.clone())),
        },
        serde_json::Value::Array(x) => prost_types::Value {
            kind: Some(Kind::ListValue(prost_types::ListValue {
                values: x
                    .iter()
                    .map(serde_to_prost)
                    .collect::<Result<Vec<prost_types::Value>, eyre::Report>>()?,
            })),
        },
        serde_json::Value::Object(x) => prost_types::Value {
            kind: Some(Kind::StructValue(prost_types::Struct {
                fields: x
                    .iter()
                    .map(|(k, v)| serde_to_prost(v).map(|v| (k.clone(), v)))
                    .collect::<Result<_, eyre::Report>>()?,
            })),
        },
    })
}

pub fn prost_struct_to_serde(
    value: &prost_types::Struct,
) -> Result<serde_json::Value, eyre::Report> {
    Ok(serde_json::value::Value::Object(
        value
            .fields
            .iter()
            .map(|(k, v)| prost_value_to_serde(v).map(|v| (k.to_string(), v)))
            .collect::<Result<_, eyre::Report>>()?,
    ))
}

pub fn prost_value_to_serde(value: &prost_types::Value) -> Result<serde_json::Value, eyre::Report> {
    Ok(match &value.kind {
        Some(prost_types::value::Kind::NullValue(_)) => serde_json::value::Value::Null,
        Some(prost_types::value::Kind::NumberValue(x)) => serde_json::value::Value::Number(
            serde_json::Number::from_f64(*x)
                .ok_or_else(|| eyre!("Unable to convert number {}.", *x))?,
        ),
        Some(prost_types::value::Kind::StringValue(x)) => {
            serde_json::value::Value::String(x.to_string())
        }
        Some(prost_types::value::Kind::BoolValue(x)) => serde_json::value::Value::Bool(*x),
        Some(prost_types::value::Kind::StructValue(x)) => prost_struct_to_serde(x)?,
        Some(prost_types::value::Kind::ListValue(x)) => serde_json::value::Value::Array(
            x.values
                .iter()
                .map(prost_value_to_serde)
                .collect::<Result<_, eyre::Report>>()?,
        ),
        None => serde_json::value::Value::Null,
    })
}
