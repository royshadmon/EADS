use std::collections::HashMap;

use crate::db::{DataPoint, HeartbeatDataPoint};

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct RestDataPoint {
    pub stream: uuid::Uuid,
    pub event: uuid::Uuid,
    pub values: Vec<(f64, f64)>,
}

impl From<DataPoint> for RestDataPoint {
    fn from(point: DataPoint) -> Self {
        RestDataPoint {
            stream: point.stream,
            event: point.event,
            values: itertools::iterate(point.time as f64, |&t| {
                t + (point.duration as f64 / point.values.len() as f64)
            })
            .zip(point.values.iter().copied())
            .collect(),
        }
    }
}

/// Collect a vector of DataPoint to a HashMap of vectors containing (time, value) pairs sorted by stream.
pub fn collect_data_points(points: Vec<DataPoint>) -> HashMap<uuid::Uuid, Vec<(f64, f64)>> {
    let mut data = HashMap::new();

    for data_point in points {
        if data.get(&data_point.stream).is_none() {
            data.insert(data_point.stream, Vec::new());
        }

        let mut values: Vec<(f64, f64)> = itertools::iterate(data_point.time as f64, |&t| {
            t + (data_point.duration as f64 / data_point.values.len() as f64)
        })
        .zip(data_point.values.iter().copied())
        .collect();

        data.get_mut(&data_point.stream)
            .unwrap()
            .append(&mut values);
    }

    data
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct RestHeartbeatDataPoint {
    pub stream: uuid::Uuid,
    pub values: Vec<(f64, f64)>,
}

impl From<HeartbeatDataPoint> for RestHeartbeatDataPoint {
    fn from(point: HeartbeatDataPoint) -> Self {
        RestHeartbeatDataPoint {
            stream: point.stream,
            values: itertools::iterate(point.time as f64, |&t| {
                t + (point.duration as f64 / point.values.len() as f64)
            })
            .zip(point.values.iter().copied())
            .collect(),
        }
    }
}

/// Collect a vector of HeartbeatDataPoint to a HashMap of vectors containing (time, value) pairs sorted by stream.
pub fn collect_heartbeat_data_points(
    points: Vec<HeartbeatDataPoint>,
) -> HashMap<uuid::Uuid, Vec<(f64, f64)>> {
    let mut data = HashMap::new();

    for data_point in points {
        if data.get(&data_point.stream).is_none() {
            data.insert(data_point.stream, Vec::new());
        }

        let mut values: Vec<(f64, f64)> = itertools::iterate(data_point.time as f64, |&t| {
            t + (data_point.duration as f64 / data_point.values.len() as f64)
        })
        .zip(data_point.values.iter().copied())
        .collect();

        data.get_mut(&data_point.stream)
            .unwrap()
            .append(&mut values);
    }

    data
}
