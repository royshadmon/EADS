use axum::extract::Path;
use axum::Json;
use axum::{extract::Extension, http::StatusCode, response::IntoResponse};
use serde_json::json;

use crate::db::{self, Calibration};
use crate::server_error::ServerError;

use super::auth_middleware::Auth;

#[tracing::instrument(skip(pool))]
pub async fn get_calibration(
    Path(id): Path<String>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    // Validate the UUID path param
    let uuid = if let Ok(uuid) = uuid::Uuid::parse_str(&id) {
        uuid
    } else {
        return Err(ServerError::KnownError((
            StatusCode::BAD_REQUEST,
            "Invalid UUID parameter.",
        )));
    };

    match db::get_calibration(&pool, uuid).await? {
        None => Err(ServerError::KnownError((
            StatusCode::NOT_FOUND,
            "Calibration not found.",
        ))),
        Some(x) => Ok((StatusCode::OK, Json(x))),
    }
}

#[derive(Debug, serde::Deserialize)]
pub struct CreateCalibration {
    time: u64,
    r#type: String,
    data: Option<serde_json::Value>,
}

#[tracing::instrument(skip(pool, _user, perms))]
pub async fn create_calibration(
    Auth(_user, perms): Auth,
    axum::Json(payload): axum::Json<CreateCalibration>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    perms.assert_has("provision")?;

    let uuid = uuid::Uuid::new_v4();

    db::create_calibration(
        &pool,
        Calibration {
            uuid,
            time: payload.time,
            r#type: payload.r#type,
            data: payload.data,
        },
    )
    .await?;

    Ok((StatusCode::OK, Json(json!({ "uuid": uuid }))))
}
