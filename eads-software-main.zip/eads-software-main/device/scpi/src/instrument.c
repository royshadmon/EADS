#include "instrument.h"

#include <stdint.h>
#include <stdio.h>

#include "scpi/scpi.h"

#include "user_context.h"

scpi_command_t scpi_commands[] = {
    { .pattern = "*IDN?", .callback = SCPI_CoreIdnQ,},
    { .pattern = "*RST", .callback = SCPI_CoreRst,},

    { .pattern = ":SINGle", .callback = Single,},
    { .pattern = ":STOP", .callback = Stop,},

    { .pattern= ":TRIGger:SOURce", .callback = TriggerSource,},
    { .pattern= ":TRIGger:SOURce?", .callback = TriggerSourceQ,},
    { .pattern= ":TRIGger:LEVel", .callback = TriggerLevel,},
    { .pattern= ":TRIGger:LEVel?", .callback = TriggerLevelQ,},

    { .pattern = ":WAVeform:DATA?", .callback = WaveformDataQ,},
    { .pattern = ":WAVeform:TIMEstamp?", .callback = WaveformTimestampQ,},
    { .pattern = ":WAVeform:SOURce", .callback = WaveformSource,},
    { .pattern = ":WAVeform:SOURce?", .callback = WaveformSourceQ,},
    { .pattern = ":WAVeform:PREamble?", .callback = WaveformPreambleQ,},
    SCPI_CMD_LIST_END
};

scpi_result_t Single(scpi_t* context) {
    scpi_user_context_t* user_context = context->user_context;
    user_context->user_state.device_state = SINGLE;

    return SCPI_RES_OK;
}

scpi_result_t Stop(scpi_t* context) {
    scpi_user_context_t* user_context = context->user_context;
    user_context->user_state.device_state = STOPPED;

    return SCPI_RES_OK;
}

scpi_result_t TriggerSource(scpi_t* context) {
    uint32_t channel;

    if (!SCPI_ParamUInt32(context, &channel, TRUE)) {
	return SCPI_RES_ERR;
    }

    if(channel >= SAMPLING_CHANNEL_COUNT) {
	return SCPI_RES_ERR;
    }

    scpi_user_context_t* user_context = context->user_context;
    user_context->user_settings.trigger_channel = channel;

    return SCPI_RES_OK;
}

scpi_result_t TriggerSourceQ(scpi_t* context) {
    scpi_user_context_t* user_context = context->user_context;
    SCPI_ResultUInt32(context, user_context->user_settings.trigger_channel);

    return SCPI_RES_OK;
}

scpi_result_t TriggerLevel(scpi_t* context) {
    uint32_t level;

    if (!SCPI_ParamUInt32(context, &level, TRUE)) {
	return SCPI_RES_ERR;
    }

    if(level >= SAMPLE_MAX_VALUE) {
	return SCPI_RES_ERR;
    }

    scpi_user_context_t* user_context = context->user_context;
    user_context->user_settings.trigger_level = level;

    return SCPI_RES_OK;
}

scpi_result_t TriggerLevelQ(scpi_t* context) {
    scpi_user_context_t* user_context = context->user_context;
    SCPI_ResultUInt32(context, user_context->user_settings.trigger_level);

    return SCPI_RES_OK;
}

scpi_result_t WaveformDataQ(scpi_t* context) {
    scpi_user_context_t* user_context = context->user_context;

    if(user_context->user_state.device_state != STOPPED) {
	return SCPI_RES_ERR;
    }

    uint32_t channel = user_context->user_settings.channel;
    uint32_t points = user_context->user_settings.points;

    uint32_t data[MAX_POINTS];

    ssize_t buffer_offset = user_context->sample_offsets[channel] - points;
    if(buffer_offset < 0) {
	buffer_offset += SAMPLE_BUFFER_LENGTH;
    }

    for(size_t i = 0; i < points; i++) {
	ssize_t buffer_index = (i + buffer_offset) % SAMPLE_BUFFER_LENGTH;
	data[i] = user_context->sample_buffers[channel][buffer_index];
    }

    SCPI_ResultArrayUInt32(context, data, points, SCPI_FORMAT_ASCII);

    return SCPI_RES_OK;
}

scpi_result_t WaveformTimestampQ(scpi_t* context) {
    scpi_user_context_t* user_context = context->user_context;

    if(user_context->user_state.device_state != STOPPED) {
	return SCPI_RES_ERR;
    }

    uint32_t channel = user_context->user_settings.channel;
    uint32_t points = user_context->user_settings.points;

    int32_t data[MAX_POINTS];

    ssize_t buffer_offset = user_context->sample_offsets[channel] - points;
    if(buffer_offset < 0) {
	buffer_offset += SAMPLE_BUFFER_LENGTH;
    }

    for(size_t i = 0; i < points; i++) {
	ssize_t buffer_index = (i + buffer_offset) % SAMPLE_BUFFER_LENGTH;
	data[i] = user_context->timestamp_buffers[channel][buffer_index] - user_context->user_state.trigger_timestamp_origin;
    }

    SCPI_ResultArrayInt32(context, data, points, SCPI_FORMAT_ASCII);

    return SCPI_RES_OK;
}

scpi_result_t WaveformSource(scpi_t* context) {
    uint32_t channel;

    if (!SCPI_ParamUInt32(context, &channel, TRUE)) {
	return SCPI_RES_ERR;
    }

    if(channel >= SAMPLING_CHANNEL_COUNT) {
	return SCPI_RES_ERR;
    }

    scpi_user_context_t* user_context = context->user_context;
    user_context->user_settings.channel = channel;

    return SCPI_RES_OK;
}

scpi_result_t WaveformSourceQ(scpi_t* context) {
    scpi_user_context_t* user_context = context->user_context;
    SCPI_ResultUInt32(context, user_context->user_settings.channel);

    return SCPI_RES_OK;
}

scpi_result_t WaveformPreambleQ(scpi_t* context) {
    scpi_user_context_t* user_context = context->user_context;

    const char* format = "ASCII";

    char preamble[1024];
    int ret = snprintf(preamble, sizeof(preamble),
	    "%s, %u, %f, %f, %d, %f, %d, %i",
	    format, user_context->user_settings.points,
	    (1 / (float)SAMPLING_FREQUENCY), (float) user_context->user_state.trigger_timestamp_origin / 1e6, 0,
	    (float) SAMPLING_ADC_REFERENCE_VOLTAGE / SAMPLE_MAX_VALUE, 0, -1);

    if(ret < 0 || ret >= 256) {
	return SCPI_RES_ERR;
    }

    SCPI_ResultText(context, preamble);

    return SCPI_RES_OK;
}
