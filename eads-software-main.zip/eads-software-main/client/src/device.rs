use std::{
    collections::{HashMap, HashSet},
    sync::Arc,
};

use circular_queue::CircularQueue;
use color_eyre::eyre::{self, eyre};
use futures::{future::try_join_all, StreamExt};
use itertools::Itertools;
use tokio::{
    io::AsyncBufReadExt,
    sync::{mpsc, Mutex},
    time::{Duration, Instant},
};
use tokio_stream::wrappers::errors::BroadcastStreamRecvError;
use tracing::{debug, error, info, warn};

use crate::{
    auth_interceptor,
    channel::Channel,
    hardware::{DeviceHardware, DeviceLedState},
    phase::{Phase, PhaseEvent, PhaseStatus},
    settings::DeviceSettings,
    stream::Stream,
};

use eads_proto::{
    api::{
        event_advisory::{self, PhaseTrigger, PhaseUntrigger},
        event_notification, event_status_response,
        heartbeat::HeartbeatStatus,
        seads_api_client::SeadsApiClient,
        DataSegment, EventAdvisory, EventNotification, EventStatusInfo, GetRegistrationStateInfo,
        Heartbeat, SubscribeEventsInfo, ValidateRegistrationInfo,
    },
    common::{registration_state::RegistrationStatus, DataPoint},
};

/// The number of samples that are stored per channel.
///
/// Increasing this value allows for storing a longer backlog of samples which can be requested by
/// the server for an event, at the cost of memory consumption.
///
/// The memory used by each channel is given by (SAMPLE_BUFFER_LENGTH * 16 bytes).
///
/// The duration of the backlog is given by (SAMPLE_BUFFER_LENGTH / sampling frequency).
const SAMPLE_BUFFER_LENGTH: usize = 2_000_000;

const ADC_CHANNEL_COUNT: usize = 8;
const HEARTBEAT_INTERVAL_MS: u64 = 60000;
const EVENT_HEARTBEAT_TIMEOUT: u64 = 30000;
const SAMPLE_SOCKET_PATH: &str = "/var/sampling/samples.sock";
const OFFSET_SOCKET_PATH: &str = "/var/sampling/offset.sock";

#[derive(Debug, Clone, Copy)]
pub struct Sample {
    pub timestamp: u64,
    pub value: f64,
}

#[derive(Debug, Default)]
pub struct TimeOffset {
    pub offset: i64,
    pub timestamp: i64,
    pub timer: i64,
    pub skew_ppb: i64,
}

#[derive(Debug, PartialEq)]
enum EventType {
    // Event has an associated server entry
    Linked,
    // Event was generated locally
    Local,
}

#[derive(Debug, PartialEq)]
enum EventStatus {
    Running,
    Ending(u64),
    Ended,
}

#[derive(Debug)]
struct Event {
    uuid: String,
    r#type: EventType,
    status: EventStatus,

    // Local streams to be captured as part of this event
    stream_cursors: Vec<(String, u64)>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum DeviceStatus {
    Normal,
    Event,
    Offline,
    OfflineEvent,
}

#[derive(Debug, Copy, Clone)]
struct DeviceState {
    status: DeviceStatus,
}

#[derive(Debug)]
enum NetworkMessage {
    DataSegment(DataSegment),
    Heartbeat(Heartbeat),
}

pub struct Device {
    settings: DeviceSettings,
    hardware: Arc<DeviceHardware>,

    state: Arc<Mutex<DeviceState>>,
    events: Arc<Mutex<Vec<Event>>>,

    phases: Arc<Vec<Phase>>,
}

impl Device {
    pub fn new(settings: DeviceSettings, hardware: Arc<DeviceHardware>) -> Device {
        let phases = settings.phases.iter().cloned().map(Phase::new).collect();

        Device {
            settings,
            hardware,
            state: Arc::new(Mutex::new(DeviceState {
                status: DeviceStatus::Normal,
            })),
            events: Arc::new(Mutex::new(Vec::new())),
            phases: Arc::new(phases),
        }
    }

    pub fn channels(&self) -> Vec<&Channel> {
        self.phases.iter().flat_map(Phase::channels).collect()
    }

    pub fn streams(&self) -> Vec<&Stream> {
        self.phases.iter().flat_map(Phase::streams).collect()
    }

    async fn status(&self) -> DeviceStatus {
        let lock = self.state.lock().await;

        lock.status
    }

    async fn set_status(&self, status: DeviceStatus) {
        let mut lock = self.state.lock().await;

        if lock.status != status {
            lock.status = status;
        }
    }

    pub async fn register(
        &self,
        client: &mut SeadsApiClient<
            tonic::codegen::InterceptedService<
                tonic::transport::Channel,
                auth_interceptor::AuthInterceptor,
            >,
        >,
    ) -> Result<(), eyre::Report> {
        // Timeout for reconnecting to data request stream
        let register_backoff = tokio::time::sleep_until(Instant::now());
        tokio::pin!(register_backoff);

        let mut first_run = true;

        info!("Entering registration mode...");

        loop {
            (&mut register_backoff).await;

            let state = client
                .get_registration_state(tonic::Request::new(GetRegistrationStateInfo::default()))
                .await?;

            match RegistrationStatus::from_i32(state.into_inner().status) {
                Some(RegistrationStatus::Registered) => {
                    self.hardware.set_led(DeviceLedState::RegisterComplete)?;

                    return Ok(());
                }
                Some(RegistrationStatus::Validated) => {
                    self.hardware.set_led(DeviceLedState::RegisterStandby)?;

                    // Wait for the device to become fully registered
                    register_backoff
                        .as_mut()
                        .reset(Instant::now() + Duration::from_millis(5000));
                }
                Some(RegistrationStatus::WaitingForValidation) => {
                    info!("Waiting for registration button press...");
                    self.hardware
                        .set_led(DeviceLedState::RegisterWaitingForPress)?;

                    // Wait for a button press, checking for any updates as we go
                    loop {
                        tokio::select! {
                            _ = tokio::time::sleep(Duration::from_millis(5000)) => {
                                let state = client
                                    .get_registration_state(tonic::Request::new(GetRegistrationStateInfo::default()))
                                    .await?;
                                if Some(RegistrationStatus::WaitingForValidation) != RegistrationStatus::from_i32(state.into_inner().status) {
                                    break;
                                }

                                first_run = false;
                            },
                            _ = self.hardware.wait_for_button_press(first_run) => {
                                info!("Registration button pressed!");

                                client.validate_registration(tonic::Request::new(ValidateRegistrationInfo::default())).await?;

                                break;
                            }
                        }
                    }
                }
                Some(RegistrationStatus::NotRegistered) => {
                    self.hardware.set_led(DeviceLedState::RegisterStandby)?;

                    // Wait for the device to require a button press (check soon to ensure we don't
                    // miss the event)
                    register_backoff
                        .as_mut()
                        .reset(Instant::now() + Duration::from_millis(500));
                }
                None => return Err(eyre!("Protocol error.")),
            }
        }
    }

    pub async fn run(
        &'static self,
        client: &'static mut SeadsApiClient<
            tonic::codegen::InterceptedService<
                tonic::transport::Channel,
                auth_interceptor::AuthInterceptor,
            >,
        >,
    ) -> Result<(), eyre::Report> {
        // Set up buffers for communicating between tasks
        let (offset_tx, offset_rx) = tokio::sync::watch::channel(TimeOffset::default());
        let (network_message_tx, network_message_rx) = mpsc::channel(10 /* TODO */);

        let mut tasks = vec![
            tokio::spawn(self.offset_socket_worker(offset_tx)),
            tokio::spawn(self.sample_socket_worker(offset_rx)),
            tokio::spawn(self.network_worker(client, network_message_rx)),
            tokio::spawn(self.buffer_worker(network_message_tx)),
        ];

        for stream in self.streams() {
            tasks.push(tokio::spawn(stream.worker()))
        }

        for phase in self.phases.iter() {
            tasks.push(tokio::spawn(phase.worker()))
        }

        try_join_all(tasks).await?;

        Ok(())
    }

    async fn buffer_worker(
        &self,
        network_message_tx: mpsc::Sender<NetworkMessage>,
    ) -> Result<(), eyre::Report> {
        let streams = self.streams();

        let mut stream_buffers: HashMap<&str, CircularQueue<Sample>> = streams
            .iter()
            .map(|s| (s.uuid(), CircularQueue::with_capacity(SAMPLE_BUFFER_LENGTH)))
            .collect();

        let mut sample_stream =
            futures::stream::select_all::select_all(self.phases.iter().map(Phase::subscribe));

        let heartbeat_timer = tokio::time::sleep(tokio::time::Duration::ZERO);
        tokio::pin!(heartbeat_timer);

        // TODO: Use intervals and pause when events are not happening
        let event_buffer_timer = tokio::time::sleep(tokio::time::Duration::from_millis(1000));
        tokio::pin!(event_buffer_timer);

        loop {
            // Normal state waiting for events
            tokio::select! {
                // If there are new samples from the stream then process them
                Some((s, item)) = sample_stream.next() => {
                    match item {
                        Ok(sample) => {
                            stream_buffers.get_mut(s).unwrap().push(sample);
                        }
                        Err(BroadcastStreamRecvError::Lagged(count)) => {
                            warn!(
                                "Heartbeats for stream {} fell behind by {} samples.",
                                s, count
                            );
                        }
                    }
                }
                _ = &mut event_buffer_timer => {
                    event_buffer_timer.as_mut().reset(Instant::now() + tokio::time::Duration::from_millis(1000));

                    let mut lock = self.events.lock().await;

                    for event in lock.iter_mut() {
                        // List of streams that are completed that we can drop. When all the streams
                        // have been dropped, the event fully ends
                        let mut ended_streams = Vec::new();

                        let mut event_points = Vec::new();

                        for (stream, cursor) in event.stream_cursors.iter_mut() {
                            let buffer = stream_buffers.get(stream.as_ref() as &str).unwrap();

                            let samples: Vec<_> = if let EventStatus::Ending(end) = event.status {
                                // Check if the most recent sample is after the end. If so, we can
                                // end this stream.
                                if let Some(true) = buffer.iter().next().map(|next| next.timestamp > end) {
                                    ended_streams.push(stream.clone());
                                }

                                buffer
                                    .iter()
                                    .skip_while(|x| x.timestamp > end)
                                    .take_while(|x| x.timestamp > *cursor)
                                    .collect()
                            } else {
                                buffer
                                    .iter()
                                    .take_while(|x| x.timestamp > *cursor)
                                    .collect()
                            };

                            if !samples.is_empty() {
                                // Update the cursor to the last grabbed point, setting it to none if
                                // we are done grabbing points
                                *cursor = samples.first().unwrap().timestamp;

                                let start = samples.last().unwrap().timestamp;
                                let end = samples.first().unwrap().timestamp;

                                if end < start {
                                    warn!("Sample queue went back in time! Dropping samples.")
                                } else {
                                    event_points.push(DataPoint {
                                        stream: stream.clone(),
                                        timestamp: start,
                                        duration: end - start,
                                        values: samples.into_iter().rev().map(|p| p.value).collect(),
                                    });
                                }
                            }
                        }

                        if let EventStatus::Ending(_) = event.status {
                            // Drop all streams that are over and set the flag if we are done with the
                            // event.
                            event.stream_cursors.retain(|(s, _)| !ended_streams.contains(s));

                            if event.stream_cursors.is_empty() {
                                event.status = EventStatus::Ended;

                                info!("Event {} ended.", event.uuid);
                            }
                        }

                        if !event_points.is_empty() {
                            network_message_tx.send(NetworkMessage::DataSegment(DataSegment {
                                event: event.uuid.clone(),
                                data: event_points,
                            })).await?;
                        }
                    }
                }
                // If the heartbeat timer has elapsed then grab the last second of data and send as
                // heartbeat
                //
                // TODO: This should use tokio::time::Interval
                _ = &mut heartbeat_timer => {
                    heartbeat_timer.as_mut().reset(Instant::now() + tokio::time::Duration::from_millis(HEARTBEAT_INTERVAL_MS));

                    let mut heartbeat_points = Vec::new();

                    for stream in streams.iter() {
                        let buffer = stream_buffers.get(stream.uuid()).unwrap();

                        // TODO: Include heartbeat settings as part of the main settings. This
                        // should all be configured on the server.
                        let points = match stream.settings().r#type {
                            crate::settings::StreamType::Waveform => (stream.settings().frequency * 2.0 / 60.0) as usize,
                            crate::settings::StreamType::VoltageRms => 1,
                            crate::settings::StreamType::Frequency => 1,
                        };

                        let samples = buffer.iter().take(points).collect_vec();

                        if !samples.is_empty() {
                            let start = samples.last().unwrap().timestamp;
                            let end = samples.first().unwrap().timestamp;

                            if end < start {
                                warn!("Sample queue went back in time! Dropping samples.")
                            } else {
                                heartbeat_points.push(DataPoint {
                                    stream: stream.settings().uuid.clone(),
                                    timestamp: start,
                                    duration: end - start,
                                    values: samples.into_iter().rev().map(|p| p.value).collect(),
                                });
                            }
                        }
                    }

                    if !heartbeat_points.is_empty() {
                        // Attach the current state to the heartbeat
                        let status = match self.status().await {
                            _ => HeartbeatStatus::Normal,
                        };

                        network_message_tx.send(NetworkMessage::Heartbeat(Heartbeat {
                            status: status.into(),
                            data: heartbeat_points,
                        })).await?;
                    }
                }
            }
        }
    }

    async fn network_worker(
        &self,
        client: &mut SeadsApiClient<
            tonic::codegen::InterceptedService<
                tonic::transport::Channel,
                auth_interceptor::AuthInterceptor,
            >,
        >,
        mut network_message_rx: mpsc::Receiver<NetworkMessage>,
    ) -> Result<(), eyre::Report> {
        // Stream of data requests from server.
        let event_notification_stream: Option<tonic::Streaming<EventNotification>> = None;
        tokio::pin!(event_notification_stream);

        // Timeout for reconnecting to data request stream
        let event_notification_connect_timeout = tokio::time::sleep_until(Instant::now());
        tokio::pin!(event_notification_connect_timeout);

        let event_stream_heartbeat_timeout =
            tokio::time::sleep(Duration::from_millis(EVENT_HEARTBEAT_TIMEOUT));
        tokio::pin!(event_stream_heartbeat_timeout);

        // Stream of events from device phases
        let mut event_stream = futures::stream::select_all::select_all(
            self.phases
                .iter()
                .map(|p| p.subscribe_events().map(|x| (p.uuid(), x))),
        );
        let mut phases_with_faults: HashSet<&str> = HashSet::new();

        loop {
            // Normal state waiting for events
            tokio::select! {
                // If there are new events from phases then handle them
                Some((phase, item)) = event_stream.next() => {
                    match item {
                        Ok(PhaseEvent::StatusChange { time, status }) => {
                            match status {
                                PhaseStatus::Fault => {
                                    phases_with_faults.insert(phase);

                                    match self.status().await {
                                        DeviceStatus::Normal => {
                                            self.hardware.set_led(DeviceLedState::Triggered)?;

                                            match client.send_event_advisory(tonic::Request::new(EventAdvisory {
                                                msg: Some(event_advisory::Msg::PhaseTrigger(PhaseTrigger {
                                                    timestamp: time,
                                                    phase: phase.to_string()
                                                }))})).await {
                                                Ok(res) => debug!("SendEventMessage {:?}", res),
                                                Err(res) => {
                                                    warn!("Failed to upload event message. {}", res);
                                                }
                                            };
                                        },
                                        DeviceStatus::Event => {
                                            phases_with_faults.insert(phase);
                                        },
                                        DeviceStatus::Offline => todo!(),
                                        DeviceStatus::OfflineEvent => todo!(),
                                    }
                                }
                                PhaseStatus::Normal => {
                                    phases_with_faults.remove(phase);

                                    if phases_with_faults.is_empty() {
                                        self.hardware.set_led(DeviceLedState::Standby)?;
                                        self.set_status(DeviceStatus::Normal).await;
                                    }

                                    match client.send_event_advisory(tonic::Request::new(EventAdvisory {
                                        msg: Some(event_advisory::Msg::PhaseUntrigger(PhaseUntrigger {
                                            timestamp: time,
                                            phase: phase.to_string()
                                        }))})).await {
                                        Ok(res) => debug!("SendEventMessage {:?}", res),
                                        Err(res) => {
                                            warn!("Failed to upload event message. {}", res);
                                        }
                                    };
                                }
                            };
                        }
                        Err(BroadcastStreamRecvError::Lagged(count)) => {
                            warn!(
                                "Events for phase {} fell behind by {} samples.",
                                phase, count
                            );
                        }
                    }
                }
                // If we have no stream open then try to connect, allowing for some delay between
                // attempts.
                _ = &mut event_notification_connect_timeout, if event_notification_stream.is_none() => {
                    match client.subscribe_event_notifications(SubscribeEventsInfo {}).await {
                        Ok(stream) => {
                            info!("Successfully connected to data request stream.");
                            *event_notification_stream = Some(stream.into_inner());
                            event_stream_heartbeat_timeout.as_mut().reset(
                                Instant::now() + Duration::from_millis(EVENT_HEARTBEAT_TIMEOUT));
                        },
                        Err(_) => {
                            warn!("Failed to connect to data request stream.");
                            event_notification_connect_timeout.as_mut().reset(Instant::now() + Duration::from_millis(5000));
                        },
                    }
                },
                // Check if any of the events have had heartbeat timeouts
                _ = &mut event_stream_heartbeat_timeout, if event_notification_stream.is_some() => {
                    warn!("Event notification stream heartbeat timeout. Closing stream.");
                    *event_notification_stream = None;

                    event_stream_heartbeat_timeout.as_mut().reset(Instant::now() + Duration::from_millis(EVENT_HEARTBEAT_TIMEOUT));
                },
                // If we do have a stream open, grab messages from it
                res = async { (*event_notification_stream).as_mut().unwrap().message().await }, if event_notification_stream.is_some() => {
                    match res {
                        Ok(Some(req)) => {
                            let mut lock = self.events.lock().await;

                            match req.msg {
                                Some(msg) => match msg {
                                    event_notification::Msg::Start(start) => {
                                        if lock.iter().any(|x| x.uuid == start.uuid) {
                                            warn!("Server request for event start while event is active. Ignoring request.");
                                        } else {
                                            info!("Event {} started.", start.uuid);

                                            lock.push(Event {
                                                uuid: start.uuid,
                                                r#type: EventType::Linked,
                                                status: EventStatus::Running,
                                                stream_cursors: start.streams.into_iter().map(|s| (s, start.start)).collect(),
                                            });
                                        }
                                    },
                                    event_notification::Msg::End(end) => {
                                        if let Some(event) = lock.iter_mut().find(|x| x.uuid == end.uuid) {
                                            info!("Event {} ending.", end.uuid);

                                            event.status = EventStatus::Ending(end.end);
                                        } else {
                                            warn!("Server request for event end for unknown event. Ignoring request.");
                                        }

                                    },
                                    event_notification::Msg::Heartbeat(heartbeat) => {
                                        // Reset the heartbeat timeout
                                        event_stream_heartbeat_timeout.as_mut().reset(
                                            Instant::now() + Duration::from_millis(EVENT_HEARTBEAT_TIMEOUT));

                                        // Check that we know about all events in the heartbeat
                                        for event in heartbeat.events.iter() {
                                            if !lock.iter().any(|x| x.uuid == event.uuid) {
                                                // TODO: Check if any unknown event has one of our
                                                // phases as a trigger and set flag
                                                match client.event_status(tonic::Request::new(EventStatusInfo { uuid: event.uuid.clone() })).await {
                                                    Ok(res) => {
                                                        let msg = res.into_inner();

                                                        // If there are any triggered phases on the
                                                        // server that are not triggered locally
                                                        // then we need to tell the server to
                                                        // untrigger.
                                                        for phase in self.phases.iter() {
                                                            if event.triggered_phases.iter().contains(&phase.uuid().to_string()) {
                                                                match *phase.status().lock().await {
                                                                    PhaseStatus::Normal => {
                                                                        // This phase is triggered
                                                                        // on the server but not
                                                                        // locally. Let's notify
                                                                        // the server it is fine.
                                                                        warn!("Phase {} triggered on server but not locally.", phase.uuid());
                                                                        match client.send_event_advisory(tonic::Request::new(EventAdvisory {
                                                                            msg: Some(event_advisory::Msg::PhaseUntrigger(PhaseUntrigger {
                                                                                timestamp: std::time::SystemTime::now()
                                                                                    .duration_since(std::time::UNIX_EPOCH)
                                                                                    .unwrap()
                                                                                    .as_micros() as u64,
                                                                                phase: phase.uuid().to_string(),
                                                                            }))})).await {
                                                                            Ok(res) => debug!("SendEventMessage {:?}", res),
                                                                            Err(res) => {
                                                                                warn!("Failed to upload phase untrigger message. {}", res);
                                                                            }
                                                                        };
                                                                    },
                                                                    PhaseStatus::Fault => todo!(),
                                                                }
                                                            }
                                                        }

                                                        lock.push(Event {
                                                            uuid: event.uuid.clone(),
                                                            r#type: EventType::Linked,
                                                            // We can assume that the event is
                                                            // running. Ideally, we could map from
                                                            // the response to be sure.
                                                            status: EventStatus::Running,
                                                            // TODO: We should set the end if is is
                                                            // available.
                                                            stream_cursors: msg.streams
                                                                .into_iter()
                                                                .filter(|s| self.streams().iter().any(|x| x.uuid() == s))
                                                                .map(|s| (s, msg.start)).collect(),
                                                        });

                                                        info!("Added event {}, {:?}", event.uuid, lock);
                                                    }
                                                    Err(res) => {
                                                        warn!("Failed to add event {}", res);
                                                    }
                                                };
                                            }
                                        }

                                        // Check that all currently running events are still
                                        // running on the server
                                        for local_event in lock.iter_mut().filter(|x| x.status == EventStatus::Running) {
                                            if !heartbeat.events.iter().any(|event| local_event.uuid == event.uuid) {
                                                match client.event_status(tonic::Request::new(EventStatusInfo { uuid: local_event.uuid.clone() })).await {
                                                    Ok(res) => {
                                                        let msg = res.into_inner();

                                                        match event_status_response::EventStatus::from_i32(msg.status) {
                                                            Some(event_status_response::EventStatus::Running) => {
                                                                error!("Event {} is running but missing from heartbeat.", local_event.uuid);
                                                            },
                                                            Some(event_status_response::EventStatus::Ended) => {
                                                                match msg.end {
                                                                    Some(end) => {
                                                                        // TODO: The server should
                                                                        // tell us when data
                                                                        // requests start and stop.
                                                                        local_event.status = EventStatus::Ending(
                                                                            end + std::time::Duration::from_secs(5).as_micros() as u64);
                                                                    },
                                                                    None => {
                                                                        error!("Event {} is missing end time.", local_event.uuid);

                                                                        // Set the end to now to end the event
                                                                        local_event.status = EventStatus::Ending(
                                                                            std::time::SystemTime::now()
                                                                                .duration_since(std::time::UNIX_EPOCH)
                                                                                .unwrap()
                                                                                .as_micros() as u64
                                                                        );
                                                                    }
                                                                }

                                                            }
                                                            None => {
                                                                error!("Invalid event status response for {}.", local_event.uuid);
                                                            }
                                                        }
                                                    },
                                                    Err(res) => {
                                                        if res.code() == tonic::Code::NotFound {
                                                            error!("Event {} is missing from server.", local_event.uuid);

                                                            // TODO: We might want to upload the
                                                            // event as offline to ensure no data
                                                            // is lost.

                                                            // Set the end to now to end the event
                                                            local_event.status = EventStatus::Ending(
                                                                std::time::SystemTime::now()
                                                                    .duration_since(std::time::UNIX_EPOCH)
                                                                    .unwrap()
                                                                    .as_micros() as u64
                                                            );
                                                        } else {
                                                            warn!("Failed to get status of event {}", res);
                                                        }
                                                    }
                                                };
                                            }
                                        }
                                    },
                                    event_notification::Msg::UpdateStreams(update) => todo!(),
                                },
                                None => {
                                    warn!("Server sent invalid event notification.");
                                }
                            }
                        },
                        Ok(None) => {
                            warn!("Data request stream closed.");
                            *event_notification_stream = None;
                        },
                        Err(e) => {
                            warn!("Data request stream closed with error {}.", e);
                            *event_notification_stream = None;
                        },
                    }
                },
                // Drain the event message queue
                msg = network_message_rx.recv() => {
                    if let Some(msg) = msg {
                        match msg {
                            NetworkMessage::DataSegment(msg) => {
                                match client.send_data_segment(tonic::Request::new(msg)).await {
                                    Ok(res) => debug!("SendDataSegment {:?}", res),
                                    Err(res) => warn!("Failed to upload data segment. {}", res),
                                };
                            },
                            NetworkMessage::Heartbeat(msg) => {
                                match client.send_heartbeat(tonic::Request::new(msg)).await {
                                    Ok(res) => debug!("SendHeartbeat {:?}", res),
                                    Err(res) => warn!("Failed to upload heartbeat. {}", res),
                                };
                            }
                        }
                    }
                }
            }
        }
    }

    async fn sample_socket_worker(
        &self,
        mut offset_rx: tokio::sync::watch::Receiver<TimeOffset>,
    ) -> Result<(), eyre::Report> {
        // Create vectors to allow for speedy lookup of calibration, buffers, and semaphores from adc channel.
        let mut channel_by_adc_channel: Vec<Option<&Channel>> = Vec::new();
        // Here we need to manually unwrap `vec![None; ADC_CHANNEL_COUNT]` to ensure no cloning occurs.
        for _ in 0..ADC_CHANNEL_COUNT {
            channel_by_adc_channel.push(None);
        }
        // Populate the vectors
        for chan in self.channels() {
            let adc_chan = chan.adc_channel();
            channel_by_adc_channel[adc_chan] = Some(chan);
        }

        fn parse_line(line: String) -> Option<(u64, usize, u32)> {
            let mut iter = line.split(',');

            let timestamp = iter.next()?.parse().ok()?;
            let channel: usize = iter.next()?.parse().ok()?;
            let value = iter.next()?.parse().ok()?;

            Some((timestamp, channel, value))
        }

        // Wait for the first offset to come in. Otherwise we will tag some samples with some time
        // around 1970.
        offset_rx.changed().await?;

        loop {
            // Open the sample socket to start receiving lines
            if let Ok(socket) = tokio::net::UnixStream::connect(SAMPLE_SOCKET_PATH).await {
                info!("Connected to sample socket.");
                let reader = tokio::io::BufReader::new(socket);

                let mut lines = reader.lines();

                while let Some(line) = lines.next_line().await? {
                    // Get the most recent offset from the offset channel
                    let offset = offset_rx.borrow();

                    // Parse this line and process if it is valid
                    if let Some((timestamp, channel, value)) = parse_line(line) {
                        // If this channel is used then there will exist a calibration and buffer for it.
                        // Otherwise, we will just throw away this sample.
                        if let Some(Some(chan)) = channel_by_adc_channel.get(channel) {
                            // TODO: This needs some documentation
                            let skew: i64 = (i64::try_from(timestamp).unwrap() - offset.timer)
                                * offset.skew_ppb
                                / 1_000_000_000;
                            match u64::try_from(skew + offset.offset) {
                                Ok(correction) => {
                                    // Push onto the buffer and make other tasks aware of the new sample
                                    chan.add_raw_sample(timestamp + correction, value)
                                        .map_err(|_| eyre!("Failed to add to sample buffer"))?;
                                }
                                Err(_) => {
                                    warn!("Failed to compute timestamp for sample. Dropping.");
                                }
                            }
                        }
                    }
                }
            } else {
                warn!("Failed to connect to sample socket.");
                tokio::time::sleep(Duration::from_millis(5000)).await;
            }
        }
    }

    async fn offset_socket_worker(
        &self,
        offset_tx: tokio::sync::watch::Sender<TimeOffset>,
    ) -> Result<(), eyre::Report> {
        fn parse_line(line: String) -> Option<(i64, i64, i64, i64)> {
            let mut iter = line.split(',');

            let timestamp = iter.next()?.parse().ok()?;
            let timer = iter.next()?.parse().ok()?;
            let offset = iter.next()?.parse().ok()?;
            let skew_ppm: f64 = iter.next()?.parse().ok()?;
            let skew_ppb = (skew_ppm * 1000.0).round() as i64;

            Some((timestamp, timer, offset, skew_ppb))
        }

        loop {
            // Open the sample socket to start receiving lines
            if let Ok(socket) = tokio::net::UnixStream::connect(OFFSET_SOCKET_PATH).await {
                info!("Connected to offset socket.");
                let reader = tokio::io::BufReader::new(socket);

                let mut lines = reader.lines();

                while let Some(line) = lines.next_line().await? {
                    if let Some((timestamp, timer, offset, skew_ppb)) = parse_line(line) {
                        offset_tx
                            .send(TimeOffset {
                                timestamp,
                                timer,
                                offset,
                                skew_ppb,
                            })
                            .expect("Failed to add to socket buffer.");
                    }
                }
            } else {
                warn!("Failed to connect to offset socket.");
                tokio::time::sleep(Duration::from_millis(5000)).await;
            }
        }
    }
}
