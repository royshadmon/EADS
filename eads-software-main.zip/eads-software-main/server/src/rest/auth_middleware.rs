use std::ops::{Deref, DerefMut};

use axum::{
    async_trait,
    extract::{Extension, FromRequest, RequestParts},
    http::StatusCode,
};
use axum_extra::extract::cookie::CookieJar;
use tracing::info;

use crate::{db, server_config::ServerConfig};
use crate::{rest::auth0, server_error::ServerError};

pub struct AuthorizedUser {
    inner: db::User,
}

enum Permission {
    Permission(String),
}

impl Permission {
    #[allow(clippy::manual_map)]
    fn parse(string: &str) -> Self {
        Self::Permission(string.to_owned())
    }
    fn name(&self) -> &str {
        match self {
            Permission::Permission(name) => name,
        }
    }
}

pub struct Permissions {
    inner: Vec<Permission>,
}

impl Permissions {
    pub fn has(&self, perm: &str) -> bool {
        self.inner.iter().any(|x| x.name() == perm)
    }
    pub fn assert_has(&self, item: &str) -> Result<(), ServerError<(StatusCode, &'static str)>> {
        if !self.has(item) {
            info!(item, "user does not have required permissions");
            return Err(ServerError::KnownError((
                StatusCode::UNAUTHORIZED,
                "Permission denied",
            )));
        }

        Ok(())
    }
}

pub struct Auth(pub AuthorizedUser, pub Permissions);

#[async_trait]
impl<B> FromRequest<B> for Auth
where
    B: Send,
{
    type Rejection = ServerError<(StatusCode, &'static str)>;

    async fn from_request(req: &mut RequestParts<B>) -> Result<Self, Self::Rejection> {
        // Grab the server config and sql pool
        let Extension(config): Extension<ServerConfig> = Extension::from_request(req).await?;
        let Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>> =
            Extension::from_request(req).await?;

        let cookies = CookieJar::from_request(req)
            .await
            .map_err(|_| ServerError::KnownError((StatusCode::UNAUTHORIZED, "Missing token.")))?;

        let auth_token = cookies
            .get("auth0-access-token")
            .ok_or(ServerError::KnownError((
                StatusCode::UNAUTHORIZED,
                "`auth0-access-token` cookie is missing",
            )))?;

        let validated_access_jwt = auth0::validate_auth0_access_jwt(auth_token.value(), &config)
            .map_err(|_| ServerError::KnownError((StatusCode::UNAUTHORIZED, "Invalid token.")))?;

        // Get the user object from the database
        let auth0_id = validated_access_jwt.claims.get("sub").unwrap().to_string();
        let user =
            db::get_user_by_auth0(&pool, &auth0_id)
                .await?
                .ok_or(ServerError::KnownError((
                    StatusCode::UNAUTHORIZED,
                    "User does not exist.",
                )))?;

        // Populate the permissions field
        let permissions = validated_access_jwt
            .claims
            .get("permissions")
            .ok_or(ServerError::KnownError((
                StatusCode::UNAUTHORIZED,
                "Token is missing 'permissions' field",
            )))?
            .as_array()
            .ok_or(ServerError::KnownError((
                StatusCode::UNAUTHORIZED,
                "Token 'permissions' field was not a array",
            )))
            .and_then(|perms| {
                perms
                    .iter()
                    .map(|x| x.as_str())
                    .map(|x| x.map(Permission::parse))
                    .collect::<Option<Vec<Permission>>>()
                    .ok_or(ServerError::KnownError((
                        StatusCode::UNAUTHORIZED,
                        "Token 'permissions' contains invalid values",
                    )))
            })?;

        Ok(Auth(
            AuthorizedUser { inner: user },
            Permissions { inner: permissions },
        ))
    }
}

impl Deref for AuthorizedUser {
    type Target = db::User;

    fn deref(&self) -> &Self::Target {
        &self.inner
    }
}

impl DerefMut for AuthorizedUser {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.inner
    }
}
