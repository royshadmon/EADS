#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <netinet/in.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/un.h>
#include <errno.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>

#include "scpi/scpi.h"

#include "instrument.h"
#include "user_context.h"
#include "socket_thread.h"

#define SCPI_INPUT_BUFFER_LENGTH 256
#define SCPI_ERROR_QUEUE_SIZE 17
#define SCPI_IDN1 "RREES"
#define SCPI_IDN2 "EADS"

#define SCPI_SERVER_PORT 5025

static char scpi_input_buffer[SCPI_INPUT_BUFFER_LENGTH];
static scpi_error_t scpi_error_queue_data[SCPI_ERROR_QUEUE_SIZE];

size_t scpi_write(scpi_t* context, const char* data, size_t len);
scpi_result_t scpi_reset(scpi_t* context);

size_t scpi_write(scpi_t* context, const char* data, size_t len) {
    if (context->user_context == NULL) {
        return 0;
    }

    return write(*(int*)((scpi_user_context_t*) context->user_context)->client_fd, data, len);
}

scpi_result_t scpi_reset(scpi_t* context) {
    memcpy(&((scpi_user_context_t*) context->user_context)->user_settings, &default_user_settings, sizeof(default_user_settings));
    memcpy(&((scpi_user_context_t*) context->user_context)->user_state, &default_user_state, sizeof(default_user_state));

    return SCPI_RES_OK;
}

int main(void) {
    //
    // Initialize the SCPI parser
    //

    scpi_interface_t scpi_interface = {
        .write = scpi_write,
        .error = NULL,
        .control = NULL,
        .flush = NULL,
        .reset = scpi_reset
    };


    scpi_t scpi_context;

    const char device_uuid[256];
    strncpy(device_uuid, getenv("BALENA_DEVICE_UUID"), 255);
    const char release_hash[256];
    strncpy(release_hash, getenv("BALENA_RELEASE_HASH"), 255);

    SCPI_Init(&scpi_context,
            scpi_commands,
            &scpi_interface,
            scpi_units_def,
            SCPI_IDN1,
            SCPI_IDN2,
            device_uuid,
            release_hash,
            scpi_input_buffer, SCPI_INPUT_BUFFER_LENGTH,
            scpi_error_queue_data, SCPI_ERROR_QUEUE_SIZE);

    scpi_context.user_context = malloc(sizeof(scpi_user_context_t));
    ((scpi_user_context_t*) scpi_context.user_context)->timestamp_buffers = malloc(sizeof(uint32_t*) * SAMPLING_CHANNEL_COUNT);
    ((scpi_user_context_t*) scpi_context.user_context)->sample_buffers = malloc(sizeof(uint32_t*) * SAMPLING_CHANNEL_COUNT);
    ((scpi_user_context_t*) scpi_context.user_context)->sample_offsets = malloc(sizeof(atomic_size_t) * SAMPLING_CHANNEL_COUNT);

    for(size_t i = 0; i < SAMPLING_CHANNEL_COUNT; i++) {
        ((scpi_user_context_t*) scpi_context.user_context)->timestamp_buffers[i] = malloc(sizeof(uint32_t) * SAMPLE_BUFFER_LENGTH);
        ((scpi_user_context_t*) scpi_context.user_context)->sample_buffers[i] = malloc(sizeof(uint32_t) * SAMPLE_BUFFER_LENGTH);
        ((scpi_user_context_t*) scpi_context.user_context)->sample_offsets[i] = 0;
    }

    memcpy(&((scpi_user_context_t*) scpi_context.user_context)->user_settings, &default_user_settings, sizeof(default_user_settings));
    memcpy(&((scpi_user_context_t*) scpi_context.user_context)->user_state, &default_user_state, sizeof(default_user_state));

    //
    // Create socket threads
    //

    volatile char** socket_line_buffers = malloc(sizeof(char*) * LINE_BUFFER_COUNT);
    for(size_t i = 0; i < LINE_BUFFER_COUNT; i++) {
        socket_line_buffers[i] = malloc(sizeof(char) * LINE_BUFFER_SIZE);
    }
    sem_t line_buffer_sema;
    sem_init(&line_buffer_sema, 0, 0);

    socket_thread_args_t socket_thread_args = {
        .line_buffers = socket_line_buffers,
        .line_buffer_sema = &line_buffer_sema
    };

    pthread_t socket_thread;
    pthread_create(&socket_thread, NULL, socket_thread_function, &socket_thread_args);

    sample_thread_args_t sample_thread_args = {
        .line_buffers = socket_line_buffers,
        .socket_sema = &line_buffer_sema,
        .user_context = scpi_context.user_context
    };

    pthread_t sample_thread;
    pthread_create(&sample_thread, NULL, sample_thread_function, &sample_thread_args);


    //
    // Start the TCP server
    //

    struct sockaddr_in server_addr = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = htonl(INADDR_ANY),
        .sin_port = htons(SCPI_SERVER_PORT)
    };

    int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_fd < 0) {
        perror("socket() failed");
        close(socket_fd);
        exit(-1);
    }

    // Set the socket to reuse local addresses
    int on = 1;
    if (setsockopt(socket_fd, SOL_SOCKET, SO_REUSEADDR, (char*) &on, sizeof(on)) < 0) {
        perror("setsockopt() failed");
        close(socket_fd);
        exit(-1);
    }

    // Bind to the socket
    if (bind(socket_fd, (struct sockaddr*) &server_addr, sizeof(server_addr)) < 0) {
        perror("bind() failed");
        close(socket_fd);
        exit(-1);
    }

    // Listen on the socket
    if (listen(socket_fd, 1) < 0) {
        perror("listen() failed");
        close(socket_fd);
        exit(-1);
    }

    printf("Listening on port %u\n", SCPI_SERVER_PORT);

    //
    // Connection loop
    //

    while(1) {
        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(socket_fd, &fds);
        int ret = select(socket_fd + 1, &fds, NULL, NULL, NULL);

        // Accept the next connection
        struct sockaddr_in client_addr;
        socklen_t client_length = sizeof(client_addr);
        int client_fd = accept(socket_fd, (struct sockaddr*) &client_addr, &client_length);

        if (client_fd < 0) {
            printf("Failed to accept: %d\n", client_fd);
            continue;
        }

        printf("Connection established with %s\n", inet_ntoa(client_addr.sin_addr));

        ((scpi_user_context_t*) scpi_context.user_context)->client_fd = &client_fd;

        char buffer[256];

        // Start talking to the client
        while(1) {
            // Setup settings for reading the socket
            fd_set fds;
            FD_ZERO(&fds);
            FD_SET(client_fd, &fds);
            struct timeval timeout = {
                .tv_sec = 5,
                .tv_usec = 0
            };
            // Read from the socket
            int ret = select(client_fd + 1, &fds, NULL, NULL, &timeout);

            if (ret < 0) {
                perror("select() failed");
                break;
            } else if (ret == 0) {
                SCPI_Input(&scpi_context, NULL, 0);
            } else {
                int bytes_read = recv(client_fd, buffer, sizeof(buffer), 0);
                if (bytes_read < 0) {
                    if (errno != EWOULDBLOCK) {
                        perror("recv() failed");
                        break;
                    }
                } else if (bytes_read == 0) {
                    printf("Connection closed.\n");
                    break;
                } else {
                    SCPI_Input(&scpi_context, buffer, bytes_read);
                }
            }
        }

        close(client_fd);
    }

    for(size_t i = 0; i < LINE_BUFFER_COUNT; i++) {
        free((void*)socket_line_buffers[i]);
    }

    free(scpi_context.user_context);
}
