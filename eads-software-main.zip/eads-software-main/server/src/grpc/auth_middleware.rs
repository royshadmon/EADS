use std::{collections::BTreeMap, env};

use color_eyre::eyre;
use hmac::{Hmac, Mac};
use jwt::VerifyWithKey;
use sha2::Sha256;
use std::task::{Context, Poll};
use tonic::{Request, Status};
use tower::Service;

use crate::db;

pub struct AuthSettings {
    jwt_key: Hmac<Sha256>,
}

impl AuthSettings {
    pub fn new() -> eyre::Result<AuthSettings> {
        let key = Hmac::new_from_slice(env::var("JWT_AUTH_SECRET_KEY")?.as_bytes())?;

        Ok(AuthSettings { jwt_key: key })
    }
}

struct Auth<S> {
    inner: S,
    device: db::Device,
}

impl<S, Request> Service<Request> for Auth<S>
where
    S: Service<Request>,
{
    type Response = S::Response;
    type Error = S::Error;
    type Future = S::Future;

    fn poll_ready(&mut self, cx: &mut Context<'_>) -> Poll<Result<(), Self::Error>> {
        self.inner.poll_ready(cx)
    }

    fn call(&mut self, request: Request) -> Self::Future {
        self.inner.call(request)
    }
}
