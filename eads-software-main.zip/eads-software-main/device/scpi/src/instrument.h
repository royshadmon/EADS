#ifndef INSTRUMENT_H
#define INSTRUMENT_H

#include "scpi/scpi.h"

extern scpi_command_t scpi_commands[];

scpi_result_t Single(scpi_t* context);
scpi_result_t Stop(scpi_t* context);

scpi_result_t TriggerSource(scpi_t* context);
scpi_result_t TriggerSourceQ(scpi_t* context);
scpi_result_t TriggerLevel(scpi_t* context);
scpi_result_t TriggerLevelQ(scpi_t* context);

scpi_result_t WaveformDataQ(scpi_t* context);
scpi_result_t WaveformTimestampQ(scpi_t* context);
scpi_result_t WaveformSource(scpi_t* context);
scpi_result_t WaveformSourceQ(scpi_t* context);
scpi_result_t WaveformPreambleQ(scpi_t* context);

#endif // INSTRUMENT_H
