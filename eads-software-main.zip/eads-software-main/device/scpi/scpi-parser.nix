{ pkgs, ... }:
pkgs.stdenv.mkDerivation rec {
  rev = "224f7cee7c2c5592081e1dec640862f029323782";
  name = "scpi-parser-${rev}";

  src = pkgs.fetchurl {
    url = "https://github.com/j123b567/scpi-parser/archive/${rev}.tar.gz";
    hash = "sha256-6b7bUWAFchiM8HEozVAEoGb+MT7B6krTS+sCj39xPUI=";
  };

  outputs = [ "out" "dev" ];

  installPhase = ''
    mkdir -p $out/lib
    mkdir -p $dev/include

    make PREFIX=./ LIBDIR=$out/lib INCDIR=$dev/include install
  '';
}
