use tonic::{codegen::InterceptedService, transport::Channel};

use eads_proto::api::{seads_api_client::SeadsApiClient, DeviceSettingsRequest};

use super::auth_interceptor::AuthInterceptor;

// TODO: This should be moved to a shared library
#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EventMessageType {
    DeviceOnline,
    DeviceOffline,
    PhaseTrigger,
    PhaseUntrigger,
}

pub async fn get_settings(
    client: &mut SeadsApiClient<InterceptedService<Channel, AuthInterceptor>>,
) -> Result<Option<eads_proto::common::DeviceSettings>, tonic::Status> {
    let response = client
        .get_device_settings(DeviceSettingsRequest::default())
        .await?;

    Ok(response.into_inner().settings)
}
