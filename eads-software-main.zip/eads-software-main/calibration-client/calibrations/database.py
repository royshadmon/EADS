from abc import ABC, abstractmethod

class CalibrationSequence(ABC):
    @classmethod
    @abstractmethod
    def identifier():
        pass

    @classmethod
    @abstractmethod
    def apply(calibration, data):
        pass
    
    @classmethod
    @abstractmethod
    def calibrate(expected, actual):
        pass

class CalibrationDatabase():
    """
    A database of Calibration definitions which are enabled.
    """
    def __init__(self):
        self.database = {}

    def register(self, calibration):
        """
        Register the provided calibration class into the calibration database.
        """
        identifier = calibration.identifier()

        self.database[identifier] = calibration

    def identifiers(self):
        return self.database.keys()

    def get(self, identifier):
        return self.database.get(identifier)

calibrations = CalibrationDatabase()
