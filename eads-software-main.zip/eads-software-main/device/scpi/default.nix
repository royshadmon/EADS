{ pkgs, ... }:
let
  scpi-parser = import ./scpi-parser.nix { inherit pkgs; };
in
rec {
  eads-scpi = pkgs.stdenv.mkDerivation {
    name = "eads-scpi";

    src = ./src;

    nativeBuildInputs = [
      scpi-parser.dev
    ];

    buildInputs = [
      scpi-parser
    ];

    installPhase = ''
      mkdir -p $out/bin

      mv scpi-server $out/bin/scpi-server
    '';
  };

  eads-scpi-start = pkgs.writeScriptBin "eads-scpi-start"
    ''
      #!${pkgs.bash}/bin/sh

      export BALENA_RELEASE_HASH=$(${pkgs.curl}/bin/curl -sS -X GET --header "Content-Type:application/json" \
          "$BALENA_SUPERVISOR_ADDRESS/v2/applications/state?apikey=$BALENA_SUPERVISOR_API_KEY" \
          | ${pkgs.jq}/bin/jq -r "first(.[]).commit" )

      ${eads-scpi}/bin/scpi-server
    '';

  eads-scpi-container = pkgs.dockerTools.buildImage {
    name = "eads-scpi";

    config = {
      Cmd = ["${eads-scpi-start}/bin/eads-scpi-start"];
    };
  };
}
