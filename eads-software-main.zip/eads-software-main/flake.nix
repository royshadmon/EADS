{
  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs";
    cargo2nix.url = "github:cargo2nix/cargo2nix/release-0.11.0";
    flake-utils.url = "github:numtide/flake-utils";
  };

  outputs = { self, nixpkgs, cargo2nix, flake-utils, ... }:
    flake-utils.lib.eachDefaultSystem (system:
      let
        pkgs = import nixpkgs {
          inherit system;
          overlays = [
            cargo2nix.overlays.default
            (final: prev: {
              cargo2nix = cargo2nix.packages.${system}.cargo2nix;
            })
          ];
        };

        # Fix for https://github.com/NixOS/nixpkgs/issues/225963
        pkgsWithPatchelfFix = import nixpkgs {
          inherit system;
          overlays = [
            cargo2nix.overlays.default
            (final: prev: {
              autoPatchelfHook = (prev.autoPatchelfHook.overrideAttrs {propagatedBuildInputs = with pkgs; [ bintools (stdenv.cc.cc.libgcc or null) ]; });
            })
          ];
        };

        api = import ./default.nix {
          pkgs = pkgsWithPatchelfFix;
          inherit cargo2nix;
        };
        device = import ./device {
          inherit pkgs;
        };
      in rec {
        devShell = api.rustPkgs.workspaceShell {
          buildInputs = [
            pkgs.balena-cli
            pkgs.cargo2nix

            # Calibration client
            (pkgs.python3.withPackages (ps: [
              ps.pyvisa
              ps.pyvisa-py
              ps.pyusb

              ps.numpy
              ps.scipy
              ps.matplotlib

              ps.pyqt6
              ps.dataclasses-json
              ps.requests

              # balena-sdk is not packaged with nixpkgs so we will pin our own here.
              (ps.buildPythonPackage rec {
                pname = "balena-sdk";
                version = "14.1.0";
                src = pkgs.fetchFromGitHub {
                  owner = "balena-io";
                  repo = "balena-sdk-python";
                  rev = "v${version}";
                  hash = "sha256-dEHLeOViPQmQajVE/DXnnuJJoloaRtjuYNFbHLicJsw=";
                };
                format = "pyproject";
                doCheck = false;
                nativeBuildInputs = [
                  ps.poetry-core
                ];
                propagatedBuildInputs = [
                  ps.pyjwt
                  ps.twisted
                  ps.pyopenssl
                  ps.pyotp
                  ps.requests
                  ps.semver
                  ps.service-identity
                  ps.deprecated

                  (ps.buildPythonPackage rec {
                    pname = "pine-client";
                    version = "0.2.0";
                    format = "wheel";
                    src = ps.fetchPypi rec {
                      inherit version format;
                      pname = "pine_client";
                      dist = python;
                      python = "py3";
                      hash = "sha256-Jn21iZ7SeBvqdFdv0dLuG7Fum8p1oiIn8H7Gz126FUE=";
                    };
                    doCheck = false;
                    propagatedBuildInputs = [
                      ps.typing-extensions
                    ];
                  })
                ];
              })

            ]))
            pkgs.sqlx-cli
            pkgs.udev
            #pkgs.librevisa # removed upstream?!
            pkgs.libffi
            #pkgs.qt6
            pkgs.qtcreator
          ];
        };

        packages = rec {
          eads-server = api.eads-server;
          eads-server-container = api.eads-server-container;

          eads-client = api.eads-client;
          eads-client-container = api.eads-client-container;

          eads-mocker = api.eads-mocker;

          eads-web = api.eads-web;
          eads-web-container = api.eads-web-container;

          eads-sampling = device.eads-sampling;
          eads-sampling-container = device.eads-sampling-container;

          eads-scpi = device.eads-scpi;
          eads-scpi-container = device.eads-scpi-container;

          eads-gpsd-container = device.eads-gpsd-container;
          eads-chrony-container = device.eads-chrony-container;

          eads-wifi-connect-ui = device.eads-wifi-connect-ui;
          eads-wifi-connect-container = device.eads-wifi-connect-container;
        };

        defaultPackage = packages.eads-server;
      });
}
