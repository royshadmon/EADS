import os
import sys
import json
import glob
import threading
import copy
import time

import numpy as np
from scipy import signal
import pyvisa
from balena import Balena

from PyQt6.QtGui import *
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *

import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg, NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure

from gen.main import Ui_MainWindow

from config import Config
import api
from collect_data import collect_data
import calibrations
from calibrations.calibration import ProvisioningProfile, Calibration, CalibrationProfile, Device
import calibrations.database

import calibrations.linear

from worker import Worker

class MplCanvas(FigureCanvasQTAgg):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        super(MplCanvas, self).__init__(fig)


class MainWindow (QMainWindow, Ui_MainWindow):
    def __init__(self):
        self.threadpool = QThreadPool()

        # Initialize state
        self.rm = pyvisa.ResourceManager("@py")

        # Initialize pyQt widget
        QMainWindow.__init__(self)
        self.setupUi(self)
        sc = MplCanvas(self, width=5, height=4, dpi=100)
        sc.axes.plot([0,1,2,3,4], [10,1,20,3,40])
        self.axes = sc.axes;

        toolbar = NavigationToolbar(sc, self)

        self.plotLayout.addWidget(toolbar)
        self.plotLayout.addWidget(sc)

        # Initialize balena sdk
        self.balena = Balena()
        self.balena.auth.login_with_token(os.getenv("BALENA_ACCESS_TOKEN"))

        # Set up default settings
        self.config = Config(
            servers = [ "http://eads.soe.ucsc.edu" ],
            selected_balena_fleet = None,
            selected_balena_device = None,
        )
        #self.load_settings_file("settings.json")

        self.access_token = os.getenv("EADS_ACCESS_TOKEN")

        # Load profiles from json
        self.profiles = {}
        for file in glob.glob("profiles/*.json"):
            with open(file) as file:
                entry = ProvisioningProfile.from_json(file.read())
                self.profiles[entry.name] = entry

        # Initialize channel table
        self.calibrationInput.addItems(self.profiles.keys())
        self.calibrationInput.currentTextChanged.connect(self.calibration_input_onchange)
        self.calibration_input_onchange(self.calibrationInput.currentText())

        # Set refresh button icons
        refresh_icon = self.style().standardIcon(QStyle.StandardPixmap.SP_BrowserReload)
        self.balenaFleetRefresh.setIcon(refresh_icon)
        self.balenaDeviceRefresh.setIcon(refresh_icon)

        self.balenaFleetRefresh.clicked.connect(self.refresh_balena_fleets)
        self.balenaDeviceRefresh.clicked.connect(self.refresh_balena_devices)
        self.balenaFleetInput.currentTextChanged.connect(self.balena_fleet_changed)
        self.balenaDeviceInput.currentTextChanged.connect(self.balena_device_changed)

        # Connect action events
        self.actionLoadSettings.triggered.connect(self.load_settings)
        self.actionSaveSettings.triggered.connect(self.save_settings)

        # Connect button events
        self.scpiSearchButton.clicked.connect(self.scpi_search)
        self.goButton.clicked.connect(self.provision_device_start)

        # Load the devices for SCPI and balena
        self.scpi_search()
        self.refresh_balena_fleets()

    def load_settings_file(self, filename):
        if filename != "":
            try:
                with open(filename) as file:
                    self.config = Config.from_json(file.read())
            except Exception as e:
                msg = QMessageBox()
                msg.setWindowTitle("Failure")
                msg.setIcon(QMessageBox.Critical)
                msg.setText(f"{filename} is contains errors")
                msg.setDetailedText(repr(e))
                msg.exec()

        self.update_settings()

    def save_settings_file(self, filename):
        if filename != "":
            with open(filename, "w") as file:
                file.write(self.config.to_json())


    def load_settings(self):
        filename, _ = QFileDialog.getOpenFileName(self, 'Open file', "./", "Config files (*.json)")

        self.load_settings_file(filename)


    def save_settings(self):
        filename, _ = QFileDialog.getSaveFileName(self, 'Save file', "./", "Config files (*.json)")

        self.save_settings_file(filename)


    def update_settings(self):
        self.apiServerInput.addItems(self.config.servers)

        if self.config.selected_balena_fleet is not None:
            self.balenaFleetInput.setCurrentIndex(self.balenaFleetInput.findText(self.config.selected_balena_fleet))
        if self.config.selected_balena_device is not None:
            self.balenaDeviceInput.setCurrentIndex(self.balenaDeviceInput.findText(self.config.selected_balena_device))


    def refresh_balena_fleets(self):
        fleets = self.balena.models.application.get_all()
        if fleets is None:
            self.balenaFleetInput.clear()
        else:
            fleets = list(map(lambda fleet: fleet["app_name"], fleets))
            for fleet in fleets:
                if self.balenaFleetInput.findText(fleet) == -1:
                    self.balenaFleetInput.addItem(fleet)

            fleets_to_remove = []
            for i in range(self.balenaFleetInput.count()):
                name = self.balenaFleetInput.itemText(i)
                if name not in fleets:
                    fleets_to_remove.append(name)
            for fleet in fleets_to_remove:
                self.balenaFleetInput.removeItem(self.balenaFleetInput.findText(fleet))

        if self.config.selected_balena_fleet is not None:
            self.balenaFleetInput.setCurrentIndex(self.balenaFleetInput.findText(self.config.selected_balena_fleet))

        self.refresh_balena_devices()

    def refresh_balena_devices(self):
        try:
            devices = self.balena.models.device.get_all_by_application(self.balenaFleetInput.currentText())
        except Exception as e:
            devices = None
            return

        if devices is None:
            self.balenaDeviceInput.clear()
        else:
            device_names = list(map(lambda device: f'{device["device_name"]} ({device["uuid"]})', devices))
            for name, device in zip(device_names, devices):
                if self.balenaDeviceInput.findText(name) == -1:
                    self.balenaDeviceInput.addItem(name, device)

            devices_to_remove = []
            for i in range(self.balenaDeviceInput.count()):
                name = self.balenaDeviceInput.itemText(i)
                if name not in device_names:
                    devices_to_remove.append(name)
            for name in devices_to_remove:
                self.balenaDeviceInput.removeItem(self.balenaDeviceInput.findText(name))

        if self.config.selected_balena_device is not None:
            self.balenaDeviceInput.setCurrentIndex(self.balenaDeviceInput.findText(self.config.selected_balena_device))

    def balena_fleet_changed(self, text):
        self.config.selected_balena_fleet = text
        self.refresh_balena_devices()

    def balena_device_changed(self, text):
        self.config.selected_balena_device = text

    def scpi_search(self):
        """
        Search for available pyVISA devices and update the address list combo
        box.  """
        devices = list(self.rm.list_resources())

        # Get unselected items
        entries = [
            self.scopeAddressInput.itemText(i) \
                for i in range(self.scopeAddressInput.count()) \
                if i != self.scopeAddressInput.currentIndex()
        ]

        # Insert any new devices we didn't have
        for dev in set(devices) - set(entries):
            if dev != self.scopeAddressInput.currentText():
                self.scopeAddressInput.addItem(dev)
            
        # Remove any entries we don't need
        for dev in set(entries) - set(devices):
            self.scopeAddressInput.removeItem(self.scopeAddressInput.findText(dev))

    def provision_device_start(self):
        self.goButton.setEnabled(False)

        worker = Worker(self.provision_device)

        worker.signals.logInfo.connect(self.info)
        worker.signals.logWarn.connect(self.warn)
        worker.signals.logError.connect(self.error)

        worker.signals.finished.connect(self.provision_device_end)
        worker.signals.error.connect(self.provision_device_error)

        self.threadpool.start(worker)

    def provision_device_end(self):
        self.goButton.setEnabled(True)

    def provision_device_error(self, e):
        msg = QMessageBox()
        msg.setWindowTitle("Failure")
        msg.setIcon(QMessageBox.Critical)
        msg.setText(f"Error while provisioning device:\n{str(e[1])}")
        msg.setDetailedText(repr(e[1]))
        msg.exec()

    def provision_device(self, **kwargs):
        """
        Perform provisioning on the selected device and create a corresponding
        device on the selected API server.
        """

        device = Device(phases=copy.deepcopy(self.provisioning_profile.phases))

        for phase_name in device.phases:
            phase = device.phases[phase_name]
            for name in phase.channels:
                channel = phase.channels[name]
                if isinstance(channel.calibration, CalibrationProfile):
                    kwargs["info"].emit(f"Calibration started for {name} channel")
                    # Replace the CalibrationProfile with a Calibration
                    channel.calibration = self.calibrate_channel(channel.calibration, **kwargs)

        kwargs["info"].emit(f"Device: {device}")
        # TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO
        #self.create_api_device(device, **kwargs)
        # TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO

    def calibrate_channel(self, profile, **kwargs):
        """
        Perform the selected calibration sequence on the selected device
        returning a Calibration object.
        """
        calibration = calibrations.database.calibrations.get(profile.type)
        balena_device = self.balenaDeviceInput.currentData()

        device_ip = balena_device["ip_address"].split()[0]

        scope = self.rm.open_resource(self.scopeAddressInput.currentText())
        scope.read_termination = '\n'
        scope.write_termination = '\n'
        scope.timeout = 10000

        device = self.rm.open_resource(f"TCPIP::{device_ip}::5025::SOCKET")
        device.read_termination = '\n'
        device.write_termination = '\n'
        device.timeout = 10000

        # Collect a training and validation set
        kwargs["info"].emit("Gathering calibration training set...")
        training_scope, training_device = collect_data(scope, device, 1)
        print(training_scope, training_device)
        # training_scope_resampled, training_scope_resampled_t = signal.resample(training_scope[:,1], training_device.shape[0], t=training_scope[:,0])
        training_scope_resampled, training_scope_resampled_t = training_scope[:,1], training_scope[:,0]
        kwargs["info"].emit("Gathering calibration validation set...")
        validation_scope, validation_device = collect_data(scope, device, 1)
        # validation_scope_resampled, validation_scope_resampled_t = signal.resample(validation_scope[:,1], validation_device.shape[0], t=validation_scope[:,0])
        validation_scope_resampled, validation_scope_resampled_t = validation_scope[:,1], validation_scope[:,0]

        np.savetxt("scope.csv", training_scope, delimiter=",")
        np.savetxt("device.csv", training_device, delimiter=",")

        exit(0)

        kwargs["info"].emit("Calibrating...")
        cal = calibration.calibrate(training_scope_resampled, training_device[:,1])

        training_calibrated = calibration.apply(cal, training_device[:,1]);
        training_error = training_calibrated - training_scope_resampled
        training_error_rms = np.sqrt(np.mean((training_error)**2))

        validation_calibrated = calibration.apply(cal, validation_device[:,1]);
        validation_error = validation_calibrated - validation_scope_resampled
        validation_error_rms = np.sqrt(np.mean((validation_error)**2))

        kwargs["info"].emit(f"Calibration training error {training_error_rms}Vrms")
        kwargs["info"].emit(f"Calibration validation error {validation_error_rms}Vrms")

        kwargs["info"].emit("Calibration completed")

        return Calibration(
                time=int(time.time()),
                type=profile.type,
                data={ **profile.settings, **cal }
            )

    def create_api_device(self, device, **kwargs):
        """
        Create a new device on the selected API server and 
        """
        balena_device = self.balenaDeviceInput.currentData()
        server = self.apiServerInput.currentText()

        res = api.get_device_by_balena(server, self.access_token, balena_device["uuid"])

        if res.status_code == 404:
            device_uuid = api.create_device(server, self.access_token, balena_device["uuid"])
            kwargs["info"].emit(f"Created device {device_uuid}")

            for phase in device.phases:
                phase_uuid = api.create_phase(server, self.access_token, device_uuid, phase)
                kwargs["info"].emit(f"Created phase {phase_uuid}")

                channel_uuids= {}

                for type in device.phases[phase].channels:
                    channel = device.phases[phase].channels[type]
                    
                    calibration_uuid = api.create_calibration(server, self.access_token, channel.calibration)
                    kwargs["info"].emit(f"Created calibration {calibration_uuid}")
                    channel_uuid = api.create_channel(server, self.access_token, device_uuid, phase_uuid, calibration_uuid, type, channel)
                    kwargs["info"].emit(f"Created channel {channel_uuid}")

                    channel_uuids[type] = channel_uuid

                for type in device.phases[phase].streams:
                    stream = device.phases[phase].streams[type]

                    stream_uuid = api.create_stream(server, self.access_token, device_uuid, phase_uuid, channel_uuids[stream.channel], type, stream)
                    kwargs["info"].emit(f"Created stream {stream_uuid}")
            kwargs["info"].emit(f"Done creating device!")

            token = api.get_device_token(server, self.access_token, device_uuid)
            token_env_var_name = "SEADS_CLIENT_TOKEN"
            # Set the token for the device using the Balena SDK
            env_vars = self.balena.models.environment_variables.device.get_all(balena_device["uuid"])
            matched_env_vars = filter(lambda x: x["name"] == token_env_var_name, env_vars)
            for env_var in matched_env_vars:
                self.balena.models.environment_variables.device.remove(env_var["id"])
            app_env_vars = self.balena.models.environment_variables.device_service_environment_variable.get_all(balena_device["uuid"])
            matched_env_vars = filter(lambda x: x["name"] == token_env_var_name, app_env_vars)
            for env_var in matched_env_vars:
                self.balena.models.environment_variables.device_service_environment_variable.remove(env_var["id"])

            self.balena.models.environment_variables.device.create(balena_device["uuid"], token_env_var_name, token)
            kwargs["info"].emit(f"Device token set.")


        elif res.status_code == 200:
            device_uuid = res.json()["uuid"]
            kwargs["error"].emit(f"Unable to update existing device {device_uuid}. Exiting.")

            # TODO: We should allow the user to cancel, update the calibration, or remove the old device.

        else:
            res.raise_for_status()

    def info(self, msg):
        self.output.appendHtml(f"<p style='color:black;'>{msg}</p>")

    def warn(self, msg):
        self.output.appendHtml(f"<p style='color:olive;'>{msg}</p>")

    def error(self, msg):
        self.output.appendHtml(f"<p style='color:red;'>{msg}</p>")
        
    def calibration_input_onchange(self, value):
        self.provisioning_profile = self.profiles.get(value)

        return 
        self.channelTable.setRowCount(len(self.provisioning_profile.channels))

        for index,(name,channel) in enumerate(self.provisioning_profile.channels.items()):
            # Channel name
            self.channelTable.setCellWidget(index, 0, QLabel(name))
            self.channelTable.cellWidget(index, 0).setAlignment(Qt.AlignCenter)

            # Channel type
            self.channelTable.setCellWidget(index, 1, QLabel(channel.type))
            self.channelTable.cellWidget(index, 1).setAlignment(Qt.AlignCenter)

            # Units label
            self.channelTable.setCellWidget(index, 2, QLabel(channel.units.value))
            self.channelTable.cellWidget(index, 2).setAlignment(Qt.AlignCenter)

            # Computed checkbox
            checkbox = QCheckBox()
            checkbox.setChecked(channel.computed)
            checkbox.setEnabled(False)
            self.channelTable.setCellWidget(index, 3, QWidget())
            checkbox_layout = QHBoxLayout(self.channelTable.cellWidget(index, 1))
            checkbox_layout.addWidget(checkbox)
            checkbox_layout.setAlignment(Qt.AlignCenter)
            checkbox_layout.setContentsMargins(0,0,0,0)
            self.channelTable.cellWidget(index, 3).setLayout(checkbox_layout)

            # Channel sample frequency
            self.channelTable.setCellWidget(index, 4, QLabel(str(channel.frequency) + " Hz"))
            self.channelTable.cellWidget(index, 4).setAlignment(Qt.AlignCenter)

            # Calibration type identifier
            self.channelTable.setCellWidget(index, 5, QLabel(channel.calibration.type))
            self.channelTable.cellWidget(index, 5).setAlignment(Qt.AlignCenter)

            # Calibration settings
            self.channelTable.setCellWidget(index, 6, QLabel(json.dumps(channel.calibration.settings)))
            self.channelTable.cellWidget(index, 6).setAlignment(Qt.AlignVCenter)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    myapp = MainWindow()
    myapp.show()
    sys.exit(app.exec())
