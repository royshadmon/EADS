{ pkgs, ... }:
let
  gpsd = (pkgs.gpsd.override {
    guiSupport = false;
  }).overrideAttrs (oldAttrs: {
    # This is a fix for a bug causing build failures when guiSupport is set to false
    postFixup = ''
      wrapPythonProgramsIn $out/bin "$out $pythonPath"
    '';
  });
in
rec {
  eads-gpsd-start = pkgs.writeScriptBin "eads-gpsd-start"
    ''
    #!${pkgs.bash}/bin/sh

    ${pkgs.coreutils}/bin/stty -F /dev/ttyAMA0 speed 9600
    ${gpsd}/bin/gpsd -Nn /dev/ttyAMA0
    '';

  eads-gpsd-container = pkgs.dockerTools.buildImage {
    name = "eads-gpsd";

    config = {
      Cmd = ["${eads-gpsd-start}/bin/eads-gpsd-start"];
    };
  };
}
