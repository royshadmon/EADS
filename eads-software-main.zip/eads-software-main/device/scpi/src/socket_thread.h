#ifndef SOCKET_THREAD_H
#define SOCKET_THREAD_H

#include <stddef.h>
#include <semaphore.h>

#include "user_context.h"

#define LINE_BUFFER_COUNT 16384
#define LINE_BUFFER_SIZE 256

typedef struct {
    volatile char** line_buffers;
    sem_t* line_buffer_sema;
} socket_thread_args_t;

void* socket_thread_function(void* args);

typedef struct {
    volatile char** line_buffers;
    sem_t* socket_sema;
    scpi_user_context_t* user_context;
} sample_thread_args_t;

void* sample_thread_function(void* args);

#endif
