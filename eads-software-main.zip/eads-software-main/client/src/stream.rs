use color_eyre::eyre;
use futures::StreamExt;
use itertools::Itertools;
use tokio::sync::{broadcast, Mutex};
use tokio_stream::wrappers::{errors::BroadcastStreamRecvError, BroadcastStream};
use tracing::{info, warn};

use crate::{
    channel::Channel,
    device::Sample,
    settings::{self, StreamSettings},
};

const STREAM_BUFFER_LENGTH: usize = 32768;

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum StreamStatus {
    Normal,
    Fault,
}

#[derive(Debug, Clone, Copy)]
pub enum StreamEvent {
    StatusChange { time: u64, status: StreamStatus },
}

pub struct Stream {
    settings: StreamSettings,

    status: Mutex<StreamStatus>,

    sample_bus: broadcast::Sender<Sample>,
    // We must keep one receiver open to keep the broadcast open to ensure sending is always valid.
    // This induces a memory overhead of (sizeof(Sample) * CHANNEL_BUFFER_LENGTH) and messages
    // after this will simply overwrite old values.
    sample_bus_rx: broadcast::Receiver<Sample>,

    event_bus: broadcast::Sender<StreamEvent>,
    // We must keep one receiver open to keep the broadcast open to ensure sending is always valid.
    // This induces a memory overhead of (sizeof(StreamEvent) * CHANNEL_BUFFER_LENGTH) and messages
    // after this will simply overwrite old values.
    event_bus_rx: broadcast::Receiver<StreamEvent>,

    channel_rx: Mutex<BroadcastStream<Sample>>,
    channel_freq: f64,
}

impl Stream {
    pub fn new(settings: StreamSettings, channels: &[Channel]) -> Stream {
        let (sample_bus, sample_bus_rx) = broadcast::channel(STREAM_BUFFER_LENGTH);
        let (event_bus, event_bus_rx) = broadcast::channel(STREAM_BUFFER_LENGTH);

        let channel = channels
            .iter()
            .find(|chan| chan.uuid() == settings.channel)
            .expect("Missing channel for stream");

        Stream {
            settings,
            status: Mutex::new(StreamStatus::Normal),
            sample_bus,
            sample_bus_rx,
            event_bus,
            event_bus_rx,
            channel_rx: Mutex::new(channel.subscribe()),
            channel_freq: channel.frequency(),
        }
    }

    pub fn uuid(&self) -> &str {
        &self.settings.uuid
    }

    pub fn subscribe(&self) -> BroadcastStream<Sample> {
        BroadcastStream::new(self.sample_bus.subscribe())
    }

    pub fn subscribe_events(&self) -> BroadcastStream<StreamEvent> {
        BroadcastStream::new(self.event_bus.subscribe())
    }

    async fn set_status(&self, status: StreamStatus) -> Result<(), eyre::Report> {
        Ok(())
    }

    async fn update_status_for_sample(&self, sample: Sample) -> Result<(), eyre::Report> {
        if let Some(threshold_low) = self.settings.threshold_low {
            if sample.value < threshold_low {
                info!(
                    "Stream {} below threshold with value {}",
                    self.settings.uuid, sample.value
                );

                let mut lock = self.status.lock().await;

                if *lock != StreamStatus::Fault {
                    self.event_bus.send(StreamEvent::StatusChange {
                        time: sample.timestamp,
                        status: StreamStatus::Fault,
                    })?;
                    *lock = StreamStatus::Fault;
                }

                return Ok(());
            }
        }

        if let Some(threshold_high) = self.settings.threshold_high {
            if sample.value > threshold_high {
                info!(
                    "Stream {} above threshold with value {}",
                    self.settings.uuid, sample.value
                );

                let mut lock = self.status.lock().await;

                if *lock != StreamStatus::Fault {
                    self.event_bus.send(StreamEvent::StatusChange {
                        time: sample.timestamp,
                        status: StreamStatus::Fault,
                    })?;
                    *lock = StreamStatus::Fault;
                }

                return Ok(());
            }
        }

        let mut lock = self.status.lock().await;

        if *lock != StreamStatus::Normal {
            self.event_bus.send(StreamEvent::StatusChange {
                time: sample.timestamp,
                status: StreamStatus::Normal,
            })?;
            *lock = StreamStatus::Normal;
        }

        return Ok(());
    }

    /// Send the sample to the bus, updating the status if the value is outside of the nominal
    /// range.
    async fn send_sample(&self, sample: Sample) -> Result<(), eyre::Report> {
        self.update_status_for_sample(sample).await?;

        self.sample_bus.send(sample)?;

        Ok(())
    }

    pub async fn worker(&self) -> Result<(), eyre::Report> {
        let uuid = self.uuid().to_string();

        match self.settings.r#type {
            settings::StreamType::Waveform => {
                let mut stream = self.channel_rx.lock().await;

                loop {
                    if let Some(sample) = stream.next().await {
                        match sample {
                            Ok(sample) => {
                                self.send_sample(sample).await?;
                            }
                            Err(BroadcastStreamRecvError::Lagged(count)) => {
                                warn!("Stream {} fell behind by {} samples.", uuid, count);
                            }
                        }
                    }
                }
            }
            settings::StreamType::VoltageRms => {
                let mut lock = self.channel_rx.lock().await;

                let mut stream = lock
                    .by_ref()
                    .chunks((self.channel_freq / self.settings.frequency) as usize);

                loop {
                    if let Some(samples) = stream.next().await {
                        match samples.into_iter().collect::<Result<Vec<_>, _>>() {
                            Ok(samples) => {
                                let start = samples.first().unwrap().timestamp;
                                let end = samples.last().unwrap().timestamp;

                                let v_rms =
                                    (samples.iter().map(|s| s.value * s.value).sum::<f64>()
                                        / (samples.len() as f64))
                                        .sqrt();

                                self.send_sample(Sample {
                                    timestamp: (start + end) / 2,
                                    value: v_rms,
                                })
                                .await?;
                            }
                            Err(BroadcastStreamRecvError::Lagged(count)) => {
                                warn!("Stream {} fell behind by {} samples.", uuid, count);
                            }
                        }
                    }
                }
            }
            settings::StreamType::Frequency => {
                let mut lock = self.channel_rx.lock().await;

                let mut stream = lock
                    .by_ref()
                    .chunks((self.channel_freq / self.settings.frequency) as usize);

                loop {
                    if let Some(samples) = stream.next().await {
                        match samples.into_iter().collect::<Result<Vec<_>, _>>() {
                            Ok(samples) => {
                                let start = samples.first().unwrap().timestamp;
                                let end = samples.last().unwrap().timestamp;

                                let crossings = samples
                                    .iter()
                                    .tuple_windows()
                                    // Crossings are defined by when one sample is above and the
                                    // following is below, or in the opposite order.
                                    .filter(|(x, y)| {
                                        ((x.value < 0.0) && (y.value > 0.0))
                                            || ((x.value > 0.0) && (y.value < 0.0))
                                    })
                                    // Linear interpolation to determine the crossing point x_c given
                                    // two points on opposing sides.
                                    //
                                    // The crossing point is given by
                                    // x_c = x_0 - ((y_0 * (x_1 - x_0)) / (y_1 - y_2))
                                    .map(|(x, y)| {
                                        (x.timestamp as f64)
                                            - ((x.value * (y.timestamp - x.timestamp) as f64)
                                                / (y.value - x.value))
                                    });

                                // The half-periods are given by the difference between adjacent
                                // crossings.
                                let crossing_diff =
                                    crossings.tuple_windows().map(|(x, y)| y - x).collect_vec();
                                // We can then take the average over the whole sampling window.
                                let period_us =
                                    crossing_diff.iter().sum::<f64>() / crossing_diff.len() as f64;
                                // Now we just convert to Hz and we're done!
                                let frequency = (1e6 / period_us) / 2.0;

                                self.send_sample(Sample {
                                    timestamp: (start + end) / 2,
                                    value: frequency,
                                })
                                .await?;
                            }
                            Err(BroadcastStreamRecvError::Lagged(count)) => {
                                warn!("Stream {} fell behind by {} samples.", uuid, count);
                            }
                        }
                    }
                }
            }
        }
    }

    /// Get the stream's settings.
    pub fn settings(&self) -> &StreamSettings {
        &self.settings
    }
}
