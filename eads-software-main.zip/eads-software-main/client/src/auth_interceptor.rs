use std::env;

use tonic::service::Interceptor;

pub struct AuthInterceptor {
    token_header: tonic::metadata::MetadataValue<tonic::metadata::Ascii>,
}

impl AuthInterceptor {
    pub fn new() -> Result<AuthInterceptor, Box<dyn std::error::Error>> {
        let token = env::var("SEADS_CLIENT_TOKEN")
            .expect("Missing environment variable SEADS_CLIENT_TOKEN");
        let token_header = tonic::metadata::MetadataValue::from_str(&format!("Bearer {}", token))?;

        Ok(AuthInterceptor { token_header })
    }
}

impl Interceptor for AuthInterceptor {
    fn call(&mut self, mut req: tonic::Request<()>) -> Result<tonic::Request<()>, tonic::Status> {
        req.metadata_mut()
            .insert("authorization", self.token_header.clone());
        Ok(req)
    }
}
