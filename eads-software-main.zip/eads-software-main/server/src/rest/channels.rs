use axum::extract::Path;
use axum::Json;
use axum::{extract::Extension, http::StatusCode, response::IntoResponse};
use serde_json::json;

use crate::db::{self, Channel, ChannelType};
use crate::server_error::ServerError;

use super::auth_middleware::Auth;

pub async fn get_channel(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    match db::get_channel(&pool, uuid).await? {
        None => Err(ServerError::KnownError((
            StatusCode::NOT_FOUND,
            "Channel not found.",
        ))),
        Some(x) => Ok((StatusCode::OK, Json(x))),
    }
}

#[derive(serde::Deserialize)]
pub struct CreateChannel {
    pub calibration: uuid::Uuid,
    pub r#type: ChannelType,
    pub frequency: f64,
    pub device: uuid::Uuid,
    pub phase: uuid::Uuid,
}

pub async fn create_channel(
    Auth(_user, perms): Auth,
    axum::Json(payload): axum::Json<CreateChannel>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    perms.assert_has("provision")?;

    let uuid = uuid::Uuid::new_v4();

    db::create_channel(
        &pool,
        Channel {
            uuid,
            calibration: payload.calibration,
            r#type: payload.r#type,
            frequency: payload.frequency,
            device: payload.device,
            phase: payload.phase,
        },
    )
    .await?;

    Ok((StatusCode::OK, Json(json!({ "uuid": uuid }))))
}
