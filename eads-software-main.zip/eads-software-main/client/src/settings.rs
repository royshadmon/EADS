use color_eyre::eyre::{self, eyre};

use crate::calibration;

#[derive(Debug, Clone)]
pub struct ChannelSettings {
    pub uuid: String,
    pub r#type: String,
    pub frequency: f64,
    pub calibration: calibration::Calibration,
}

impl ChannelSettings {
    pub fn new(
        settings: eads_proto::common::ChannelSettings,
    ) -> Result<ChannelSettings, eyre::Report> {
        let calibration = calibration::Calibration::new(
            settings
                .calibration
                .clone()
                .ok_or_else(|| eyre!("Channel {} is missing calibration data.", settings.uuid))?,
        )?;

        Ok(ChannelSettings {
            uuid: settings.uuid.clone(),
            r#type: settings.r#type.clone(),
            frequency: settings.frequency,
            calibration,
        })
    }
}

#[derive(Debug, Clone, Copy)]
pub enum StreamType {
    Waveform,
    VoltageRms,
    Frequency,
}

impl StreamType {
    pub fn parse(string: &str) -> Option<StreamType> {
        match string {
            "waveform" => Some(Self::Waveform),
            "voltage_rms" => Some(Self::VoltageRms),
            "frequency" => Some(Self::Frequency),
            _ => None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct StreamSettings {
    pub uuid: String,
    pub r#type: StreamType,
    pub frequency: f64,
    pub threshold_low: Option<f64>,
    pub threshold_high: Option<f64>,
    pub channel: String,
}

impl StreamSettings {
    pub fn new(
        settings: eads_proto::common::StreamSettings,
    ) -> Result<StreamSettings, eyre::Report> {
        if let Some(r#type) = StreamType::parse(&settings.r#type) {
            Ok(StreamSettings {
                uuid: settings.uuid.clone(),
                r#type,
                frequency: settings.frequency,
                threshold_low: settings.threshold_low,
                threshold_high: settings.threshold_high,
                channel: settings.channel.clone(),
            })
        } else {
            Err(eyre!(
                "Unknown stream type '{}' for stream {}",
                settings.r#type,
                settings.uuid
            ))
        }
    }
}

#[derive(Debug, Clone)]
pub struct PhaseSettings {
    pub uuid: String,
    pub channels: Vec<ChannelSettings>,
    pub streams: Vec<StreamSettings>,
}

impl PhaseSettings {
    pub fn new(settings: eads_proto::common::PhaseSettings) -> Result<PhaseSettings, eyre::Report> {
        Ok(PhaseSettings {
            uuid: settings.uuid,
            channels: settings
                .channels
                .into_iter()
                .map(ChannelSettings::new)
                .collect::<Result<_, eyre::Report>>()?,
            streams: settings
                .streams
                .into_iter()
                .map(StreamSettings::new)
                .collect::<Result<_, eyre::Report>>()?,
        })
    }
}

#[derive(Debug, Clone)]
pub struct DeviceSettings {
    pub uuid: String,
    pub phases: Vec<PhaseSettings>,
    // TODO: This should use geo types
    pub location: Option<(f64, f64)>,
    pub registered: bool,
}

impl DeviceSettings {
    pub fn new(
        settings: eads_proto::common::DeviceSettings,
    ) -> Result<DeviceSettings, eyre::Report> {
        Ok(DeviceSettings {
            uuid: settings.uuid,
            phases: settings
                .phases
                .into_iter()
                .map(PhaseSettings::new)
                .collect::<Result<_, eyre::Report>>()?,
            location: settings.position.map(|p| (p.longitude, p.latitude)),
            registered: settings.registered,
        })
    }
}
