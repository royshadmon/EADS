set -e

if [ "$#" -ne 1 ]; then
    echo "Incorrect number of arguments. Usage: 'manual_provision.sh <balena uuid>'"
    exit -1
fi

balena_uuid=$1

if [ -z $SEADS_API_URI ]; then
    SEADS_API_URI="http://localhost:5001"
    echo "SEADS_API_URI not set. Assuming '$SEADS_API_URI'"
fi

if [ -z $SEADS_API_TOKEN ]; then
    echo "SEADS_API_TOKEN not set. Visit $SEADS_API_URI/oauth/login to get a token."
    exit -1
fi

device_uuid=$(http POST \
    "$SEADS_API_URI/v1/devices" \
    "Cookie:auth0-access-token=$SEADS_API_TOKEN" \
    balena_uuid="$balena_uuid" \
    | jq -r -R '. as $raw | try fromjson.uuid catch error($raw)')
echo "Created device $device_uuid"

calibration_uuid=$(http POST \
    "$SEADS_API_URI/v1/calibrations" \
    "Cookie:auth0-access-token=$SEADS_API_TOKEN" \
    time:=$(($(date +%s%N)/1000)) \
    type="linear" \
    data:='{ "channel": "0", "slope": 0.1933378387952032, "offset": -400.2986421542941 }' \
    | jq -r -R '. as $raw | try fromjson.uuid catch error($raw)')
echo "Created calibration profile $calibration_uuid"

phase_uuid=$(http POST \
    "$SEADS_API_URI/v1/phases" \
    "Cookie:auth0-access-token=$SEADS_API_TOKEN" \
    name="Phase A" \
    device=$device_uuid \
    | jq -r -R '. as $raw | try fromjson.uuid catch error($raw)')
echo "Created device phase $phase_uuid"

channel_uuid=$(http POST \
    "$SEADS_API_URI/v1/channels" \
    "Cookie:auth0-access-token=$SEADS_API_TOKEN" \
    calibration=$calibration_uuid \
    type=voltage \
    frequency:=8000 \
    device=$device_uuid \
    phase=$phase_uuid \
    | jq -r -R '. as $raw | try fromjson.uuid catch error($raw)')
echo "Created channel $channel_uuid"

waveform_stream_uuid=$(http POST \
    "$SEADS_API_URI/v1/streams" \
    "Cookie:auth0-access-token=$SEADS_API_TOKEN" \
    type="waveform" \
    computed:=false \
    units="volts" \
    frequency:=8000 \
    channel=$channel_uuid \
    device=$device_uuid \
    phase=$phase_uuid \
    | jq -r -R '. as $raw | try fromjson.uuid catch error($raw)')
echo "Created waveform stream $waveform_stream_uuid"

# NOTE: We are using 120v ±5% as the default threshold
voltage_rms_stream_uuid=$(http POST \
    "$SEADS_API_URI/v1/streams" \
    "Cookie:auth0-access-token=$SEADS_API_TOKEN" \
    type="voltage_rms" \
    computed:=true \
    units="volts" \
    frequency:=1 \
    threshold_low:=114 \
    threshold_high:=126 \
    channel=$channel_uuid \
    device=$device_uuid \
    phase=$phase_uuid \
    | jq -r -R '. as $raw | try fromjson.uuid catch error($raw)')
echo "Created RMS stream $voltage_rms_stream_uuid"

# NOTE: We are using 60Hz ±0.5% as the default threshold
frequency_stream_uuid=$(http POST \
    "$SEADS_API_URI/v1/streams" \
    "Cookie:auth0-access-token=$SEADS_API_TOKEN" \
    type="frequency" \
    computed:=true \
    units="hz" \
    frequency:=1 \
    threshold_low:=59.7 \
    threshold_high:=60.3 \
    channel=$channel_uuid \
    device=$device_uuid \
    phase=$phase_uuid \
    | jq -r -R '. as $raw | try fromjson.uuid catch error($raw)')
echo "Created frequency stream $frequency_stream_uuid"

token=$(http \
    "$SEADS_API_URI/v1/devices/$device_uuid/token" \
    "Cookie:auth0-access-token=$SEADS_API_TOKEN" \
    | jq -r -R '. as $raw | try fromjson.token catch error($raw)')
echo "Generated token \"$token\""
