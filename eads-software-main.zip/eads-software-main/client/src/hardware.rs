use std::sync::Arc;

use color_eyre::eyre;

use tokio::{sync::RwLock, time::Duration};

const GPIO_LED_RED: u8 = 5;
const GPIO_LED_GREEN: u8 = 6;
const GPIO_LED_BLUE: u8 = 13;

const GPIO_BUTTON: u8 = 19;

#[derive(Debug, PartialEq, Clone, Copy)]
pub struct LedColor {
    pub r: u8,
    pub g: u8,
    pub b: u8,
}

impl LedColor {
    pub const RED: LedColor = LedColor { r: 255, g: 0, b: 0 };
    pub const GREEN: LedColor = LedColor { r: 0, g: 255, b: 0 };
    pub const BLUE: LedColor = LedColor { r: 0, g: 0, b: 255 };
    pub const ORANGE: LedColor = LedColor {
        r: 255,
        g: 165,
        b: 0,
    };
    pub const WHITE: LedColor = LedColor {
        r: 255,
        g: 255,
        b: 255,
    };
}

#[derive(Debug, PartialEq, Clone, Copy)]
pub enum LedState {
    Off,
    Solid(LedColor),
    // Blinking with specified duration on and off
    Blink(LedColor, Duration, Duration),
}

#[derive(Debug, Clone, Copy)]
pub enum DeviceLedState {
    // Registration states
    WifiStandby,
    WifiConnecting,
    RegisterStandby,
    RegisterWaitingForPress,
    RegisterComplete,

    // Normal states
    Standby,
    Offline,
    Triggered,

    // Event states
    OnlineEvent,
    OnlineEventTriggered,
    OfflineEventTriggered,
}

impl DeviceLedState {
    pub fn led_state(&self) -> LedState {
        match self {
            DeviceLedState::WifiStandby => LedState::Blink(
                LedColor::BLUE,
                Duration::from_millis(5000),
                Duration::from_millis(5000),
            ),
            DeviceLedState::WifiConnecting => LedState::Blink(
                LedColor::BLUE,
                Duration::from_millis(1500),
                Duration::from_millis(1500),
            ),
            DeviceLedState::RegisterStandby => LedState::Solid(LedColor::BLUE),
            DeviceLedState::RegisterWaitingForPress => LedState::Blink(
                LedColor::BLUE,
                Duration::from_millis(500),
                Duration::from_millis(500),
            ),
            DeviceLedState::RegisterComplete => LedState::Solid(LedColor::GREEN),
            DeviceLedState::Standby => LedState::Solid(LedColor::GREEN),
            DeviceLedState::Offline => LedState::Blink(
                LedColor::BLUE,
                Duration::from_millis(1500),
                Duration::from_millis(1500),
            ),
            DeviceLedState::Triggered => LedState::Solid(LedColor::ORANGE),
            DeviceLedState::OnlineEvent => LedState::Blink(
                LedColor::GREEN,
                Duration::from_millis(1000),
                Duration::from_millis(1000),
            ),
            DeviceLedState::OnlineEventTriggered => LedState::Blink(
                LedColor::ORANGE,
                Duration::from_millis(1000),
                Duration::from_millis(1000),
            ),
            DeviceLedState::OfflineEventTriggered => LedState::Blink(
                LedColor::ORANGE,
                Duration::from_millis(1000),
                Duration::from_millis(1000),
            ),
        }
    }
}

#[cfg(feature = "rpi")]
pub struct DeviceHardware {
    led_state_tx: tokio::sync::watch::Sender<LedState>,
    led_state_rx: tokio::sync::Mutex<tokio::sync::watch::Receiver<LedState>>,

    gpio: rppal::gpio::Gpio,
}

#[cfg(feature = "rpi")]
impl DeviceHardware {
    pub fn new() -> eyre::Result<DeviceHardware> {
        let gpio = rppal::gpio::Gpio::new()?;

        let (led_state_tx, led_state_rx) = tokio::sync::watch::channel(LedState::Off);

        Ok(DeviceHardware {
            led_state_tx,
            led_state_rx: tokio::sync::Mutex::new(led_state_rx),
            gpio,
        })
    }

    pub async fn worker(&self) -> eyre::Result<()> {
        let mut rx = self.led_state_rx.lock().await;

        let mut state = *rx.borrow_and_update();

        let led_red = Arc::new(RwLock::new(self.gpio.get(GPIO_LED_RED)?.into_output()));
        let led_green = Arc::new(RwLock::new(self.gpio.get(GPIO_LED_GREEN)?.into_output()));
        let led_blue = Arc::new(RwLock::new(self.gpio.get(GPIO_LED_BLUE)?.into_output()));

        loop {
            let token = tokio_util::sync::CancellationToken::new();
            let cloned_token = token.clone();

            let led_red = led_red.clone();
            let led_green = led_green.clone();
            let led_blue = led_blue.clone();

            let task = match state {
                LedState::Off => tokio::spawn(async move {
                    // Turn off the LED
                    led_red.try_write().unwrap().set_low();
                    led_green.try_write().unwrap().set_low();
                    led_blue.try_write().unwrap().set_low();

                    // Wait until the next value is sent
                    cloned_token.cancelled().await;
                }),
                LedState::Solid(color) => tokio::spawn(async move {
                    // Set the LED color
                    led_red
                        .try_write()
                        .unwrap()
                        .set_pwm_frequency(5000.0, f64::from(color.r) / 256.0)
                        .unwrap();
                    led_green
                        .try_write()
                        .unwrap()
                        .set_pwm_frequency(5000.0, f64::from(color.g) / 256.0)
                        .unwrap();
                    led_blue
                        .try_write()
                        .unwrap()
                        .set_pwm_frequency(5000.0, f64::from(color.b) / 256.0)
                        .unwrap();

                    // Wait until the next value is sent
                    cloned_token.cancelled().await;

                    // Clean up PWM
                    led_red.try_write().unwrap().clear_pwm().unwrap();
                    led_green.try_write().unwrap().clear_pwm().unwrap();
                    led_blue.try_write().unwrap().clear_pwm().unwrap();
                }),
                LedState::Blink(color, on, off) => tokio::spawn(async move {
                    let mut flag = true;

                    // Set the initial LED color
                    led_red
                        .try_write()
                        .unwrap()
                        .set_pwm_frequency(5000.0, f64::from(color.r) / 256.0)
                        .unwrap();
                    led_green
                        .try_write()
                        .unwrap()
                        .set_pwm_frequency(5000.0, f64::from(color.g) / 256.0)
                        .unwrap();
                    led_blue
                        .try_write()
                        .unwrap()
                        .set_pwm_frequency(5000.0, f64::from(color.b) / 256.0)
                        .unwrap();

                    loop {
                        tokio::select! {
                            _ = tokio::time::sleep(on), if flag => {
                                flag = false;

                                // Set the LED color
                                led_red
                                    .try_write()
                                    .unwrap()
                                    .set_pwm_frequency(5000.0, 0.0)
                                    .unwrap();
                                led_green
                                    .try_write()
                                    .unwrap()
                                    .set_pwm_frequency(5000.0, 0.0)
                                    .unwrap();
                                led_blue
                                    .try_write()
                                    .unwrap()
                                    .set_pwm_frequency(5000.0, 0.0)
                                    .unwrap();
                            },
                            _ = tokio::time::sleep(off), if !flag => {
                                flag = true;

                                // Set the LED color
                                led_red
                                    .try_write()
                                    .unwrap()
                                    .set_pwm_frequency(5000.0, f64::from(color.r) / 256.0)
                                    .unwrap();
                                led_green
                                    .try_write()
                                    .unwrap()
                                    .set_pwm_frequency(5000.0, f64::from(color.g) / 256.0)
                                    .unwrap();
                                led_blue
                                    .try_write()
                                    .unwrap()
                                    .set_pwm_frequency(5000.0, f64::from(color.b) / 256.0)
                                    .unwrap();
                            },

                            // Wait until the next value is sent
                            _ = cloned_token.cancelled() => {
                                // Clean up PWM
                                led_red.try_write().unwrap().clear_pwm().unwrap();
                                led_green.try_write().unwrap().clear_pwm().unwrap();
                                led_blue.try_write().unwrap().clear_pwm().unwrap();

                                break;
                            }
                        }
                    }
                }),
            };

            loop {
                rx.changed().await?;

                let new_state = *rx.borrow_and_update();

                if state != new_state {
                    state = new_state;
                    break;
                }
            }

            token.cancel();
            task.await?;
        }
    }

    pub fn set_led(&self, state: DeviceLedState) -> eyre::Result<()> {
        self.led_state_tx.send(state.led_state())?;

        Ok(())
    }

    pub async fn wait_for_button_press(&self, reset: bool) -> Result<(), eyre::Report> {
        let mut pin = self.gpio.get(GPIO_BUTTON)?.into_input_pullup();

        pin.set_interrupt(rppal::gpio::Trigger::FallingEdge)?;

        tokio::task::spawn_blocking(move || pin.poll_interrupt(reset, None)).await??;

        Ok(())
    }
}
