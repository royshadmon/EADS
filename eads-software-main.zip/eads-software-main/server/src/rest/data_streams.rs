use axum::extract::Path;
use axum::Json;
use axum::{extract::Extension, http::StatusCode, response::IntoResponse};
use serde_json::json;

use crate::db::{self, DataStream, DataStreamType, DataStreamUnits};
use crate::server_error::ServerError;

use super::auth_middleware::Auth;
use super::util;

#[tracing::instrument(skip(pool))]
pub async fn get_data_stream(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    match db::get_data_stream(&pool, uuid).await? {
        None => Err(ServerError::KnownError((
            StatusCode::NOT_FOUND,
            "Data stream not found.",
        ))),
        Some(x) => Ok((StatusCode::OK, Json(x))),
    }
}

#[tracing::instrument(skip(pool))]
pub async fn get_data_stream_latest_heartbeat(
    Path(uuid): Path<uuid::Uuid>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    match db::get_latest_heartbeat_datapoint_for_stream(&pool, uuid).await? {
        None => Err(ServerError::KnownError((
            StatusCode::NOT_FOUND,
            "Data stream heartbeat not available.",
        ))),
        Some(x) => Ok((StatusCode::OK, Json(util::RestHeartbeatDataPoint::from(x)))),
    }
}

#[derive(Debug, serde::Deserialize)]
pub struct CreateDataStream {
    pub r#type: DataStreamType,
    pub computed: bool,
    pub units: DataStreamUnits,
    pub frequency: f64,
    pub threshold_low: Option<f64>,
    pub threshold_high: Option<f64>,
    pub channel: uuid::Uuid,
    pub device: uuid::Uuid,
    pub phase: uuid::Uuid,
}

#[tracing::instrument(skip(pool, _user, perms))]
pub async fn create_data_stream(
    Auth(_user, perms): Auth,
    axum::Json(payload): axum::Json<CreateDataStream>,
    Extension(pool): Extension<sqlx::Pool<sqlx::Postgres>>,
) -> Result<impl IntoResponse, ServerError<impl IntoResponse>> {
    perms.assert_has("provision")?;

    let uuid = uuid::Uuid::new_v4();

    db::create_data_stream(
        &pool,
        DataStream {
            uuid,
            r#type: payload.r#type,
            computed: payload.computed,
            units: payload.units,
            frequency: payload.frequency,
            threshold_low: payload.threshold_low,
            threshold_high: payload.threshold_high,
            channel: payload.channel,
            device: payload.device,
            phase: payload.phase,
        },
    )
    .await?;

    Ok((StatusCode::OK, Json(json!({ "uuid": uuid }))))
}
