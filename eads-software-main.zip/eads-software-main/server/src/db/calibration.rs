#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct Calibration {
    pub uuid: uuid::Uuid,
    pub time: u64,
    pub r#type: String,
    pub data: Option<serde_json::Value>,
}

#[tracing::instrument(skip(pool, calibration))]
pub async fn create_calibration(
    pool: &sqlx::Pool<sqlx::Postgres>,
    calibration: Calibration,
) -> sqlx::Result<i64> {
    sqlx::query!(
        "INSERT INTO calibrations ( \
            uuid, \
            time, \
            type, \
            data \
        ) VALUES ($1, $2, $3, $4) RETURNING (id)",
        calibration.uuid,
        super::from_unix_timestamp_micros(calibration.time),
        calibration.r#type,
        calibration.data
    )
    .fetch_one(pool)
    .await
    .map(|row| Ok(row.id))?
}

#[tracing::instrument(skip(pool))]
pub async fn get_calibration(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Option<Calibration>> {
    sqlx::query!("SELECT * FROM calibrations WHERE uuid = $1", uuid)
        .fetch_optional(pool)
        .await
        .map(|x| {
            x.map(|row| Calibration {
                uuid: row.uuid,
                time: super::to_unix_timestamp_micros(row.time),
                r#type: row.r#type,
                data: row.data,
            })
        })
}
