import json
from abc import ABC, abstractmethod
from enum import Enum
from typing import Optional, Union, Any
from dataclasses import dataclass
from dataclasses_json import dataclass_json

@dataclass_json
@dataclass
class Calibration:
    time: int
    type: str
    data: dict[str, Any]

@dataclass_json
@dataclass
class CalibrationProfile:
    type: str
    settings: dict[str, Any]

# TODO: Use Literal?
class ChannelType(str, Enum):
    VOLTAGE = "voltage"
    CURRENT = "current"

@dataclass_json
@dataclass
class Channel:
    frequency: float
    calibration: CalibrationProfile

class StreamType(str, Enum):
    WAVEFORM = "waveform"
    VOLTAGE_RMS = "voltage_rms"
    FREQUENCY = "frequency"

class StreamUnits(str, Enum):
    VOLTS = "volts"
    AMPS = "amps"
    WATTS = "watts"
    HERTZ = "hz"

@dataclass_json
@dataclass
class Stream:
    computed: bool
    units: StreamUnits
    frequency: float

    # This is only used to look up which channel to associate this stream with.
    # This will not be sent to the server.
    channel: str

    threshold_low: Optional[float] = None
    threshold_high: Optional[float] = None

@dataclass_json
@dataclass
class Phase:
    channels: dict[ChannelType, Channel]
    streams: dict[StreamType, Stream]

@dataclass_json
@dataclass
class ProvisioningProfile:
    name: str
    phases: dict[str, Phase]

@dataclass_json
@dataclass
class Device:
    phases: dict[str, Phase]
