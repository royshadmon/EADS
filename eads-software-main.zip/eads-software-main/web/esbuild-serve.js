const esbuild = require('esbuild');
const http = require('http');

esbuild.serve({
  servedir: `${__dirname}/build`,
  port: 8001,
}, {
  outdir: "build/static",
  target: "es2020",
  inject: [ "./react-shim.js" ],
}).then(result => {
  const {host, port} = result

  http.createServer((req, res) => {
    const forwardRequest = (path) => {
      console.log(path);
      const options = {
        hostname: host,
        port,
        path,
        method: req.method,
        headers: req.headers,
      }
  
      const proxyReq = http.request(options, proxyRes => {
        // Forward all 404s to the main bundle
        if (proxyRes.statusCode === 404) {
          return forwardRequest("/");
        }
  
        res.writeHead(proxyRes.statusCode, proxyRes.headers);
        proxyRes.pipe(res, { end: true });
      });

      req.pipe(proxyReq, { end: true });
    };

    forwardRequest(req.url);
  }).listen(8000);
});

