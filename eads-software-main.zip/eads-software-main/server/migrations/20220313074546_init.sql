-- Enable the uuid contrib extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
-- Enable PostGIS for location information
CREATE EXTENSION IF NOT EXISTS "postgis";

-- Create users table
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    uuid UUID NOT NULL UNIQUE,
    auth0_id TEXT NOT NULL UNIQUE
);
CREATE INDEX users_uuid_index ON users USING hash (uuid);
CREATE INDEX users_auth0_id_index ON users USING hash (auth0_id);

-- Create device table
CREATE TABLE devices (
    id BIGSERIAL PRIMARY KEY,
    uuid UUID NOT NULL UNIQUE,

    -- User-specified name for device
    name VARCHAR(255),

    -- UUID assigned by Balena
    balena_uuid UUID NOT NULL UNIQUE,

    registered BOOLEAN NOT NULL,
    -- Token used to verify that registration is being done by someone with
    -- access to the device. This will be included as a query parameter in the
    -- redirect from devices' captive portal.
    register_token CHAR(32) NOT NULL,
    -- Stores the state of physical validation (button press). If waiting for
    -- when the device is not registered it should poll this value to enter
    -- waiting for press state. Once the button is pressed, the validation
    -- completed flag should be set to allow the user to continue registration.
    register_waiting_on_validation TIMESTAMP,
    register_validation_completed TIMESTAMP,

    -- Devices _can_ be assigned to a user but do not have to be. This can be
    -- the case after the device is first calibrated and added to the system
    -- before it is activated by the user.
    "user" INT REFERENCES users (id),

    -- Store the location using SRID 4326 (longitude and latitude as used
    -- in GPS provided by device).
    location geography(POINT, 4326),

    -- The last time a heartbeat was received from the device
    last_online TIMESTAMP
);
CREATE INDEX devices_uuid_index ON devices USING hash (uuid);
CREATE INDEX devices_balena_uuid_index ON devices USING hash (balena_uuid);

-- Create calibrations table
CREATE TABLE calibrations (
    id BIGSERIAL PRIMARY KEY,
    uuid UUID NOT NULL UNIQUE,

    -- Time that the calibration was performed.
    time TIMESTAMP NOT NULL,

    -- Type of the calibration. This tells the device which calibration mode
    -- to use and how to interpret the values in the data field.
    type TEXT NOT NULL,
    data JSON
);
CREATE INDEX calibrations_uuid_index ON calibrations USING hash (uuid);

-- Device phases represent groupings of channels on a device. This is used to
-- associate current and voltage channels and allow for recovering a customers
-- phase information when correlated with nearby devices.
CREATE TABLE device_phases (
    id BIGSERIAL PRIMARY KEY,
    uuid UUID NOT NULL UNIQUE,

    -- Name of phase consistent with physical markings on device. e.g. "Phase A"
    name VARCHAR(255),

    -- Device this phase is assigned to
    device INT REFERENCES devices (id) NOT NULL
);
CREATE INDEX device_phases_uuid_index ON device_phases USING hash (uuid);

-- Create channels table
CREATE TYPE channel_type AS ENUM ('voltage', 'current');
CREATE TABLE channels (
    id BIGSERIAL PRIMARY KEY,
    uuid UUID NOT NULL UNIQUE,

    -- All channels must have a calibration profile. This is used by the device
    -- to map between raw sensor readings and the actual measured value.
    calibration INT NOT NULL REFERENCES calibrations (id),

    type channel_type NOT NULL,

    -- Frequency at which this channel should be sampled. The device is not
    -- guaranteed to produce data at this frequency (for instance, if the
    -- device decides to drop some data so that it does not fall behind, it
    -- can decrease the actual frequency used).
    frequency FLOAT8 NOT NULL,

    -- Device this channel is assigned to
    device INT REFERENCES devices (id) NOT NULL,
    -- Phase this channel is assigned to
    phase INT REFERENCES device_phases (id) NOT NULL,

    -- There can only be one channel of each type assigned to a phase
    UNIQUE (type, phase)
);
CREATE INDEX channels_uuid_index ON channels USING hash (uuid);

-- Create data streams table
CREATE TYPE data_stream_type AS ENUM ('waveform', 'voltage_rms', 'frequency');
CREATE TYPE data_stream_units AS ENUM ('volts', 'amps', 'watts', 'hz');
CREATE TABLE data_streams (
    id BIGSERIAL PRIMARY KEY,
    uuid UUID NOT NULL UNIQUE,

    -- Type of the data stream used by the server to decide how to perform analysis
    type data_stream_type NOT NULL,

    -- Is this stream computed or something measured directly?
    computed BOOLEAN NOT NULL,

    -- We need to know what units this stream is in. This will help us tell
    -- how to display this data.
    units data_stream_units NOT NULL,

    -- Frequency at which this stream should be sampled. The device is not
    -- guaranteed to produce data at this frequency (for instance, if the
    -- device decides to drop some data so that it does not fall behind, it
    -- can decrease the actual frequency used).
    frequency FLOAT8 NOT NULL,

    -- Threshold at which point the data on this stream is considered abnormal
    -- and starts an event.
    threshold_low FLOAT8,
    threshold_high FLOAT8,

    -- Channel to use as the source for this stream
    channel INT REFERENCES channels (id) NOT NULL,

    -- Device this stream is assigned to
    device INT REFERENCES devices (id) NOT NULL,
    -- Phase this stream is assigned to
    phase INT REFERENCES device_phases (id) NOT NULL,

    -- There can only be one data stream of each type assigned to a phase
    UNIQUE (type, phase)
);
CREATE INDEX data_streams_uuid_index ON data_streams USING hash (uuid);

CREATE TYPE event_type AS ENUM ('device_triggered');
CREATE TYPE event_status AS ENUM ('running', 'complete');
CREATE TABLE events (
    id BIGSERIAL PRIMARY KEY,
    uuid UUID NOT NULL UNIQUE,

    status event_status NOT NULL,

    -- Type of the event. Currently, only devices can start an event
    type event_type NOT NULL,

    -- Timestamp of when the event started
    start_time TIMESTAMP NOT NULL,
    -- Timestamp of when the event ended
    end_time TIMESTAMP
);
CREATE INDEX event_uuid_index ON events USING hash (uuid);

-- Table for keeping track of which phases have been triggered as part of an event
CREATE TABLE event_phases (
    event INT NOT NULL REFERENCES events (id),
    phase INT NOT NULL REFERENCES device_phases (id),

    UNIQUE (event, phase)
);

-- Table for keeping track of which streams are part of events
CREATE TABLE event_streams (
    event INT NOT NULL REFERENCES events (id),
    stream INT NOT NULL REFERENCES data_streams (id),

    UNIQUE (event, stream)
);

CREATE TABLE event_locations (
    id BIGSERIAL PRIMARY KEY,

    time TIMESTAMP NOT NULL,

    event INT NOT NULL REFERENCES events (id),

    geo geometry NOT NULL
);

CREATE TYPE event_message_type AS ENUM (
    -- Device coming online after having lost connection. Caused by first
    -- successful heartbeat after being offline.
    --
    -- 'data' fields:
    --   - 'device': UUID of device
    'device_online',

    -- Device going offline. Caused by failure to send heartbeats.
    --
    -- 'data' fields:
    --   - 'device': UUID of device
    'device_offline',

    -- Phase exited nominal ranges. This indicates that a device detected
    -- the start of an anomaly on this phase.
    --
    -- 'data' fields:
    --   - 'phase': UUID of phase
    'phase_trigger',

    -- Phase re-entered nominal ranges. This indicates that a device detected
    -- the end of an anomaly on this phase.
    --
    -- 'data' fields:
    --   - 'phase': UUID of phase
    'phase_untrigger'
);
CREATE TABLE event_messages (
    id BIGSERIAL PRIMARY KEY,

    -- Event that this message is part of
    event INT NOT NULL REFERENCES events (id),

    -- Microsecond-accurate timestamp when the message was generated
    time TIMESTAMP NOT NULL,

    -- Type of the event message
    type event_message_type NOT NULL,

    data JSON
);

-- Create data points table
CREATE TABLE event_data_points (
    id BIGSERIAL PRIMARY KEY,

    -- Data stream that this data point was measured from
    stream INT NOT NULL REFERENCES data_streams (id),

    -- Event that this data point is part of
    event INT NOT NULL REFERENCES events (id),

    -- Microsecond-accurate timestamp when the first point in this segment was collected
    time TIMESTAMP NOT NULL,

    -- Microsecond-accurate duration of the sampling segment
    duration INTERVAL NOT NULL,

    -- Value(s) of the data stream at this point
    values FLOAT8[] NOT NULL
);

-- Create heartbeat data points table
CREATE TABLE heartbeat_data_points (
    id BIGSERIAL PRIMARY KEY,

    -- Data stream that this data point was measured from
    stream INT NOT NULL REFERENCES data_streams (id),

    -- Microsecond-accurate timestamp when the first point in this segment was collected
    time TIMESTAMP NOT NULL,

    -- Microsecond-accurate duration of the sampling segment
    duration INTERVAL NOT NULL,

    -- Value(s) of the data stream at this point
    values FLOAT8[] NOT NULL
);
