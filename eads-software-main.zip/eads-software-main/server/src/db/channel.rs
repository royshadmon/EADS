#[derive(Debug, serde::Serialize, serde::Deserialize, sqlx::Type)]
#[serde(rename_all = "snake_case")]
#[sqlx(type_name = "channel_type", rename_all = "snake_case")]
pub enum ChannelType {
    Voltage,
    Current,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct Channel {
    pub uuid: uuid::Uuid,
    pub calibration: uuid::Uuid,
    pub r#type: ChannelType,
    pub frequency: f64,
    pub device: uuid::Uuid,
    pub phase: uuid::Uuid,
}

#[tracing::instrument(skip(pool))]
pub async fn create_channel(
    pool: &sqlx::Pool<sqlx::Postgres>,
    channel: Channel,
) -> sqlx::Result<i64> {
    sqlx::query!(
        "INSERT INTO channels ( \
            uuid, \
            calibration, \
            type, \
            frequency, \
            device, \
            phase \
        ) VALUES ( \
            $1, \
            (SELECT (id) FROM calibrations WHERE uuid=$2), \
            $3, \
            $4, \
            (SELECT (id) FROM devices WHERE uuid=$5), \
            (SELECT (id) FROM device_phases WHERE uuid=$6) \
        ) RETURNING (id)",
        channel.uuid,
        channel.calibration,
        channel.r#type as ChannelType,
        channel.frequency,
        channel.device,
        channel.phase
    )
    .fetch_one(pool)
    .await
    .map(|row| Ok(row.id))?
}

#[tracing::instrument(skip(pool))]
pub async fn get_channel(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Option<Channel>> {
    sqlx::query_as!(
        Channel,
        "SELECT \
            channels.uuid AS uuid, \
            calibrations.uuid AS calibration, \
            channels.type AS \"type!: _\", \
            channels.frequency AS frequency, \
            devices.uuid AS device, \
            device_phases.uuid AS phase \
         FROM channels \
         INNER JOIN calibrations \
            ON calibrations.id = channels.calibration \
         INNER JOIN devices \
            ON devices.id = channels.device \
         INNER JOIN device_phases \
            ON device_phases.id = channels.phase \
         WHERE channels.uuid = $1",
        uuid
    )
    .fetch_optional(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn get_channels_by_device_phase(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Vec<Channel>> {
    sqlx::query_as!(
        Channel,
        "SELECT \
            channels.uuid AS uuid, \
            calibrations.uuid AS calibration, \
            channels.type AS \"type!: _\", \
            channels.frequency AS frequency, \
            devices.uuid AS device, \
            device_phases.uuid AS phase \
         FROM device_phases \
         INNER JOIN channels \
            ON channels.phase = device_phases.id \
         INNER JOIN calibrations \
            ON calibrations.id = channels.calibration \
         INNER JOIN devices \
            ON devices.id = channels.device \
         WHERE device_phases.uuid = $1",
        uuid
    )
    .fetch_all(pool)
    .await
}
