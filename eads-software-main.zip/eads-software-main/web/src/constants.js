export const CONTACT_EMAIL = process.env.REACT_APP_CONTACT_EMAIL;

export const API_URI = process.env.REACT_APP_API_URI;

export const MAPBOX_ACCESS_TOKEN = process.env.REACT_APP_MAPBOX_ACCESS_TOKEN;
