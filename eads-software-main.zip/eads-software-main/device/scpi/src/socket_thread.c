#include "socket_thread.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/select.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#include "user_context.h"

static const char* samples_socket_name = "/var/sampling/samples.sock";

void* socket_thread_function(void* args) {
    socket_thread_args_t* thread_args = (socket_thread_args_t*) args;

    size_t cursor = 0;

    int sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if(sock < 0) {
        perror("Error: can't open socket");
        exit(-1);
    }

    struct sockaddr_un sock_addr;
    sock_addr.sun_family = AF_UNIX;
    strcpy(sock_addr.sun_path, samples_socket_name);

    if(connect(sock, (struct sockaddr*) &sock_addr, sizeof(sock_addr)) < 0) {
        perror("Error: can't connect to socket");
        exit(-1);
    }

    printf("Connected to sample socket\n");

    char socket_buffer[LINE_BUFFER_SIZE * 4096];

    volatile char* buffer = thread_args->line_buffers[cursor];
    size_t offset = 0;

    while(1) {
        int bytes_read = recv(sock, socket_buffer, sizeof(socket_buffer), 0);
        if(bytes_read <= 0) {
            perror("Error: recv failed");
            exit(-1);
        }

        for(size_t i = 0; i < bytes_read; i++) {
            char val = socket_buffer[i];

            if(val == '\n') {
                // Cap off the current string
                buffer[offset] = '\0';

                // Move the cursor to the next buffer
                cursor++;
                if(cursor >= LINE_BUFFER_COUNT) {
                    cursor = 0;
                }
                buffer = thread_args->line_buffers[cursor];

                // Notify the other thread that a value is available
                sem_post(thread_args->line_buffer_sema);

                offset = 0;
            } else {
                buffer[offset++] = val;

                if(offset >= LINE_BUFFER_SIZE - 1) {
                    perror("Error: line too long");
                    exit(-1);
                }
            }
        }
    }
}

void* sample_thread_function(void* args) {
    sample_thread_args_t* thread_args = (sample_thread_args_t*) args;
    scpi_user_context_t* context = thread_args->user_context;

    size_t cursor = 0;

    while(1) {
        int sem_value;
        sem_getvalue(thread_args->socket_sema, &sem_value);
        if(sem_value >= LINE_BUFFER_COUNT - 1) {
            fprintf(stderr, "Line buffer overrun!\n");
            exit(-1);
        }

        // Wait for value from the other thread
        sem_wait(thread_args->socket_sema);

        volatile char* buffer = thread_args->line_buffers[cursor];

        if(context->user_state.device_state != STOPPED) {

            char *end;
            uint64_t timestamp = strtoull(buffer, &end, 10);
            uint64_t channel = strtoull(end + 1, &end, 10);
            uint64_t value = strtoull(end + 1, &end, 10);

            if(channel >= SAMPLING_CHANNEL_COUNT) {
                printf("Invalid channel %llu. Dropping sample.\n", channel);
            } else {
                // If we are waiting for a trigger and this is the correct channel then check the condition
                if((context->user_state.device_state == SINGLE) && (channel == context->user_settings.trigger_channel)) {
                    // Check the trigger condition
                    if(value >= context->user_settings.trigger_level) {
                        context->user_state.trigger_timestamp_origin = timestamp;
                        context->user_state.trigger_sample_count_left = context->user_settings.points;

                        context->user_state.device_state = TRIGGERED;
                    }
                }

                size_t buffer_offset = context->sample_offsets[channel];

                context->sample_offsets[channel]++;
                if(context->sample_offsets[channel] >= SAMPLE_BUFFER_LENGTH) {
                    context->sample_offsets[channel] = 0;
                }

                context->timestamp_buffers[channel][buffer_offset] = timestamp;
                context->sample_buffers[channel][buffer_offset] = value;

                // If this is the sampled channel then decrement the sample count left
                if((context->user_state.device_state == TRIGGERED) && (channel == context->user_settings.trigger_channel)) {
                    if(--(context->user_state.trigger_sample_count_left) == 0) {
                        context->user_state.device_state = STOPPED;
                    }
                }
            }
        }

        // Push the cursor forward
        cursor++;
        if(cursor >= LINE_BUFFER_COUNT) {
            cursor = 0;
        }
    }
}
