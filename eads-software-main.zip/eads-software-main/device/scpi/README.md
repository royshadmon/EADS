# SCPI Server

The SCPI service provides an SCPI interface to the SEADS device to be used in testing and calibration.

## SCPI Interface

The SCPI server is exposed through a TCPIP socket on port 5025.

### Command Reference

The following commands are available.

| Command                                       | Description                                      |
|-----------------------------------------------|--------------------------------------------------|
| [`*IDN?`](#idn---query-identification-string) | Get the identification string for the instrument |
| [`*RST`](#rst---reset-instrument)             | Reset the instrument                             |


#### `*IDN?` - Query identification string

**Command Syntax**: `*IDN?`

Queries the instrument identification string.


**Return Format**: `<manufacturer_string>,<model>,<serial_number>,<software_version>`


#### `*RST` - Reset instrument

**Command Syntax** `*RST`

Resets the instrument.
