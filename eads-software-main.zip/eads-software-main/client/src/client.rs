use std::{env, sync::Arc, path};

use http::Uri;
use serde_json::json;
use tokio::{
    time::{Duration, Instant},
    io::AsyncWriteExt,
    fs
};
use tonic::transport::ClientTlsConfig;
use tracing::warn;
use tracing_error::ErrorLayer;
use tracing_subscriber::{
    filter::EnvFilter, prelude::__tracing_subscriber_SubscriberExt, util::SubscriberInitExt,
    Registry,
};
use tracing_tree::HierarchicalLayer;

use eads_proto::api::seads_api_client::SeadsApiClient;

mod auth_interceptor;
mod calibration;
mod channel;
mod device;
mod grpc_client;
mod hardware;
mod phase;
mod settings;
mod stream;

use crate::hardware::DeviceHardware;

const REGISTRATION_PATH: &str = "/registration/state";

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Install better backtrace support
    color_eyre::install()?;

    // Initialize tracing library
    Registry::default()
        .with(EnvFilter::from_default_env())
        .with(
            HierarchicalLayer::new(2)
                .with_targets(true)
                .with_bracketed_fields(true),
        )
        .with(ErrorLayer::default())
        .init();

    let uri = env::var("SEADS_API_URI")
        .expect("Missing environment variable SEADS_API_URI")
        .parse::<Uri>()?;

    let hardware = Arc::new(DeviceHardware::new()?);

    // Connect to the gRPC API server and create the client object
    let channel = loop {
        let mut builder = tonic::transport::Channel::builder(uri.clone());

        if uri.scheme() == Some(&http::uri::Scheme::HTTPS) {
            builder = builder.tls_config(ClientTlsConfig::new())?;
        }

        match builder.connect().await {
            Ok(channel) => {
                break channel;
            }
            Err(_) => {
                warn!("Failed to connect to server");
                tokio::time::sleep(Duration::from_millis(5000)).await;
            }
        }
    };
    let mut client =
        SeadsApiClient::with_interceptor(channel, auth_interceptor::AuthInterceptor::new()?);

    // Timeout for reconnecting to data request stream
    let settings_backoff = tokio::time::sleep_until(Instant::now());
    tokio::pin!(settings_backoff);

    let mut just_registered = false;

    let device = loop {
        (&mut settings_backoff).await;
        // Retrieve device settings from the server
        let res = match grpc_client::get_settings(&mut client).await {
            Ok(Some(res)) => res,
            _ => {
                warn!("Failed to get device settings from server");
                settings_backoff
                    .as_mut()
                    .reset(Instant::now() + Duration::from_millis(5000));
                continue;
            }
        };

        let settings = match settings::DeviceSettings::new(res) {
            Ok(device_settings) => device_settings,
            Err(e) => {
                warn!("Invalid settings from server. {}", e);
                settings_backoff
                    .as_mut()
                    .reset(Instant::now() + Duration::from_millis(5000));
                continue;
            }
        };

        if settings.registered {
            if just_registered {
                if path::Path::new(REGISTRATION_PATH).exists() {
                    fs::remove_file(REGISTRATION_PATH).await?;
                }

                let mut file = fs::File::create(REGISTRATION_PATH).await?;

                let out = json!({
                    "uuid": settings.uuid,
                    "location": settings.location,
                    "registered": settings.registered,
                });
                let out_vec = serde_json::to_vec(&out)?;

                file.write_all(&out_vec).await?;
            }

            break device::Device::new(settings, hardware.clone());
        } else {
            let device = device::Device::new(settings, hardware.clone());

            device.register(&mut client).await?;

            // We are registered at this point and can dump out the registration info.
            just_registered = true;
        }
    };

    // TODO: We should use a global singleton for these. Unsafe rust will be needed :/
    let device: &device::Device = Box::leak(Box::new(device)) as &'static _;
    let client: &mut SeadsApiClient<
        tonic::codegen::InterceptedService<
            tonic::transport::Channel,
            auth_interceptor::AuthInterceptor,
        >,
    > = Box::leak(Box::new(client)) as &'static mut _;

    // Create the main task for communicating with the server
    tokio::try_join!(device.run(client), hardware.worker())?;

    Ok(())
}
