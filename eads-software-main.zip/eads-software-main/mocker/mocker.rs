use std::fs;
use std::time::{Duration, SystemTime};

use color_eyre::eyre;
use num_complex::Complex;
use tokio::io::AsyncWriteExt;
use tokio::net::UnixStream;

const SAMPLE_SOCKET_PATH: &str = "/var/sampling/samples.sock";
const OFFSET_SOCKET_PATH: &str = "/var/sampling/offset.sock";

const SAMPLING_RATE: f64 = 8000.0;
const SIGNAL_FREQUENCY: f64 = 60.0;
const SIGNAL_AMPLITUDE: f64 = 1.075;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    fs::remove_file(SAMPLE_SOCKET_PATH);
    fs::remove_file(OFFSET_SOCKET_PATH);

    let samples_listener = tokio::net::UnixListener::bind(SAMPLE_SOCKET_PATH)?;
    let offset_listener = tokio::net::UnixListener::bind(OFFSET_SOCKET_PATH)?;

    let epoch = SystemTime::now();

    loop {
        tokio::select! {
            Ok((stream, _addr)) = samples_listener.accept() => {
                println!("new samples client!");
                tokio::spawn(sample_sender_task(stream, epoch));
            }
            Ok((stream, _addr)) = offset_listener.accept() => {
                println!("new offset client!");
                tokio::spawn(offset_sender_task(stream, epoch));
            }
        };
    }
}

async fn sample_sender_task(mut stream: UnixStream, epoch: SystemTime) -> Result<(), eyre::Report> {
    let start_time = SystemTime::now().duration_since(epoch)?;

    let time = itertools::iterate(start_time.as_micros() as u64, |&x| x + 125);

    let step = Complex::new(
        0.0,
        2.0 * std::f64::consts::PI * SIGNAL_FREQUENCY / SAMPLING_RATE,
    )
    .exp();

    let sine_wave =
        itertools::iterate(Complex::new(1.0, 0.0), |&x| x * step).map(|x| SIGNAL_AMPLITUDE * x.im);

    let adc_out = sine_wave.map(|x| ((x + (3.3 / 2.0)) * 4096.0 / 3.3).floor());

    let samples = &mut itertools::zip(time, adc_out).map(|(t, x)| format!("{},0,{}\n", t, x));

    loop {
        let mut buffer: Vec<u8> = Vec::new();

        for sample in samples.take(8000) {
            buffer.append(&mut sample.as_bytes().to_vec());
        }

        stream.write_all(&buffer).await?;

        tokio::time::sleep(Duration::from_secs(1)).await;
    }
}

async fn offset_sender_task(mut stream: UnixStream, epoch: SystemTime) -> Result<(), eyre::Report> {
    loop {
        let time = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)?
            .as_micros();

        let buffer = format!(
            "{},0,{},0\n",
            time,
            epoch.duration_since(SystemTime::UNIX_EPOCH)?.as_micros()
        )
        .into_bytes();

        stream.write_all(&buffer).await?;

        tokio::time::sleep(Duration::from_secs(10)).await;
    }
}
