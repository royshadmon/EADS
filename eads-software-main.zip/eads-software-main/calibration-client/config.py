from dataclasses import dataclass
from dataclasses_json import dataclass_json

@dataclass_json
@dataclass
class Config:
    servers: list[str]
    selected_balena_fleet: str
    selected_balena_device: str
