{ pkgs, ... }:
rec {
  wifi-connect = pkgs.rustPlatform.buildRustPackage rec {
    version = "v4.11.59";
    name = "wifi-connect-${version}";

    src = pkgs.fetchFromGitHub {
      owner = "balena-os";
      repo = "wifi-connect";
      rev = version;
      hash = "sha256-5bmK4SF4jeJJYrZpNAjPc4YyQd0rOBbQZgfOB3W6Es4=";
    };

    # Tell nix that it is okay to depend on a git module.
    cargoLock = {
      lockFile = "${src}/Cargo.lock";
      outputHashes = {
        "network-manager-0.13.3" = "sha256-h9xM9qNsk4Ac6vnkDiKskfry8bWUpK3v8Jne5hdbGs4=";
      };
    };

    cargoHash = "sha256-OlvQwmb/DpLVtlFbIu8WMpbD94vYSb2SFWgJ6OMQ57A=";

    buildInputs = [
      pkgs.dbus
    ];

    nativeBuildInputs = [
      pkgs.pkg-config
    ];
  };

  eads-wifi-connect-ui = pkgs.buildNpmPackage {
    pname = "eads-wifi-connect-ui";
    version = "1.0.0";

    src = ./ui;

    nativeBuildInputs = [
      pkgs.nodejs
      pkgs.python3
    ];

    # https://github.com/webpack/webpack/issues/14532
    NODE_OPTIONS = "--openssl-legacy-provider";

    installPhase = ''
      mkdir -p $out/share/wifi-connect-ui
      mv ./build/* $out/share/wifi-connect-ui
    '';

    npmDepsHash = "sha256-G1wcujuYqIYGpx6a938aM1165VS2rKTv9ERet9it9CQ=";
  };

  eads-wifi-connect-start = pkgs.writeScriptBin "start"
    ''
      #!${pkgs.bash}/bin/bash

      # Directories needed for dnamasq
      ${pkgs.coreutils}/bin/mkdir -p /var/lib/misc
      ${pkgs.coreutils}/bin/mkdir -p /var/run

      export DBUS_SYSTEM_BUS_ADDRESS=unix:path=/host/run/dbus/system_bus_socket
      
      REGISTERED=0
      # Are we already registered?
      if [ -f /registration/status ]; then
        # TODO: We should check the registered flag in the json here.
        REGISTERED=1
      fi

      if [ $REGISTERED -eq 1 ]; then
          printf 'Skipping WiFi Connect\n'
      else
          printf 'Starting WiFi Connect\n'
          ${wifi-connect}/bin/wifi-connect --ui-directory ${eads-wifi-connect-ui}/share/wifi-connect-ui -s "EADS Setup"
      fi
      
      # Start your application here.
      ${pkgs.coreutils}/bin/sleep infinity
    '';

  eads-wifi-connect-container = pkgs.dockerTools.buildImage {
    name = "eads-wifi-connect";

    copyToRoot = pkgs.buildEnv {
      name = "image-root";
      paths = [
        pkgs.dockerTools.binSh
        pkgs.fakeNss
        pkgs.dnsmasq
      ];
      pathsToLink = [ "/bin" "/etc" "/var" ];
    };

    config = {
      Cmd = ["${eads-wifi-connect-start}/bin/start"];
    };
  };
}
