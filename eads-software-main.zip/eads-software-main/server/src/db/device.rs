use geozero::wkb;
use serde::ser::SerializeStruct;
use sqlx::types::time;

pub struct Device {
    pub uuid: uuid::Uuid,
    pub balena_uuid: uuid::Uuid,
    pub name: Option<String>,
    pub location: Option<geo_types::Point<f64>>,
    pub user: Option<uuid::Uuid>,
    pub last_online: Option<u64>,
}

impl serde::Serialize for Device {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let mut state = serializer.serialize_struct("Device", 6)?;
        state.serialize_field("uuid", &self.uuid)?;
        state.serialize_field("balena_uuid", &self.balena_uuid)?;
        state.serialize_field("name", &self.name)?;
        state.serialize_field("longitude", &self.location.map(|loc| loc.x()))?;
        state.serialize_field("latitude", &self.location.map(|loc| loc.y()))?;
        state.serialize_field("user", &self.user)?;
        state.serialize_field("last_online", &self.last_online)?;
        state.end()
    }
}

#[derive(Debug, serde::Deserialize)]
pub struct CreateDevice {
    balena_uuid: uuid::Uuid,
}

#[tracing::instrument(skip(pool, device))]
pub async fn create_device(
    pool: &sqlx::Pool<sqlx::Postgres>,
    device: CreateDevice,
) -> sqlx::Result<uuid::Uuid> {
    let uuid = uuid::Uuid::new_v4();

    sqlx::query!(
        "INSERT INTO devices ( \
            uuid, \
            balena_uuid,
            registered
        ) VALUES ( \
            $1, \
            $2, \
            FALSE
        )",
        uuid,
        device.balena_uuid,
    )
    .execute(pool)
    .await?;

    Ok(uuid)
}

// Struct used to decode device objects from the db
struct DeviceRec {
    pub uuid: uuid::Uuid,
    pub balena_uuid: uuid::Uuid,
    pub name: Option<String>,
    pub location: wkb::Decode<geo_types::Geometry<f64>>,
    pub user: Option<uuid::Uuid>,
    pub last_online: Option<time::PrimitiveDateTime>,
}

impl From<DeviceRec> for Device {
    fn from(rec: DeviceRec) -> Self {
        Self {
            uuid: rec.uuid,
            balena_uuid: rec.balena_uuid,
            name: rec.name,
            location: rec.location.geometry.and_then(|x| x.try_into().ok()),
            user: rec.user,
            last_online: rec.last_online.map(super::to_unix_timestamp_micros),
        }
    }
}

#[tracing::instrument(skip(pool))]
pub async fn get_device(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Option<Device>> {
    sqlx::query_as!(
        DeviceRec,
        "SELECT \
            devices.uuid AS uuid, \
            devices.balena_uuid AS balena_uuid, \
            devices.name AS name, \
            devices.location::geometry AS \"location!: _\", \
            users.uuid AS \"user!: _\", \
            devices.last_online AS last_online \
         FROM devices \
         LEFT JOIN users \
            ON users.id = devices.\"user\" \
         WHERE devices.uuid = $1",
        uuid
    )
    .fetch_optional(pool)
    .await
    .map(|x| x.map(Into::into))
}

#[tracing::instrument(skip(pool))]
pub async fn get_device_by_balena_uuid(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Option<Device>> {
    sqlx::query_as!(
        DeviceRec,
        "SELECT \
            devices.uuid AS uuid, \
            devices.balena_uuid AS balena_uuid, \
            devices.name AS name, \
            devices.location::geometry AS \"location!: _\", \
            users.uuid AS \"user!: _\", \
            devices.last_online AS last_online \
         FROM devices \
         LEFT JOIN users \
            ON users.id = devices.\"user\" \
         WHERE devices.balena_uuid = $1",
        uuid
    )
    .fetch_optional(pool)
    .await
    .map(|x| x.map(Into::into))
}

#[tracing::instrument(skip(pool))]
pub async fn get_devices(pool: &sqlx::Pool<sqlx::Postgres>) -> sqlx::Result<Vec<Device>> {
    sqlx::query_as!(
        DeviceRec,
        "SELECT \
            devices.uuid AS \"uuid!: _\", \
            devices.balena_uuid AS \"balena_uuid!: _\", \
            devices.name AS name, \
            devices.location::geometry AS \"location!: _\", \
            users.uuid AS \"user!: _\", \
            devices.last_online AS last_online \
         FROM devices \
         LEFT JOIN users \
            ON users.id = devices.\"user\" \
         WHERE devices.registered = TRUE",
    )
    .fetch_all(pool)
    .await
    .map(|x| x.into_iter().map(Into::into).collect())
}

pub struct DeviceRegistrationState {
    pub registered: bool,
    pub register_waiting_on_validation: Option<time::PrimitiveDateTime>,
    pub register_validation_completed: Option<time::PrimitiveDateTime>,
}

#[tracing::instrument(skip(pool))]
pub async fn get_device_registration_state(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Option<DeviceRegistrationState>> {
    sqlx::query_as!(
        DeviceRegistrationState,
        "SELECT \
            registered, \
            register_waiting_on_validation, \
            register_validation_completed \
         FROM devices \
         WHERE devices.uuid = $1",
        uuid
    )
    .fetch_optional(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn set_device_register_waiting_on_validation(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
    time: u64,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "UPDATE devices \
         SET register_waiting_on_validation = $2 \
         WHERE devices.uuid = $1",
        uuid,
        super::from_unix_timestamp_micros(time * 1_000_000),
    )
    .execute(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn set_device_register_validation_completed(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
    time: Option<u64>,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "UPDATE devices \
         SET register_validation_completed = $2 \
         WHERE devices.uuid = $1",
        uuid,
        time.map(|x| super::from_unix_timestamp_micros(x * 1_000_000)),
    )
    .execute(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn set_device_registered(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
    registered: bool,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "UPDATE devices \
         SET registered = $2 \
         WHERE devices.uuid = $1",
        uuid,
        registered
    )
    .execute(pool)
    .await
}

#[derive(Debug, serde::Deserialize)]
pub struct RegistrationInfo {
    pub name: String,
    pub longitude: f64,
    pub latitude: f64,
    pub user: uuid::Uuid,
}

#[tracing::instrument(skip(pool))]
pub async fn set_device_registration_info(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
    info: RegistrationInfo,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "UPDATE devices \
         SET name = $2, \
             location = $3, \
             \"user\" = (SELECT id FROM users WHERE uuid=$4) \
         WHERE devices.uuid = $1",
        uuid,
        info.name,
        wkb::Encode(geo_types::Geometry::Point(geo_types::Point::new(
            info.longitude,
            info.latitude
        ))) as _,
        info.user,
    )
    .execute(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn set_device_last_online(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
    last_online: u64,
) -> sqlx::Result<sqlx::postgres::PgQueryResult> {
    sqlx::query!(
        "UPDATE devices \
         SET last_online = $2 \
         WHERE devices.uuid = $1",
        uuid,
        super::from_unix_timestamp_micros(last_online * 1_000_000),
    )
    .execute(pool)
    .await
}

#[derive(serde::Serialize)]
pub struct DeviceStatus {
    pub voltage: Option<f64>,
    pub frequency: Option<f64>,
}

#[tracing::instrument(skip(pool))]
pub async fn get_device_status(
    pool: &sqlx::Pool<sqlx::Postgres>,
    device: uuid::Uuid,
) -> sqlx::Result<DeviceStatus> {
    sqlx::query_as!(
        DeviceStatus,
        "SELECT \
            (SELECT DISTINCT ON (voltage_points.stream) \
                voltage_points.values[1] \
            FROM data_streams \
            INNER JOIN heartbeat_data_points AS voltage_points \
                ON voltage_points.stream = data_streams.id \
                    AND data_streams.type='voltage_rms' \
            WHERE \
                data_streams.device=(SELECT id FROM devices WHERE uuid=$1) \
            ORDER BY voltage_points.stream, voltage_points.time DESC) \
        AS voltage, \
            (SELECT DISTINCT ON (frequency_points.stream) \
                frequency_points.values[1] AS frequency \
            FROM data_streams \
            INNER JOIN heartbeat_data_points AS frequency_points \
                ON frequency_points.stream = data_streams.id \
                    AND data_streams.type='frequency' \
            WHERE \
                data_streams.device=(SELECT id FROM devices WHERE uuid=$1) \
            ORDER BY frequency_points.stream, frequency_points.time DESC) \
        AS frequency",
        device
    )
    .fetch_one(pool)
    .await
}

pub struct DeviceWithStatusRec {
    pub uuid: uuid::Uuid,
    pub balena_uuid: uuid::Uuid,
    pub name: Option<String>,
    pub location: wkb::Decode<geo_types::Geometry<f64>>,
    pub user: Option<uuid::Uuid>,
    pub last_online: Option<time::PrimitiveDateTime>,

    pub voltage: Option<f64>,
    pub frequency: Option<f64>,
}

impl From<DeviceWithStatusRec> for (Device, DeviceStatus) {
    fn from(rec: DeviceWithStatusRec) -> Self {
        (
            Device {
                uuid: rec.uuid,
                balena_uuid: rec.balena_uuid,
                name: rec.name,
                location: rec.location.geometry.and_then(|x| x.try_into().ok()),
                user: rec.user,
                last_online: rec.last_online.map(super::to_unix_timestamp_micros),
            },
            DeviceStatus {
                voltage: rec.voltage,
                frequency: rec.frequency,
            },
        )
    }
}

#[tracing::instrument(skip(pool))]
pub async fn get_devices_with_status(
    pool: &sqlx::Pool<sqlx::Postgres>,
) -> sqlx::Result<Vec<(Device, DeviceStatus)>> {
    sqlx::query_as!(
        DeviceWithStatusRec,
        "SELECT \
            devices.uuid AS \"uuid!: _\", \
            devices.balena_uuid AS \"balena_uuid!: _\", \
            devices.name AS name, \
            devices.location::geometry AS \"location!: _\", \
            users.uuid AS \"user!: _\", \
            devices.last_online AS last_online, \
                (SELECT DISTINCT ON (voltage_points.stream) \
                    voltage_points.values[1] \
                FROM data_streams \
                INNER JOIN heartbeat_data_points AS voltage_points \
                    ON voltage_points.stream = data_streams.id \
                        AND data_streams.type='voltage_rms' \
                WHERE \
                    data_streams.device=devices.id \
                ORDER BY voltage_points.stream, voltage_points.time DESC) \
            AS voltage, \
                (SELECT DISTINCT ON (frequency_points.stream) \
                    frequency_points.values[1] AS frequency \
                FROM data_streams \
                INNER JOIN heartbeat_data_points AS frequency_points \
                    ON frequency_points.stream = data_streams.id \
                        AND data_streams.type='frequency' \
                WHERE \
                    data_streams.device=devices.id \
                ORDER BY frequency_points.stream, frequency_points.time DESC) \
            AS frequency \
         FROM devices \
         LEFT JOIN users \
            ON users.id = devices.\"user\"",
    )
    .fetch_all(pool)
    .await
    .map(|x| x.into_iter().map(Into::into).collect())
}
