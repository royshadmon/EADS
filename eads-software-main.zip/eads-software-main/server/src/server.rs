use axum::http;
use color_eyre::eyre;
use futures::TryFutureExt;
use sqlx::postgres::PgPoolOptions;
use tower::{make::Shared, util::ServiceExt, ServiceBuilder};
use tower_http::{
    cors::{self, CorsLayer},
    trace::TraceLayer,
};
use tracing_error::ErrorLayer;
use tracing_subscriber::{
    filter::EnvFilter, prelude::__tracing_subscriber_SubscriberExt, util::SubscriberInitExt,
    Registry,
};
use tracing_tree::HierarchicalLayer;

use grpc::auth_interceptor::AuthSettings;
use server_config::ServerConfig;

mod db;
mod grpc;
mod rest;
mod server_config;
mod server_error;

#[tokio::main]
async fn main() -> eyre::Result<()> {
    // Install better backtrace support
    color_eyre::install()?;

    // Initialize tracing library
    Registry::default()
        .with(EnvFilter::from_default_env())
        .with(
            HierarchicalLayer::new(2)
                .with_targets(true)
                .with_bracketed_fields(true),
        )
        .with(ErrorLayer::default())
        .init();

    // Create reqwest client
    let reqwest_client = reqwest::Client::new();

    // Get the environment variables into a server configure
    let config = ServerConfig::new(reqwest_client.clone()).await?;

    // Connect to the postgres database
    let sql_pool = PgPoolOptions::new()
        .max_connections(8)
        .connect(&config.postgres_uri)
        .await?;
    // Perform any outstanding migrations
    sqlx::migrate!().run(&sql_pool).await?;

    let cors = CorsLayer::new()
        .allow_methods(vec![http::Method::GET, http::Method::POST])
        .allow_origin(
            "http://localhost:8000"
                .parse::<http::HeaderValue>()
                .unwrap(),
        )
        .allow_credentials(cors::AllowCredentials::yes())
        .allow_headers([http::header::CONTENT_TYPE]);

    // Create the REST api service
    let rest_service = rest::make_router(config, sql_pool.clone(), reqwest_client.clone())
        // Install tracing
        .layer(
            ServiceBuilder::new()
                .layer(TraceLayer::new_for_http())
                .into_inner(),
        )
        .layer(cors)
        .map_err(tower::BoxError::from)
        .boxed_clone();

    let grpc_service = grpc::make_router(AuthSettings::new()?, sql_pool)?
        .into_service()
        .map_response(|r| r.map(axum::body::boxed))
        .boxed_clone();

    // Create service which chooses between REST and gRPC based on Content-Type
    let rest_grpc = tower::steer::Steer::new(
        vec![rest_service, grpc_service],
        |req: &http::Request<axum::body::Body>, _svcs: &[_]| {
            if req
                .headers()
                .get(http::header::CONTENT_TYPE)
                .map(|v| v.as_bytes())
                != Some(b"application/grpc")
            {
                0
            } else {
                1
            }
        },
    );

    // Start up the server
    let addr = "[::]:5001".parse()?;
    axum::Server::bind(&addr)
        // Start up the server
        .serve(Shared::new(rest_grpc))
        .await?;

    Ok(())
}
