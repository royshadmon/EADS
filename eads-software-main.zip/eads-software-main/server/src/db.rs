use sqlx::types::time;

mod calibration;
mod channel;
mod data_point;
mod data_stream;
mod device;
mod device_phase;
mod event;
mod user;

pub use calibration::*;
pub use channel::*;
pub use data_point::*;
pub use data_stream::*;
pub use device::*;
pub use device_phase::*;
pub use event::*;
pub use user::*;

fn from_unix_timestamp_micros(timestamp: u64) -> time::PrimitiveDateTime {
    let time = time::OffsetDateTime::from_unix_timestamp_nanos(timestamp as i128 * 1000);
    time::PrimitiveDateTime::new(time.date(), time.time())
}

fn to_unix_timestamp_micros(timestamp: time::PrimitiveDateTime) -> u64 {
    (timestamp.assume_utc().unix_timestamp_nanos() / 1000)
        .try_into()
        .unwrap()
}
