#include "user_context.h"

const scpi_user_settings_t default_user_settings = {
    .trigger_channel = 7,
    .trigger_level = 3072,

    .channel = 0,
    .points = 8000,
};

const scpi_user_state_t default_user_state = {
    .device_state = STOPPED,
    .trigger_sample_count_left = 0,
    .trigger_timestamp_origin = 0,
};
