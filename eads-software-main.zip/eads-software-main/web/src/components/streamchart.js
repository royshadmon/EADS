import React from "react";
import useSWR from "swr";

import { Table } from 'react-bootstrap';
import DeviceMap from '../components/devicemap.js';

const fetcher = (url) => fetch(url, { credentials: 'include' }).then((res) => res.json());

export default function StreamChart() {
  
}
