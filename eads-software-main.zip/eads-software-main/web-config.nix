# This file holds the configuration options passed in to the eads-web nix build.
{
  REACT_APP_CONTACT_EMAIL="";
  REACT_APP_API_URI="";
  REACT_APP_MAPBOX_ACCESS_TOKEN="";
}
