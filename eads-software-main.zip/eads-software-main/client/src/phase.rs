use std::collections::HashSet;

use color_eyre::eyre;
use futures::StreamExt;
use itertools::Itertools;
use tokio::sync::{broadcast, Mutex};
use tokio_stream::wrappers::{errors::BroadcastStreamRecvError, BroadcastStream};
use tracing::warn;

use crate::{
    channel::Channel,
    settings::PhaseSettings,
    stream::{Stream, StreamEvent},
    device::Sample,
};

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum PhaseStatus {
    Normal,
    Fault,
}

#[derive(Debug, Clone, Copy)]
pub enum PhaseEvent {
    StatusChange { time: u64, status: PhaseStatus },
}

pub struct Phase {
    settings: PhaseSettings,
    status: Mutex<PhaseStatus>,

    channels: Vec<Channel>,
    streams: Vec<Stream>,

    event_bus: broadcast::Sender<PhaseEvent>,
    // We must keep one receiver open to keep the broadcast open to ensure sending is always valid.
    // This induces a memory overhead of (sizeof(StreamEvent) * CHANNEL_BUFFER_LENGTH) and messages
    // after this will simply overwrite old values.
    event_bus_rx: broadcast::Receiver<PhaseEvent>,
}

impl Phase {
    pub fn new(settings: PhaseSettings) -> Phase {
        let channels = settings
            .channels
            .iter()
            .cloned()
            .map(Channel::new)
            .collect_vec();
        let streams: Vec<_> = settings
            .streams
            .iter()
            .cloned()
            .map(|s| Stream::new(s, &channels))
            .collect();

        let (event_bus, event_bus_rx) = broadcast::channel(100 /* TODO */);

        Phase {
            settings,
            status: Mutex::new(PhaseStatus::Normal),
            channels,
            streams,
            event_bus,
            event_bus_rx,
        }
    }

    pub fn uuid(&self) -> &str {
        &self.settings.uuid
    }

    /// Get a stream containing samples tagged with uuid of the originating stream
    pub fn subscribe(
        &self,
    ) -> Box<impl futures::stream::Stream<Item = (&str, Result<Sample, BroadcastStreamRecvError>)>>
    {
        Box::new(futures::stream::select_all::select_all(
            self.streams
                .iter()
                .map(|s| Stream::subscribe(s).map(|x| (s.uuid(), x))),
        ))
    }

    pub fn subscribe_events(
        &self,
    ) -> Box<impl futures::stream::Stream<Item = Result<PhaseEvent, BroadcastStreamRecvError>>>
    {
        Box::new(BroadcastStream::new(self.event_bus.subscribe()))
    }

    pub async fn worker(&self) -> Result<(), eyre::Report> {
        let mut event_streams = futures::stream::select_all::select_all(
            self.streams
                .iter()
                .map(|s| Stream::subscribe_events(s).map(|x| (s.uuid(), x))),
        );

        let mut streams_with_faults: HashSet<&str> = HashSet::new();

        while let Some((stream, item)) = event_streams.next().await {
            match item {
                Ok(StreamEvent::StatusChange { time, status }) => {
                    match status {
                        crate::stream::StreamStatus::Fault => {
                            if streams_with_faults.is_empty() {
                                let mut lock = self.status.lock().await;

                                if *lock != PhaseStatus::Fault {
                                    self.event_bus.send(PhaseEvent::StatusChange {
                                        time,
                                        status: PhaseStatus::Fault,
                                    })?;
                                    *lock = PhaseStatus::Fault;
                                }
                            }

                            streams_with_faults.insert(stream);
                        }
                        crate::stream::StreamStatus::Normal => {
                            streams_with_faults.remove(stream);

                            if streams_with_faults.is_empty() {
                                let mut lock = self.status.lock().await;

                                if *lock != PhaseStatus::Normal {
                                    self.event_bus.send(PhaseEvent::StatusChange {
                                        time,
                                        status: PhaseStatus::Normal,
                                    })?;
                                    *lock = PhaseStatus::Normal;
                                }
                            }
                        }
                    };
                }
                Err(_) => warn!("Event stream fell behind."),
            }
        }

        Ok(())
    }

    /// Get a reference to the phase's channels.
    pub fn channels(&self) -> &[Channel] {
        self.channels.as_ref()
    }

    /// Get a reference to the phase's streams.
    pub fn streams(&self) -> &[Stream] {
        self.streams.as_ref()
    }

    /// Get a reference to the phase's status.
    pub fn status(&self) -> &Mutex<PhaseStatus> {
        &self.status
    }
}
