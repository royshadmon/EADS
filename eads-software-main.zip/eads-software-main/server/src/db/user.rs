#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct User {
    pub uuid: sqlx::types::Uuid,
    pub auth0_id: String,
}

#[tracing::instrument(skip(pool))]
pub async fn get_user(
    pool: &sqlx::Pool<sqlx::Postgres>,
    user_uuid: uuid::Uuid,
) -> sqlx::Result<Option<User>> {
    sqlx::query!("SELECT * FROM users WHERE uuid = $1", user_uuid)
        .fetch_optional(pool)
        .await
        .map(|x| {
            x.map(|row| User {
                uuid: row.uuid,
                auth0_id: row.auth0_id,
            })
        })
}

#[tracing::instrument(skip(pool))]
pub async fn get_user_by_auth0(
    pool: &sqlx::Pool<sqlx::Postgres>,
    auth0_id: &str,
) -> sqlx::Result<Option<User>> {
    sqlx::query!("SELECT * FROM users WHERE auth0_id = $1", auth0_id)
        .fetch_optional(pool)
        .await
        .map(|x| {
            x.map(|row| User {
                uuid: row.uuid,
                auth0_id: row.auth0_id,
            })
        })
}

#[tracing::instrument(skip(pool))]
pub async fn create_user(pool: &sqlx::Pool<sqlx::Postgres>, user: User) -> sqlx::Result<i64> {
    sqlx::query!(
        "INSERT INTO users (uuid, auth0_id) VALUES ($1, $2) RETURNING (id)",
        user.uuid,
        user.auth0_id
    )
    .fetch_one(pool)
    .await
    .map(|row| Ok(row.id))?
}
