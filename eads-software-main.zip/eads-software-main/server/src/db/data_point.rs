use sqlx::types::time;

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct DataPoint {
    pub stream: uuid::Uuid,
    pub event: uuid::Uuid,
    pub time: u64,
    pub duration: u64,
    pub values: Vec<f64>,
}

#[tracing::instrument(skip(pool))]
pub async fn insert_event_datapoint(
    pool: &sqlx::Pool<sqlx::Postgres>,
    datapoint: DataPoint,
) -> sqlx::Result<i64> {
    sqlx::query!(
        "INSERT INTO event_data_points ( \
            stream, \
            event, \
            time, \
            duration, \
            values \
        ) VALUES ( \
            (SELECT (id) FROM data_streams WHERE uuid=$1), \
            (SELECT (id) FROM events WHERE uuid=$2), \
            $3, \
            $4, \
            $5 \
        ) RETURNING (id)",
        datapoint.stream,
        datapoint.event,
        super::from_unix_timestamp_micros(datapoint.time),
        // TODO: This will not work if an event lasts longer than a day!
        sqlx::postgres::types::PgInterval {
            microseconds: datapoint.duration as i64,
            months: 0,
            days: 0,
        },
        &datapoint.values
    )
    .fetch_one(pool)
    .await
    .map(|row| Ok(row.id))?
}

pub struct DataPointRec {
    pub stream: uuid::Uuid,
    pub event: uuid::Uuid,
    pub time: time::PrimitiveDateTime,
    pub duration: sqlx::postgres::types::PgInterval,
    pub values: Vec<f64>,
}

#[tracing::instrument(skip(pool))]
pub async fn get_event_datapoints(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
) -> sqlx::Result<Vec<DataPoint>> {
    sqlx::query_as!(
        DataPointRec,
        "SELECT \
            data_streams.uuid AS \"stream!: _\", \
            events.uuid AS \"event!: _\", \
            event_data_points.time AS \"time!: _\", \
            event_data_points.duration AS \"duration!: _\", \
            event_data_points.values AS \"values!: _\" \
        FROM event_data_points \
        INNER JOIN events \
            ON events.id = event_data_points.event \
        INNER JOIN data_streams \
            ON data_streams.id = event_data_points.stream \
        WHERE event=(SELECT id FROM events WHERE uuid=$1)
        ORDER BY event_data_points.time ASC",
        event
    )
    .fetch_all(pool)
    .await
    .map(|x| {
        x.into_iter()
            .map(|rec| DataPoint {
                stream: rec.stream,
                event,
                time: super::to_unix_timestamp_micros(rec.time),
                // TODO: This will not work if an event lasts longer than a day!
                duration: rec.duration.microseconds as u64,
                values: rec.values,
            })
            .collect()
    })
}

#[tracing::instrument(skip(pool))]
pub async fn get_event_datapoints_for_streams(
    pool: &sqlx::Pool<sqlx::Postgres>,
    event: uuid::Uuid,
    streams: Vec<uuid::Uuid>,
) -> sqlx::Result<Vec<DataPoint>> {
    sqlx::query_as!(
        DataPointRec,
        "SELECT \
            data_streams.uuid AS \"stream!: _\", \
            events.uuid AS \"event!: _\", \
            event_data_points.time AS \"time!: _\", \
            event_data_points.duration AS \"duration!: _\", \
            event_data_points.values AS \"values!: _\" \
        FROM event_data_points \
        INNER JOIN events \
            ON events.id = event_data_points.event \
        INNER JOIN data_streams \
            ON data_streams.id = event_data_points.stream \
        WHERE event=(SELECT id FROM events WHERE uuid=$1)
            AND data_streams.uuid = ANY($2)
        ORDER BY event_data_points.time ASC",
        event,
        &streams[..]
    )
    .fetch_all(pool)
    .await
    .map(|x| {
        x.into_iter()
            .map(|rec| DataPoint {
                stream: rec.stream,
                event,
                time: super::to_unix_timestamp_micros(rec.time),
                // TODO: This will not work if an event lasts longer than a day!
                duration: rec.duration.microseconds as u64,
                values: rec.values,
            })
            .collect()
    })
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct HeartbeatDataPoint {
    pub stream: uuid::Uuid,
    pub time: u64,
    pub duration: u64,
    pub values: Vec<f64>,
}

pub struct HeartbeatDataPointRec {
    pub stream: uuid::Uuid,
    pub time: time::PrimitiveDateTime,
    pub duration: sqlx::postgres::types::PgInterval,
    pub values: Vec<f64>,
}

#[tracing::instrument(skip(pool))]
pub async fn insert_heartbeat_datapoint(
    pool: &sqlx::Pool<sqlx::Postgres>,
    datapoint: HeartbeatDataPoint,
) -> sqlx::Result<i64> {
    sqlx::query!(
        "INSERT INTO heartbeat_data_points ( \
            stream, \
            time, \
            duration, \
            values \
        ) VALUES ( \
            (SELECT (id) FROM data_streams WHERE uuid=$1), \
            $2, \
            $3, \
            $4 \
        ) RETURNING (id)",
        datapoint.stream,
        super::from_unix_timestamp_micros(datapoint.time),
        sqlx::postgres::types::PgInterval {
            microseconds: datapoint.duration as i64,
            months: 0,
            days: 0,
        },
        &datapoint.values
    )
    .fetch_one(pool)
    .await
    .map(|row| Ok(row.id))?
}

/// Get the most recent heartbeat for the given data stream
#[tracing::instrument(skip(pool))]
pub async fn get_latest_heartbeat_datapoint_for_stream(
    pool: &sqlx::Pool<sqlx::Postgres>,
    stream: uuid::Uuid,
) -> sqlx::Result<Option<HeartbeatDataPoint>> {
    sqlx::query_as!(
        HeartbeatDataPointRec,
        "SELECT \
            data_streams.uuid AS \"stream!: _\", \
            heartbeat_data_points.time AS \"time!: _\", \
            heartbeat_data_points.duration AS \"duration!: _\", \
            heartbeat_data_points.values AS \"values!: _\" \
        FROM heartbeat_data_points \
        INNER JOIN data_streams \
            ON data_streams.id = heartbeat_data_points.stream \
        WHERE data_streams.uuid=$1
        ORDER BY heartbeat_data_points.time ASC
        LIMIT 1",
        stream
    )
    .fetch_optional(pool)
    .await
    .map(|x| {
        x.map(|rec| HeartbeatDataPoint {
            stream: rec.stream,
            time: super::to_unix_timestamp_micros(rec.time),
            // TODO: This will not work if an event lasts longer than a day!
            duration: rec.duration.microseconds as u64,
            values: rec.values,
        })
    })
}

/// Get the most recent heartbeat for all streams on the given device
#[tracing::instrument(skip(pool))]
pub async fn get_latest_heartbeat_datapoints_for_device(
    pool: &sqlx::Pool<sqlx::Postgres>,
    device: uuid::Uuid,
) -> sqlx::Result<Vec<HeartbeatDataPoint>> {
    sqlx::query_as!(
        HeartbeatDataPointRec,
        "SELECT \
            data_streams.uuid AS \"stream!: _\", \
            sq.time AS \"time!: _\", \
            sq.duration AS \"duration!: _\", \
            sq.values AS \"values!: _\" \
        FROM ( \
            SELECT DISTINCT ON (stream) * \
            FROM heartbeat_data_points \
            ORDER BY heartbeat_data_points.stream, heartbeat_data_points.time DESC \
        ) sq \
        INNER JOIN data_streams \
            ON data_streams.id = sq.stream \
        WHERE data_streams.device=(SELECT id FROM devices WHERE uuid=$1) \
        ORDER BY sq.time DESC",
        device
    )
    .fetch_all(pool)
    .await
    .map(|x| {
        x.into_iter()
            .map(|rec| HeartbeatDataPoint {
                stream: rec.stream,
                time: super::to_unix_timestamp_micros(rec.time),
                // TODO: This will not work if an event lasts longer than a day!
                duration: rec.duration.microseconds as u64,
                values: rec.values,
            })
            .collect()
    })
}
