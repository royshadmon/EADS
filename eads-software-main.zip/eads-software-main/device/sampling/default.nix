{ pkgs, ... }:
rec {
  eads-sampling = pkgs.stdenv.mkDerivation {
    name = "eads-sampling";

    src = ./src;

    buildInputs = [
      pkgs.concurrencykit
    ];

    SAMPLING_ADC = "MCP3202";

    installPhase = ''
      mkdir -p $out/bin

      mv sampling $out/bin/sampling
    '';
  };

  eads-sampling-container = pkgs.dockerTools.buildImage {
    name = "eads-sampling";

    config = {
      Cmd = ["${eads-sampling}/bin/sampling"];
    };
  };
}
