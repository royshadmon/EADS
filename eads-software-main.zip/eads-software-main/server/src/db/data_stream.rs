#[derive(Debug, serde::Serialize, serde::Deserialize, sqlx::Type)]
#[serde(rename_all = "snake_case")]
#[sqlx(type_name = "data_stream_type", rename_all = "snake_case")]
pub enum DataStreamType {
    Waveform,
    VoltageRms,
    Frequency,
}

#[derive(Debug, serde::Serialize, serde::Deserialize, sqlx::Type)]
#[serde(rename_all = "snake_case")]
#[sqlx(type_name = "data_stream_units", rename_all = "snake_case")]
pub enum DataStreamUnits {
    Volts,
    Amps,
    Watts,
    Hz,
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
pub struct DataStream {
    pub uuid: uuid::Uuid,
    pub r#type: DataStreamType,
    pub computed: bool,
    pub units: DataStreamUnits,
    pub frequency: f64,
    pub threshold_low: Option<f64>,
    pub threshold_high: Option<f64>,
    pub channel: uuid::Uuid,
    pub device: uuid::Uuid,
    pub phase: uuid::Uuid,
}

#[tracing::instrument(skip(pool))]
pub async fn create_data_stream(
    pool: &sqlx::Pool<sqlx::Postgres>,
    data_stream: DataStream,
) -> sqlx::Result<i64> {
    sqlx::query!(
        "INSERT INTO data_streams ( \
            uuid, \
            type, \
            computed, \
            units, \
            frequency, \
            threshold_low, \
            threshold_high, \
            channel, \
            device, \
            phase \
        ) VALUES ( \
            $1, \
            $2, \
            $3, \
            $4, \
            $5, \
            $6, \
            $7, \
            (SELECT (id) FROM channels WHERE uuid=$8), \
            (SELECT (id) FROM devices WHERE uuid=$9), \
            (SELECT (id) FROM device_phases WHERE uuid=$10) \
        ) RETURNING (id)",
        data_stream.uuid,
        data_stream.r#type as DataStreamType,
        data_stream.computed,
        data_stream.units as DataStreamUnits,
        data_stream.frequency,
        data_stream.threshold_low,
        data_stream.threshold_high,
        data_stream.channel,
        data_stream.device,
        data_stream.phase,
    )
    .fetch_one(pool)
    .await
    .map(|row| Ok(row.id))?
}

#[tracing::instrument(skip(pool))]
pub async fn get_data_stream(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Option<DataStream>> {
    sqlx::query_as!(
        DataStream,
        "SELECT \
            data_streams.uuid AS uuid, \
            data_streams.type AS \"type!: _\", \
            data_streams.computed AS computed, \
            data_streams.units AS \"units!: _\", \
            data_streams.frequency AS frequency, \
            data_streams.threshold_low AS threshold_low, \
            data_streams.threshold_high AS threshold_high, \
            channels.uuid AS channel, \
            devices.uuid AS device, \
            device_phases.uuid AS phase \
         FROM data_streams \
         INNER JOIN channels \
            ON channels.id = data_streams.channel \
         INNER JOIN devices \
            ON devices.id = data_streams.device \
         INNER JOIN device_phases \
            ON device_phases.id = data_streams.phase \
         WHERE data_streams.uuid = $1",
        uuid
    )
    .fetch_optional(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn get_data_streams(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuids: Vec<uuid::Uuid>,
) -> sqlx::Result<Vec<DataStream>> {
    sqlx::query_as!(
        DataStream,
        "SELECT \
            data_streams.uuid AS \"uuid!: _\", \
            data_streams.type AS \"type!: _\", \
            data_streams.computed AS \"computed!: _\", \
            data_streams.units AS \"units!: _\", \
            data_streams.frequency AS \"frequency!: _\", \
            data_streams.threshold_low AS \"threshold_low!: _\", \
            data_streams.threshold_high AS \"threshold_high!: _\", \
            channels.uuid AS \"channel!: _\", \
            devices.uuid AS \"device!: _\", \
            device_phases.uuid AS \"phase!: _\" \
         FROM data_streams \
         INNER JOIN channels \
            ON channels.id = data_streams.channel \
         INNER JOIN devices \
            ON devices.id = data_streams.device \
         INNER JOIN device_phases \
            ON device_phases.id = data_streams.phase \
         WHERE data_streams.uuid = ANY($1)",
        &uuids[..]
    )
    .fetch_all(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn get_all_data_streams(
    pool: &sqlx::Pool<sqlx::Postgres>,
) -> sqlx::Result<Vec<DataStream>> {
    sqlx::query_as!(
        DataStream,
        "SELECT \
            data_streams.uuid AS \"uuid!: _\", \
            data_streams.type AS \"type!: _\", \
            data_streams.computed AS \"computed!: _\", \
            data_streams.units AS \"units!: _\", \
            data_streams.frequency AS \"frequency!: _\", \
            data_streams.threshold_low AS threshold_low, \
            data_streams.threshold_high AS threshold_high, \
            channels.uuid AS \"channel!: _\", \
            devices.uuid AS \"device!: _\", \
            device_phases.uuid AS \"phase!: _\" \
         FROM data_streams \
         INNER JOIN channels \
            ON channels.id = data_streams.channel \
         INNER JOIN device_phases \
            ON device_phases.id = data_streams.phase \
         INNER JOIN devices \
            ON devices.id = data_streams.device",
    )
    .fetch_all(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn get_data_streams_by_phase(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Vec<DataStream>> {
    sqlx::query_as!(
        DataStream,
        "SELECT \
            data_streams.uuid AS uuid, \
            data_streams.type AS \"type!: _\", \
            data_streams.computed AS computed, \
            data_streams.units AS \"units!: _\", \
            data_streams.frequency AS frequency, \
            data_streams.threshold_low AS threshold_low, \
            data_streams.threshold_high AS threshold_high, \
            channels.uuid AS channel, \
            devices.uuid AS device, \
            device_phases.uuid AS phase \
         FROM device_phases \
         INNER JOIN data_streams \
            ON data_streams.phase = device_phases.id \
         INNER JOIN channels \
            ON channels.id = data_streams.channel \
         INNER JOIN devices \
            ON devices.id = data_streams.device \
         WHERE device_phases.uuid = $1",
        uuid
    )
    .fetch_all(pool)
    .await
}

#[tracing::instrument(skip(pool))]
pub async fn get_data_streams_by_device(
    pool: &sqlx::Pool<sqlx::Postgres>,
    uuid: uuid::Uuid,
) -> sqlx::Result<Vec<DataStream>> {
    sqlx::query_as!(
        DataStream,
        "SELECT \
            data_streams.uuid AS uuid, \
            data_streams.type AS \"type!: _\", \
            data_streams.computed AS computed, \
            data_streams.units AS \"units!: _\", \
            data_streams.frequency AS frequency, \
            data_streams.threshold_low AS threshold_low, \
            data_streams.threshold_high AS threshold_high, \
            channels.uuid AS channel, \
            devices.uuid AS device, \
            device_phases.uuid AS phase \
         FROM devices \
         INNER JOIN data_streams \
            ON data_streams.device = devices.id \
         INNER JOIN channels \
            ON channels.id = data_streams.channel \
         INNER JOIN device_phases \
            ON device_phases.id = data_streams.phase \
         WHERE devices.uuid = $1",
        uuid
    )
    .fetch_all(pool)
    .await
}
